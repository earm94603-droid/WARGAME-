package com.containerclash.fps;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
