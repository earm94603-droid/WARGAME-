import React, { useRef, useEffect, useState } from 'react';
import { Heart, Pause, RotateCcw, Crosshair, ChevronUp, ShieldAlert } from 'lucide-react';
import { MatchState, PlayerStats, formatGameTime } from '../game/rules.ts';

interface HUDProps {
  matchState: MatchState;
  playerStats: PlayerStats;
  isAiming: boolean;
  hitmarkerActive: boolean;
  damageFlashActive: boolean;
  playerPos: { x: number; z: number; yaw: number };
  enemyPos: { x: number; z: number } | null;
  peekState: 'left' | 'center' | 'right';
  onPeekChange: (dir: 'left' | 'center' | 'right') => void;
  onFireDown: () => void;
  onFireUp: () => void;
  onAimToggle: () => void;
  onJump: () => void;
  onCrouchToggle: () => void;
  onReload: () => void;
  onPauseToggle: () => void;
  onMoveChange: (x: number, y: number) => void;
  onLookDelta: (dx: number, dy: number) => void;
}

export const HUD: React.FC<HUDProps> = ({
  matchState,
  playerStats,
  isAiming,
  hitmarkerActive,
  damageFlashActive,
  playerPos,
  enemyPos,
  peekState,
  onPeekChange,
  onFireDown,
  onFireUp,
  onAimToggle,
  onJump,
  onCrouchToggle,
  onReload,
  onPauseToggle,
  onMoveChange,
  onLookDelta,
}) => {
  const [isTouchDevice, setIsTouchDevice] = useState(() => {
    if (typeof window === 'undefined') return false;
    return (
      'ontouchstart' in window ||
      navigator.maxTouchPoints > 0 ||
      window.innerWidth < 1024 ||
      window.innerHeight < 650
    );
  });
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const joystickKnobRef = useRef<HTMLDivElement>(null);
  const lookTouchIdRef = useRef<number | null>(null);
  const lastTouchPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const moveTouchIdRef = useRef<number | null>(null);

  useEffect(() => {
    const handleResize = () => {
      setIsTouchDevice(
        'ontouchstart' in window ||
          navigator.maxTouchPoints > 0 ||
          window.innerWidth < 1024 ||
          window.innerHeight < 650
      );
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Joystick touch tracking
  const handleJoystickTouchStart = (e: React.TouchEvent) => {
    if (moveTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    moveTouchIdRef.current = touch.identifier;
    updateJoystick(touch.clientX, touch.clientY);
  };

  const handleJoystickTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === moveTouchIdRef.current) {
        updateJoystick(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleJoystickTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === moveTouchIdRef.current) {
        moveTouchIdRef.current = null;
        if (joystickKnobRef.current) {
          joystickKnobRef.current.style.transform = `translate(0px, 0px)`;
        }
        onMoveChange(0, 0);
        break;
      }
    }
  };

  const updateJoystick = (clientX: number, clientY: number) => {
    if (!joystickBaseRef.current || !joystickKnobRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const maxRadius = rect.width / 2 - 12;
    const distance = Math.hypot(dx, dy);

    const clampedDist = Math.min(distance, maxRadius);
    const angle = Math.atan2(dy, dx);

    const knobX = Math.cos(angle) * clampedDist;
    const knobY = Math.sin(angle) * clampedDist;

    joystickKnobRef.current.style.transform = `translate(${knobX}px, ${knobY}px)`;

    const normX = knobX / maxRadius;
    const normY = knobY / maxRadius;
    onMoveChange(normX, -normY);
  };

  // Right-side Look Touch Handling (Entire Right Half of the screen)
  const handleLookTouchStart = (e: React.TouchEvent) => {
    if (lookTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    lookTouchIdRef.current = touch.identifier;
    lastTouchPosRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleLookTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchIdRef.current) {
        const rawDx = touch.clientX - lastTouchPosRef.current.x;
        const rawDy = touch.clientY - lastTouchPosRef.current.y;
        lastTouchPosRef.current = { x: touch.clientX, y: touch.clientY };
        // Clamp maximum frame delta to prevent camera snaps
        const dx = Math.max(-28, Math.min(28, rawDx));
        const dy = Math.max(-28, Math.min(28, rawDy));
        if (Math.abs(dx) > 0 || Math.abs(dy) > 0) {
          onLookDelta(dx, dy);
        }
        break;
      }
    }
  };

  const handleLookTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === lookTouchIdRef.current) {
        lookTouchIdRef.current = null;
        break;
      }
    }
  };

  // Drag-to-Aim while holding Fire button
  const fireTouchPosRef = useRef<{ x: number; y: number } | null>(null);

  const handleFireTouchStart = (e: React.TouchEvent) => {
    e.stopPropagation();
    onFireDown();
    const touch = e.changedTouches[0];
    fireTouchPosRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleFireTouchMove = (e: React.TouchEvent) => {
    e.stopPropagation();
    if (fireTouchPosRef.current && e.changedTouches.length > 0) {
      const touch = e.changedTouches[0];
      const rawDx = touch.clientX - fireTouchPosRef.current.x;
      const rawDy = touch.clientY - fireTouchPosRef.current.y;
      fireTouchPosRef.current = { x: touch.clientX, y: touch.clientY };
      const dx = Math.max(-18, Math.min(18, rawDx));
      const dy = Math.max(-18, Math.min(18, rawDy));
      onLookDelta(dx, dy);
    }
  };

  const handleFireTouchEnd = (e: React.TouchEvent) => {
    e.stopPropagation();
    onFireUp();
    fireTouchPosRef.current = null;
  };

  // Radar Mini-Map calculations
  const radarScale = 1.35; // map 64m to radar canvas
  const mapCenter = 44; // 88x88 px radar
  const radarPlayerX = mapCenter + playerPos.x * (mapCenter / 32) * 0.75;
  const radarPlayerY = mapCenter + playerPos.z * (mapCenter / 32) * 0.75;

  let radarEnemyX = 0;
  let radarEnemyY = 0;
  let isEnemyOnRadar = false;
  if (enemyPos) {
    radarEnemyX = mapCenter + enemyPos.x * (mapCenter / 32) * 0.75;
    radarEnemyY = mapCenter + enemyPos.z * (mapCenter / 32) * 0.75;
    isEnemyOnRadar = true;
  }

  // Health color
  const hpPercent = Math.max(0, Math.min(100, playerStats.health));
  const hpColorClass =
    hpPercent > 50 ? 'bg-emerald-500' : hpPercent > 25 ? 'bg-amber-500' : 'bg-red-600';

  return (
    <div className="absolute inset-0 pointer-events-none select-none overflow-hidden z-20">
      {/* Damage Screen Flash Vignette */}
      {damageFlashActive && (
        <div className="absolute inset-0 bg-red-600/35 animate-pulse pointer-events-none border-8 border-red-600/60" />
      )}

      {/* 1. TOP SCORE & MATCH STATUS BAR (Faithful to Screenshot 3) */}
      <div className="absolute top-3 inset-x-0 flex items-center justify-center px-4 pointer-events-auto">
        <div className="flex items-center bg-[#0d131f]/90 border border-slate-700/80 rounded-md shadow-2xl overflow-hidden backdrop-blur-none">
          {/* Blue Score */}
          <div className="flex items-center gap-2 px-4 py-1.5 bg-blue-600/80 text-white font-heading text-2xl tracking-wide">
            <span className="text-xs uppercase tracking-widest text-blue-200">BLUE</span>
            <span className="font-bold text-3xl tabular-nums">{matchState.blueScore}</span>
          </div>

          {/* Match Timer */}
          <div className="px-5 py-1.5 flex flex-col items-center justify-center bg-[#0d131f]">
            <span className="text-[10px] text-slate-400 font-tactical tracking-wider">TARGET: {matchState.targetKills}</span>
            <span className="font-tactical text-xl font-bold text-white tracking-widest tabular-nums">
              {formatGameTime(matchState.timeLeftSeconds)}
            </span>
          </div>

          {/* Red Score */}
          <div className="flex items-center gap-2 px-4 py-1.5 bg-red-600/80 text-white font-heading text-2xl tracking-wide">
            <span className="font-bold text-3xl tabular-nums">{matchState.redScore}</span>
            <span className="text-xs uppercase tracking-widest text-red-200">RED</span>
          </div>

          {/* Pause Button */}
          <button
            onClick={onPauseToggle}
            className="p-2.5 text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors border-l border-slate-700"
            title="Pause Match"
            aria-label="Pause Match"
          >
            <Pause className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 2. TOP-LEFT RADAR MINI-MAP (Screenshot 3 Reference) */}
      <div className="absolute top-3 left-3 flex flex-col gap-1 pointer-events-auto">
        <div className="w-[92px] h-[92px] bg-[#0c121e]/90 border border-slate-700 rounded-md p-1 relative shadow-xl overflow-hidden">
          {/* Radar background grid lines */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f293d_1px,transparent_1px),linear-gradient(to_bottom,#1f293d_1px,transparent_1px)] bg-[size:16px_16px] opacity-40" />

          {/* Center container yard outlines */}
          <div className="absolute top-[36px] left-[32px] w-[24px] h-[16px] border border-blue-500/40 bg-blue-900/20" />
          <div className="absolute top-[20px] left-[18px] w-[14px] h-[22px] border border-red-500/40 bg-red-900/20" />
          <div className="absolute top-[52px] left-[52px] w-[14px] h-[22px] border border-yellow-500/40 bg-yellow-900/20" />

          {/* Player Position & Direction Cone */}
          <div
            className="absolute w-3 h-3 -ml-1.5 -mt-1.5 z-10"
            style={{
              left: `${Math.max(6, Math.min(84, radarPlayerX))}px`,
              top: `${Math.max(6, Math.min(84, radarPlayerY))}px`,
            }}
          >
            <div
              className="w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-b-[9px] border-b-cyan-400 drop-shadow-[0_0_4px_cyan]"
              style={{ transform: `rotate(${-playerPos.yaw}rad)` }}
            />
          </div>

          {/* Enemy Blip Ping */}
          {isEnemyOnRadar && (
            <div
              className="absolute w-2.5 h-2.5 -ml-1.25 -mt-1.25 rounded-full bg-red-500 animate-ping z-10"
              style={{
                left: `${Math.max(6, Math.min(84, radarEnemyX))}px`,
                top: `${Math.max(6, Math.min(84, radarEnemyY))}px`,
              }}
            />
          )}

          {/* Compass labels */}
          <div className="absolute top-0.5 inset-x-0 text-center text-[9px] text-cyan-400/80 font-tactical font-bold">N</div>
        </div>
      </div>

      {/* 3. CENTER DYNAMIC CROSSHAIR & HITMARKER */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {!isAiming ? (
          <div className="relative w-8 h-8 flex items-center justify-center">
            {/* Crosshair pips */}
            <div className="absolute top-0 w-0.5 h-2 bg-white/85 shadow-sm" />
            <div className="absolute bottom-0 w-0.5 h-2 bg-white/85 shadow-sm" />
            <div className="absolute left-0 h-0.5 w-2 bg-white/85 shadow-sm" />
            <div className="absolute right-0 h-0.5 w-2 bg-white/85 shadow-sm" />
            <div className="w-1 h-1 rounded-full bg-white/90" />

            {/* Hitmarker X indicator */}
            {hitmarkerActive && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-4 h-4 border-2 border-red-500 rotate-45 animate-ping" />
                <div className="absolute w-3.5 h-3.5 border-t-2 border-r-2 border-red-500 rotate-45" />
                <div className="absolute w-3.5 h-3.5 border-b-2 border-l-2 border-red-500 rotate-45" />
              </div>
            )}
          </div>
        ) : (
          /* ADS Precise Holo Center */
          <div className="relative w-5 h-5 flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]" />
            {hitmarkerActive && (
              <div className="absolute w-4 h-4 border-2 border-red-400 rotate-45 animate-ping" />
            )}
          </div>
        )}
      </div>

      {/* 4. BOTTOM-LEFT HEALTH BAR (Screenshot 3 Reference) */}
      <div className="absolute bottom-4 left-4 flex items-center gap-3 bg-[#0d131f]/90 border border-slate-700/80 p-2.5 rounded-md shadow-2xl pointer-events-auto">
        <div className="w-9 h-9 rounded bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-500">
          <Heart className="w-5 h-5 fill-red-500 animate-pulse" />
        </div>
        <div className="flex flex-col gap-1 w-36">
          <div className="flex items-center justify-between text-xs font-tactical font-bold text-slate-300">
            <span>HEALTH</span>
            <span className="tabular-nums text-white text-sm">{Math.ceil(playerStats.health)}</span>
          </div>
          <div className="h-2.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-700">
            <div
              className={`h-full transition-all duration-150 ${hpColorClass}`}
              style={{ width: `${hpPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* 5. BOTTOM-RIGHT AMMO INDICATOR (Screenshot 3 Reference) */}
      <div className="absolute bottom-4 right-4 flex items-center gap-3 bg-[#0d131f]/90 border border-slate-700/80 p-2.5 rounded-md shadow-2xl pointer-events-auto">
        <div className="flex flex-col items-end">
          <div className="text-[10px] text-slate-400 font-tactical tracking-wider">M4 ASSAULT RIFLE</div>
          <div className="flex items-baseline gap-1 font-tactical">
            <span className={`text-2xl font-bold tabular-nums ${playerStats.ammo <= 5 ? 'text-red-400 animate-pulse' : 'text-white'}`}>
              {playerStats.ammo}
            </span>
            <span className="text-slate-500 text-sm">/</span>
            <span className="text-slate-400 text-sm tabular-nums">{playerStats.reserveAmmo}</span>
          </div>
        </div>
        <button
          onClick={onReload}
          className="p-2 rounded bg-slate-800 border border-slate-600 hover:bg-slate-700 text-amber-400 transition-colors"
          title="Reload weapon [R]"
          aria-label="Reload weapon"
        >
          <RotateCcw className="w-5 h-5" />
        </button>
      </div>

      {/* 6. MOBILE TOUCH CONTROLS (Floating Joystick & Tactical Action Buttons) */}
      {isTouchDevice && (
        <>
          {/* Tactical Peek Controls (Left & Right Lean) */}
          <div className="absolute bottom-64 left-6 flex items-center gap-3 pointer-events-auto z-20">
            {/* Peek Left (بيك يسار) */}
            <button
              onTouchStart={(e) => {
                e.stopPropagation();
                onPeekChange('left');
              }}
              onTouchEnd={(e) => {
                e.stopPropagation();
                onPeekChange('center');
              }}
              onClick={() => onPeekChange(peekState === 'left' ? 'center' : 'left')}
              className={`w-14 h-12 rounded-xl border-2 flex flex-col items-center justify-center shadow-lg transition-all cursor-pointer ${
                peekState === 'left'
                  ? 'bg-cyan-500/90 border-cyan-300 text-white shadow-[0_0_15px_rgba(6,182,212,0.6)] scale-105'
                  : 'bg-[#0f172a]/85 border-slate-600 text-slate-300 active:bg-cyan-600/50'
              }`}
              aria-label="Peek Left"
              title="Peek Left [Q]"
            >
              <span className="text-sm font-black font-tactical tracking-wider leading-none">⮜ Q</span>
              <span className="text-[9px] font-bold text-slate-200 mt-0.5 leading-none">بيك يسار</span>
            </button>

            {/* Peek Right (بيك يمين) */}
            <button
              onTouchStart={(e) => {
                e.stopPropagation();
                onPeekChange('right');
              }}
              onTouchEnd={(e) => {
                e.stopPropagation();
                onPeekChange('center');
              }}
              onClick={() => onPeekChange(peekState === 'right' ? 'center' : 'right')}
              className={`w-14 h-12 rounded-xl border-2 flex flex-col items-center justify-center shadow-lg transition-all cursor-pointer ${
                peekState === 'right'
                  ? 'bg-cyan-500/90 border-cyan-300 text-white shadow-[0_0_15px_rgba(6,182,212,0.6)] scale-105'
                  : 'bg-[#0f172a]/85 border-slate-600 text-slate-300 active:bg-cyan-600/50'
              }`}
              aria-label="Peek Right"
              title="Peek Right [E]"
            >
              <span className="text-sm font-black font-tactical tracking-wider leading-none">E ⮞</span>
              <span className="text-[9px] font-bold text-slate-200 mt-0.5 leading-none">بيك يمين</span>
            </button>
          </div>

          {/* Left Joystick Area */}
          <div
            className="absolute bottom-24 left-6 w-36 h-36 rounded-full border-2 border-white/20 bg-slate-950/40 flex items-center justify-center pointer-events-auto touch-none"
            ref={joystickBaseRef}
            onTouchStart={handleJoystickTouchStart}
            onTouchMove={handleJoystickTouchMove}
            onTouchEnd={handleJoystickTouchEnd}
            onTouchCancel={handleJoystickTouchEnd}
          >
            <div
              ref={joystickKnobRef}
              className="w-14 h-14 rounded-full bg-cyan-500/60 border-2 border-cyan-300/80 shadow-lg pointer-events-none"
            />
          </div>

          {/* ENTIRE RIGHT HALF TOUCH LOOK AREA (100% of Right Side: Top to Bottom) */}
          <div
            className="absolute inset-y-0 right-0 w-[55vw] pointer-events-auto touch-none select-none z-10"
            onTouchStart={handleLookTouchStart}
            onTouchMove={handleLookTouchMove}
            onTouchEnd={handleLookTouchEnd}
            onTouchCancel={handleLookTouchEnd}
          />

          {/* Right Action Touch Buttons */}
          <div className="absolute bottom-24 right-6 flex flex-col gap-3 pointer-events-auto z-20">
            <div className="flex items-center gap-3">
              {/* ADS / Aim Scope Button */}
              <button
                onTouchStart={(e) => {
                  e.stopPropagation();
                  onAimToggle();
                }}
                onClick={onAimToggle}
                className={`w-14 h-14 rounded-full border-2 flex items-center justify-center shadow-2xl transition-all cursor-pointer ${
                  isAiming
                    ? 'bg-amber-500/80 border-amber-300 text-white scale-105'
                    : 'bg-[#111827]/80 border-slate-500 text-slate-300'
                }`}
                aria-label="Aim Down Sights"
              >
                <Crosshair className="w-7 h-7" />
              </button>

              {/* Jump Button */}
              <button
                onTouchStart={(e) => {
                  e.stopPropagation();
                  onJump();
                }}
                onClick={onJump}
                className="w-14 h-14 rounded-full bg-[#111827]/80 border-2 border-slate-500 text-slate-200 flex items-center justify-center shadow-xl active:scale-95 active:bg-blue-600/80 transition-all cursor-pointer"
                aria-label="Jump"
              >
                <ChevronUp className="w-8 h-8" />
              </button>
            </div>

            <div className="flex items-center gap-3 justify-end">
              {/* Crouch Button */}
              <button
                onTouchStart={(e) => {
                  e.stopPropagation();
                  onCrouchToggle();
                }}
                onClick={onCrouchToggle}
                className="w-13 h-13 rounded-full bg-[#111827]/80 border-2 border-slate-500 text-slate-200 flex items-center justify-center shadow-xl active:scale-95 transition-all text-xs font-tactical font-bold cursor-pointer"
                aria-label="Crouch"
              >
                CROUCH
              </button>

              {/* Primary Fire Button (Large Arcade Trigger with Drag-to-Aim) */}
              <button
                onTouchStart={handleFireTouchStart}
                onTouchMove={handleFireTouchMove}
                onTouchEnd={handleFireTouchEnd}
                onTouchCancel={handleFireTouchEnd}
                onMouseDown={onFireDown}
                onMouseUp={onFireUp}
                onClick={() => {
                  onFireDown();
                  setTimeout(onFireUp, 100);
                }}
                className="w-20 h-20 rounded-full bg-red-600/90 border-4 border-red-400 text-white flex items-center justify-center shadow-[0_0_20px_rgba(239,68,68,0.6)] active:scale-95 active:bg-red-700 transition-all cursor-pointer"
                aria-label="Fire Weapon"
              >
                <div className="w-10 h-10 rounded-full border-2 border-white/80 flex items-center justify-center">
                  <div className="w-4 h-4 bg-white rounded-full" />
                </div>
              </button>
            </div>
          </div>
        </>
      )}

      {/* Desktop Keybind Hints banner (hidden on pure touch devices) */}
      {!isTouchDevice && (
        <div className="absolute bottom-2 inset-x-0 flex justify-center pointer-events-none">
          <div className="bg-[#0b0f19]/70 px-4 py-1 rounded text-[11px] font-tactical text-slate-400 border border-slate-800">
            [WASD] Move · [Q/E] Peek L/R · [Mouse] Look · [L-Click] Fire · [R-Click] ADS · [Space] Jump · [C] Crouch · [R] Reload · [Esc] Pause
          </div>
        </div>
      )}
    </div>
  );
};
