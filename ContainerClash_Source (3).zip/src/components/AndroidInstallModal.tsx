import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Smartphone, Copy, Check, ExternalLink, QrCode, Play, Sparkles, Download } from 'lucide-react';
import { soundEngine } from '../game/audio.ts';

interface AndroidInstallModalProps {
  onClose: () => void;
  onLaunchBotMatch: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  onClose,
  onLaunchBotMatch,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'install_guide' | 'qr_code' | 'zip_guide'>('install_guide');

  // Real live URL for this deployed applet
  const liveUrl =
    typeof window !== 'undefined' && window.location.origin.includes('ais-')
      ? window.location.origin
      : 'https://ais-pre-s2ajrsqo4h7avmlah2xgzp-929388176229.europe-west2.run.app';

  useEffect(() => {
    QRCode.toDataURL(liveUrl, {
      width: 260,
      margin: 1.5,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error('Failed to generate QR code', err));
  }, [liveUrl]);

  const handleCopyLink = () => {
    soundEngine.playUiClick();
    navigator.clipboard.writeText(liveUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/85 backdrop-blur-md pointer-events-auto select-none" dir="rtl">
      <div className="w-full max-w-2xl bg-[#0d1322] border-2 border-emerald-500/80 rounded-xl shadow-[0_0_40px_rgba(16,185,129,0.25)] flex flex-col max-h-[92vh] overflow-hidden text-right">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-[#080d18] px-5 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/20 border border-emerald-500/50 text-emerald-400">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-heading text-2xl md:text-3xl text-white tracking-wide">
                تشغيل وتثبيت اللعبة على هاتف الأندرويد
              </h2>
              <p className="text-xs text-emerald-400 font-tactical">
                CONTAINER CLASH 3D FPS · إصدار الأندرويد والشاشات الذكية
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onClose();
            }}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 text-xl transition-colors"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center border-b border-slate-800 bg-[#0a0f1d] px-5 gap-2">
          <button
            onClick={() => {
              soundEngine.playUiClick();
              setActiveTab('install_guide');
            }}
            className={`flex items-center gap-2 py-3 px-4 border-b-2 font-heading text-lg transition-colors ${
              activeTab === 'install_guide'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>خطوات التشغيل والتثبيت</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playUiClick();
              setActiveTab('qr_code');
            }}
            className={`flex items-center gap-2 py-3 px-4 border-b-2 font-heading text-lg transition-colors ${
              activeTab === 'qr_code'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>مسح الرمز (QR Code)</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playUiClick();
              setActiveTab('zip_guide');
            }}
            className={`flex items-center gap-2 py-3 px-4 border-b-2 font-heading text-lg transition-colors ${
              activeTab === 'zip_guide'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>تحميل ملف ZIP للأندرويد</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 md:p-6 overflow-y-auto flex-1 flex flex-col gap-5 text-slate-200">
          {activeTab === 'install_guide' ? (
            <>
              {/* Clarification for the 5MB file in user screenshot */}
              <div className="p-4 rounded-lg bg-amber-950/40 border border-amber-500/50 text-amber-200 flex flex-col gap-2">
                <div className="flex items-center gap-2 font-heading text-lg text-amber-400">
                  <Sparkles className="w-5 h-5" />
                  <span>تعديلات الاستقامة وسلاسة الكاميرا المطبقة الآن:</span>
                </div>
                <p className="text-xs md:text-sm text-slate-300 leading-relaxed font-sans">
                  ✓ <strong>استقامة الرؤية 100%:</strong> تم حل مشكلة ميلان الشاشة وضبط أفق الرؤية ليكون مستوياً وطبيعياً تماماً.
                  <br />
                  ✓ <strong>تثبيت الكاميرا:</strong> تم عزل حركة اللمس وحذف الاهتزاز المفاجئ أثناء الجري وإطلاق النار.
                  <br />
                  ✓ <strong>واقعية السلاح:</strong> تمت إضافة كاتم صوت تكتيكي مع حلقات تبريد، ومقبض أمامي بزاوية (AFG)، ومنظار هولوجرافي (EOTech) مع نقطة ليزر حمراء ومخزن P-MAG مفصل.
                </p>
              </div>

              {/* Method 1: The Best Method (PWA / WebAPK) */}
              <div className="p-5 rounded-lg bg-slate-900/90 border border-emerald-500/40 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                      1
                    </span>
                    <h3 className="font-heading text-xl text-emerald-300">
                      الطريقة المباشرة (WebAPK): تثبيت أيقونة اللعبة على هاتفك بدون لابتوب
                    </h3>
                  </div>
                  <span className="text-[11px] bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-800">
                    أسهل وأسرع طريقة
                  </span>
                </div>

                <div className="text-xs md:text-sm text-slate-300 space-y-2 font-sans pr-2">
                  <p>1. افتح متصفح <strong>Google Chrome</strong> على هاتفك الأندرويد.</p>
                  <p>2. افتح رابط اللعبة الموضح بالأسفل.</p>
                  <p>3. اضغط على قائمة الخيارات في كروم (<strong>النقاط الثلاث ⋮ في أعلى الزاوية</strong>).</p>
                  <p>4. اضغط على <strong>"تثبيت التطبيق" (Install app)</strong> أو <strong>"إضافة إلى الشاشة الرئيسية"</strong>.</p>
                  <p className="text-emerald-400 font-semibold">
                    ✓ يقوم نظام أندرويد تلقائياً بإنشاء وتثبيت تطبيق كامل على هاتفك يعمل بملء الشاشة 60 FPS بدون متصفح!
                  </p>
                </div>
              </div>

              {/* Copy Direct Link Section */}
              <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3">
                <div className="flex flex-col text-right w-full md:w-auto">
                  <span className="text-xs text-slate-400 font-tactical">رابط اللعبة المباشر لهاتفك:</span>
                  <span className="font-mono text-xs text-cyan-300 select-all truncate max-w-sm" dir="ltr">
                    {liveUrl}
                  </span>
                </div>

                <button
                  onClick={handleCopyLink}
                  className="w-full md:w-auto px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-heading text-lg flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg"
                >
                  {copied ? <Check className="w-5 h-5 text-white" /> : <Copy className="w-5 h-5" />}
                  <span>{copied ? 'تم نسخ الرابط!' : 'نسخ الرابط المباشر'}</span>
                </button>
              </div>
            </>
          ) : activeTab === 'zip_guide' ? (
            /* ZIP Download & Mobile Converter Guide */
            <div className="flex flex-col gap-4">
              <div className="p-4 bg-emerald-950/60 border border-emerald-500/80 rounded-lg flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-300 font-heading text-xl">
                    <Download className="w-5 h-5 text-emerald-400" />
                    <span>تحميل مشروع APK كامل مجهز بـ Capacitor (ملف ZIP)</span>
                  </div>
                  <span className="text-xs bg-emerald-800 text-emerald-200 px-2.5 py-0.5 rounded font-tactical">جاهز للأندرويد</span>
                </div>
                <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
                  يحتوي على: مجلد <code>android/</code> كاملاً مع Gradle و AndroidManifest، إعدادات <code>capacitor.config.ts</code>، وملف البناء السحابي التلقائي <code>.github/workflows/build-android.yml</code>، وكامل أصول اللعبة المحلية.
                </p>
                <a
                  href="/download/source.zip"
                  download="ContainerClash_Source.zip"
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-lg text-white font-heading text-xl text-center flex items-center justify-center gap-2 border border-emerald-400 shadow-md active:scale-95 transition-all cursor-pointer"
                >
                  <Download className="w-6 h-6" />
                  <span>تنزيل ملف ZIP الكامل إلى هاتفك الآن</span>
                </a>
              </div>

              {/* GitHub Actions Cloud Build Instructions */}
              <div className="p-4 bg-slate-900 border border-cyan-500/50 rounded-lg flex flex-col gap-2.5 text-slate-300 text-xs md:text-sm font-sans leading-relaxed">
                <h4 className="font-heading text-lg text-cyan-400 flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  <span>كيف تبني ملف APK من هاتفك مجاناً عبر GitHub Actions (بدون لابتوب):</span>
                </h4>
                <p>
                  1. <strong>فك ضغط الملف:</strong> استخدم تطبيق <strong>ZArchiver</strong> لفك ضغط <code>ContainerClash_Source.zip</code>.
                </p>
                <p>
                  2. <strong>افتح GitHub من متصفح هاتفك:</strong> ادخل على <strong className="text-white">github.com</strong> وأنشئ مستودعاً جديداً باسم <code>ContainerClash</code>.
                </p>
                <p>
                  3. <strong>ارفع الملفات:</strong> اضغط <strong>Upload files</strong> وارفع مجلدات المشروع (تأكد من شمول مجلد <code>.github</code> و <code>android</code>).
                </p>
                <p>
                  4. <strong>استلم ملف APK:</strong> بمجرد رفع الملفات، سيبدأ GitHub ببناء التطبيق تلقائياً! اضغط على تبويب <strong>Actions</strong>، ثم حمّل ملف <strong>ContainerClash-Android-Debug-APK</strong> وثبّته مباشرة على هاتفك!
                </p>
              </div>
            </div>
          ) : (
            /* QR Code Tab */
            <div className="flex flex-col items-center justify-center py-6 gap-5 text-center">
              <p className="text-sm text-slate-300 max-w-md">
                وجّه كاميرا هاتفك الأندرويد نحو الرمز أدناه ليتم فتح وتثبيت اللعبة مباشرة على هاتفك:
              </p>

              {qrDataUrl ? (
                <div className="p-4 bg-white rounded-xl shadow-2xl border-4 border-emerald-500">
                  <img src={qrDataUrl} alt="Container Clash QR Code" className="w-56 h-56" />
                </div>
              ) : (
                <div className="w-56 h-56 bg-slate-800 rounded-xl flex items-center justify-center text-slate-400 text-xs">
                  جاري تجهيز الرمز...
                </div>
              )}

              <div className="flex items-center gap-2 text-xs font-mono text-slate-400 bg-slate-900 px-4 py-2 rounded-lg border border-slate-800" dir="ltr">
                <span>{liveUrl}</span>
              </div>

              <button
                onClick={handleCopyLink}
                className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-heading text-lg flex items-center gap-2 transition-all active:scale-95"
              >
                {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                <span>{copied ? 'تم نسخ الرابط!' : 'نسخ الرابط'}</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 bg-[#080d18] p-4 flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-400 font-tactical">
            CONTAINER CLASH · 1v1 ARCADE SHOOTER
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              onClick={() => {
                soundEngine.playUiClick();
                onLaunchBotMatch();
              }}
              className="flex-1 md:flex-initial px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-heading text-lg flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <Play className="w-5 h-5" />
              <span>ابدأ اللعب الآن</span>
            </button>

            <button
              onClick={() => {
                soundEngine.playUiClick();
                onClose();
              }}
              className="px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-heading text-lg transition-colors"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
