import React from 'react';
import { Trophy, Skull, RotateCcw, Home, Target, Zap } from 'lucide-react';
import { PlayerStats, calculateAccuracy } from '../game/rules.ts';
import { soundEngine } from '../game/audio.ts';

interface MatchEndModalProps {
  isVictory: boolean;
  blueScore: number;
  redScore: number;
  playerStats: PlayerStats;
  onRematch: () => void;
  onReturnToMenu: () => void;
}

export const MatchEndModal: React.FC<MatchEndModalProps> = ({
  isVictory,
  blueScore,
  redScore,
  playerStats,
  onRematch,
  onReturnToMenu,
}) => {
  const accuracy = calculateAccuracy(playerStats.shotsFired, playerStats.shotsHit);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm select-none pointer-events-auto animate-fade-in">
      <div className="w-full max-w-md bg-[#0d131f] border border-slate-700 rounded-lg p-6 shadow-2xl flex flex-col gap-6 text-center">
        {/* Banner */}
        <div className="flex flex-col items-center gap-2">
          {isVictory ? (
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-amber-400">
              <Trophy className="w-8 h-8" />
            </div>
          ) : (
            <div className="w-16 h-16 rounded-full bg-red-600/20 border-2 border-red-500 flex items-center justify-center text-red-500">
              <Skull className="w-8 h-8" />
            </div>
          )}

          <h2
            className={`font-heading text-6xl tracking-wider ${
              isVictory ? 'text-amber-400 drop-shadow-[0_0_20px_rgba(251,191,36,0.5)]' : 'text-red-500'
            }`}
          >
            {isVictory ? 'VICTORY' : 'DEFEAT'}
          </h2>

          <div className="flex items-center gap-4 text-2xl font-heading text-white">
            <span className="text-blue-400">BLUE: {blueScore}</span>
            <span className="text-slate-500">VS</span>
            <span className="text-red-400">RED: {redScore}</span>
          </div>
        </div>

        {/* Combat Stats Grid */}
        <div className="grid grid-cols-2 gap-3 p-4 bg-slate-900/80 border border-slate-800 rounded-md text-left font-tactical">
          <div className="flex flex-col">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Target className="w-3.5 h-3.5 text-blue-400" /> ELIMINATIONS
            </span>
            <span className="text-2xl font-bold text-white tabular-nums">{playerStats.kills}</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Skull className="w-3.5 h-3.5 text-red-400" /> DEATHS
            </span>
            <span className="text-2xl font-bold text-white tabular-nums">{playerStats.deaths}</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" /> ACCURACY
            </span>
            <span className="text-2xl font-bold text-white tabular-nums">{accuracy}%</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Target className="w-3.5 h-3.5 text-emerald-400" /> HEADSHOTS
            </span>
            <span className="text-2xl font-bold text-white tabular-nums">{playerStats.headshots}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onRematch();
            }}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-md bg-blue-600 hover:bg-blue-500 text-white font-heading text-xl tracking-wider active:scale-95 transition-all"
          >
            <RotateCcw className="w-5 h-5" />
            <span>REMATCH</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playUiClick();
              onReturnToMenu();
            }}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 font-heading text-xl tracking-wider active:scale-95 transition-all"
          >
            <Home className="w-5 h-5" />
            <span>MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
