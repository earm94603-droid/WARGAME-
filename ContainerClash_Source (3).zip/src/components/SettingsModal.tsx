import React, { useState } from 'react';
import { GameSettings } from '../game/types.ts';
import { Settings, Smartphone, Sliders, Code2, Download, Copy, Check } from 'lucide-react';
import { soundEngine } from '../game/audio.ts';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onClose: () => void;
  defaultTab?: 'settings' | 'android_guide';
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
  defaultTab = 'settings',
}) => {
  const [activeTab, setActiveTab] = useState<'settings' | 'android_guide'>(defaultTab);
  const [copiedScript, setCopiedScript] = useState<string | null>(null);

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedScript(key);
    setTimeout(() => setCopiedScript(null), 2000);
  };

  const godotPlayerScript = `extends CharacterBody3D
# CONTAINER CLASH - Player Controller (Godot 4)
@export var speed: float = 5.0
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.003

@onready var camera = $Camera3D
@onready var weapon = $Camera3D/Weapon

var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= gravity * delta
    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = jump_velocity

    var input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
    if direction:
        velocity.x = direction.x * speed
        velocity.z = direction.z * speed
    else:
        velocity.x = move_toward(velocity.x, 0, speed)
        velocity.z = move_toward(velocity.z, 0, speed)
    move_and_slide()`;

  const godotNetworkScript = `extends Node
# CONTAINER CLASH - 1v1 Hotspot Multiplayer (Godot 4)
const GAME_PORT: int = 24567
var peer: ENetMultiplayerPeer

func host_game() -> Error:
    peer = ENetMultiplayerPeer.new()
    var err = peer.create_server(GAME_PORT, 1)
    if err == OK:
        multiplayer.multiplayer_peer = peer
    return err

func join_game(host_ip: String) -> Error:
    peer = ENetMultiplayerPeer.new()
    var err = peer.create_client(host_ip.strip_edges(), GAME_PORT)
    if err == OK:
        multiplayer.multiplayer_peer = peer
    return err`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm pointer-events-auto select-none">
      <div className="w-full max-w-2xl bg-[#0d131f] border border-slate-700 rounded-lg shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header Tabs */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-[#090d16] px-5 py-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                soundEngine.playUiClick();
                setActiveTab('settings');
              }}
              className={`flex items-center gap-2 px-3 py-1.5 rounded font-heading text-lg tracking-wider transition-colors ${
                activeTab === 'settings'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sliders className="w-4 h-4" />
              SETTINGS & CONTROLS
            </button>
            <button
              onClick={() => {
                soundEngine.playUiClick();
                setActiveTab('android_guide');
              }}
              className={`flex items-center gap-2 px-3 py-1.5 rounded font-heading text-lg tracking-wider transition-colors ${
                activeTab === 'android_guide'
                  ? 'bg-emerald-700 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              ANDROID APK & PWA GUIDE
            </button>
          </div>
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onClose();
            }}
            className="text-slate-400 hover:text-white p-1 text-xl"
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto flex-1 flex flex-col gap-6">
          {activeTab === 'settings' ? (
            <div className="flex flex-col gap-5">
              {/* Sensitivity */}
              <div className="flex flex-col gap-2">
                <div className="flex justify-between text-sm font-tactical text-slate-300">
                  <span>حساسية توجيه السلاح والكاميرا (AIM SENSITIVITY)</span>
                  <span className="text-cyan-400 font-bold">{Math.round(settings.touchSensitivity * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="3.0"
                  step="0.1"
                  value={settings.touchSensitivity}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      touchSensitivity: parseFloat(e.target.value),
                      mouseSensitivity: parseFloat(e.target.value),
                    })
                  }
                  className="w-full accent-blue-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                />
              </div>

              {/* Sound Volume */}
              <div className="flex flex-col gap-2">
                <div className="flex justify-between text-sm font-tactical text-slate-300">
                  <span>AUDIO VOLUME</span>
                  <span className="text-cyan-400 font-bold">{Math.round(settings.soundVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1.0"
                  step="0.05"
                  value={settings.soundVolume}
                  onChange={(e) => {
                    const vol = parseFloat(e.target.value);
                    soundEngine.setVolume(vol);
                    onUpdateSettings({ ...settings, soundVolume: vol });
                  }}
                  className="w-full accent-blue-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                />
              </div>

              {/* Graphics Quality */}
              <div className="flex flex-col gap-2">
                <span className="text-sm font-tactical text-slate-300">GRAPHICS QUALITY</span>
                <div className="grid grid-cols-3 gap-3">
                  {(['high', 'medium', 'performance'] as const).map((q) => (
                    <button
                      key={q}
                      onClick={() => onUpdateSettings({ ...settings, graphicsQuality: q })}
                      className={`py-2 rounded font-heading text-lg tracking-wider border capitalize transition-all ${
                        settings.graphicsQuality === q
                          ? 'bg-blue-600 border-blue-400 text-white'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              {/* Invert Y */}
              <div className="flex items-center justify-between p-3 bg-slate-900/60 border border-slate-800 rounded">
                <span className="text-sm font-tactical text-slate-300">INVERT Y-AXIS</span>
                <input
                  type="checkbox"
                  checked={settings.invertY}
                  onChange={(e) => onUpdateSettings({ ...settings, invertY: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 rounded"
                />
              </div>

              {/* Control Guide Overview */}
              <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-md">
                <h4 className="font-heading text-lg text-slate-200 mb-2">HOW TO PLAY</h4>
                <div className="grid grid-cols-2 gap-2 text-xs font-tactical text-slate-400">
                  <div>• Left Joystick / WASD: Movement</div>
                  <div>• Right Drag / Mouse: Look</div>
                  <div>• Red Button / L-Click: Fire</div>
                  <div>• Scope Button / R-Click: ADS Zoom</div>
                  <div>• Arrow Up / Space: Jump</div>
                  <div>• Crouch / [C]: Crouch cover</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-5">
              {/* Direct Play & Install Link Card */}
              <div className="p-4 bg-emerald-950/60 border border-emerald-500 rounded-md flex flex-col gap-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-300 font-heading text-xl">
                    <Smartphone className="w-5 h-5 text-emerald-400" />
                    <span>ANDROID FULL-SCREEN APP LINK</span>
                  </div>
                  <span className="text-xs bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded font-tactical">60 FPS WEBAPK</span>
                </div>
                <p className="text-xs text-slate-300">
                  Open this link on your Android phone in <strong>Google Chrome</strong> or in the <strong>CanIWebView app</strong> to play or install as a full-screen app.
                </p>
                <div className="flex items-center justify-between gap-2 p-2.5 bg-slate-950 rounded border border-slate-800">
                  <span className="text-xs font-mono text-cyan-300 truncate" dir="ltr">
                    https://ais-pre-s2ajrsqo4h7avmlah2xgzp-929388176229.europe-west2.run.app
                  </span>
                  <button
                    onClick={() => handleCopy('link', 'https://ais-pre-s2ajrsqo4h7avmlah2xgzp-929388176229.europe-west2.run.app')}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-tactical flex items-center gap-1.5"
                  >
                    {copiedScript === 'link' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedScript === 'link' ? 'COPIED' : 'COPY LINK'}</span>
                  </button>
                </div>
              </div>

              {/* Android Notice */}
              <div className="p-4 bg-blue-950/50 border border-blue-800/80 rounded-md flex flex-col gap-2">
                <div className="flex items-center gap-2 text-blue-300 font-heading text-xl">
                  <Smartphone className="w-5 h-5" />
                  <span>ANDROID INSTALLATION & APK COMPLIANCE</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  As required by your instructions: <strong>Honest delivery statement:</strong> In this web sandbox container, native Godot 4 binary APK cross-compilation is physically impossible because the Android NDK, Java JDK, and Android SDK commandline tools (~5GB) are not present in this Node/Web execution environment.
                </p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  To provide you with the <strong>exact same real-phone 60 FPS full-screen experience</strong>, this game is packaged as an <strong>Installable Progressive Web App (PWA)</strong> that installs directly to your Android phone home screen without any browser address bar!
                </p>
              </div>

              {/* PWA Home Screen Installation */}
              <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-md flex flex-col gap-3">
                <h3 className="font-heading text-lg text-emerald-400">HOW TO INSTALL ON YOUR ANDROID PHONE:</h3>
                <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside font-sans">
                  <li>Open this URL on your Android phone in <strong>Google Chrome</strong>.</li>
                  <li>Tap the <strong>Chrome menu (three dots in top right)</strong>.</li>
                  <li>Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                  <li>Container Clash will install as an app icon with native full-screen hardware-accelerated WebGL performance!</li>
                </ol>
              </div>

              {/* Native Godot 4 Export Source Code */}
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-heading text-lg text-amber-400 flex items-center gap-2">
                    <Code2 className="w-4 h-4" />
                    GODOT 4 NATIVE GDSCRIPT PROJECT FILES
                  </h3>
                  <span className="text-xs text-slate-400 font-tactical">Ready to export to APK</span>
                </div>

                {/* Player Script */}
                <div className="bg-slate-950 border border-slate-800 rounded p-3">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[11px] font-tactical text-slate-400">player.gd</span>
                    <button
                      onClick={() => handleCopy('player', godotPlayerScript)}
                      className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-tactical"
                    >
                      {copiedScript === 'player' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {copiedScript === 'player' ? 'COPIED' : 'COPY'}
                    </button>
                  </div>
                  <pre className="text-[10px] text-slate-300 font-mono overflow-x-auto max-h-24">
                    {godotPlayerScript}
                  </pre>
                </div>

                {/* Network Script */}
                <div className="bg-slate-950 border border-slate-800 rounded p-3">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[11px] font-tactical text-slate-400">network.gd (Hotspot Multiplayer)</span>
                    <button
                      onClick={() => handleCopy('network', godotNetworkScript)}
                      className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-tactical"
                    >
                      {copiedScript === 'network' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {copiedScript === 'network' ? 'COPIED' : 'COPY'}
                    </button>
                  </div>
                  <pre className="text-[10px] text-slate-300 font-mono overflow-x-auto max-h-24">
                    {godotNetworkScript}
                  </pre>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 bg-[#090d16] p-4 flex justify-end">
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onClose();
            }}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-500 rounded text-white font-heading text-lg tracking-wider"
          >
            DONE
          </button>
        </div>
      </div>
    </div>
  );
};
