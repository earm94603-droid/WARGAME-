import React, { useState } from 'react';
import { Play, Users, Settings, Smartphone, Volume2, VolumeX, Shield, Wifi, Globe, Copy, Check, Download } from 'lucide-react';
import { soundEngine } from '../game/audio.ts';

interface TitleScreenProps {
  onStartBotMatch: () => void;
  onHostMultiplayer: () => void;
  onJoinMultiplayer: (roomCode: string) => void;
  onOpenSettings: () => void;
  onOpenAndroidGuide: () => void;
  isConnecting: boolean;
  networkRoomCode: string | null;
  networkError: string | null;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartBotMatch,
  onHostMultiplayer,
  onJoinMultiplayer,
  onOpenSettings,
  onOpenAndroidGuide,
  isConnecting,
  networkRoomCode,
  networkError,
}) => {
  const [showMultiplayerModal, setShowMultiplayerModal] = useState(false);
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [isMuted, setIsMuted] = useState(soundEngine.getMuted());
  const [copied, setCopied] = useState(false);

  const handleMuteToggle = () => {
    const muted = soundEngine.toggleMute();
    setIsMuted(muted);
  };

  const handleCopyLink = () => {
    if (networkRoomCode) {
      const url = `${window.location.origin}?join=${networkRoomCode}`;
      navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="absolute inset-0 flex flex-col justify-between p-6 pointer-events-auto z-30 select-none bg-gradient-to-t from-[#0b0f19] via-[#0b0f19]/60 to-transparent">
      {/* Top Bar with Audio & Version */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 px-3 py-1 bg-black/60 border border-slate-700/80 rounded-md">
          <Shield className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-tactical text-slate-300 tracking-wider">CRTE MIL-SPEC v1.0.4</span>
        </div>

        <button
          onClick={handleMuteToggle}
          className="p-2.5 rounded-md bg-black/60 border border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          title="Toggle Audio"
          aria-label="Toggle Audio"
        >
          {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-cyan-400" />}
        </button>
      </div>

      {/* Center Title Lockup */}
      <div className="flex flex-col items-center justify-center my-auto text-center">
        {/* Decorative tactical emblem */}
        <div className="mb-2 flex items-center gap-2 px-4 py-1 rounded bg-amber-500/20 border border-amber-500/40 text-amber-400 font-tactical text-xs tracking-widest uppercase">
          Tactical 1v1 Operative
        </div>

        <h1 className="font-heading text-7xl md:text-9xl font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-200 to-slate-400 drop-shadow-[0_8px_16px_rgba(0,0,0,0.9)]">
          CONTAINER CLASH
        </h1>

        <p className="max-w-md text-sm md:text-base text-slate-300 font-sans tracking-wide mt-1 drop-shadow">
          Fast-paced industrial container yard shootouts. Outmaneuver and eliminate the opposing operative.
        </p>

        {/* Primary Action Menu */}
        <div className="flex flex-col gap-3 mt-8 w-full max-w-xs">
          {/* Play Against Bot */}
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onStartBotMatch();
            }}
            className="group relative flex items-center justify-center gap-3 px-6 py-4 rounded-md bg-gradient-to-r from-blue-700 to-blue-600 hover:from-blue-600 hover:to-blue-500 text-white font-heading text-2xl tracking-wider shadow-[0_0_25px_rgba(37,99,235,0.4)] border border-blue-400/50 active:scale-95 transition-all"
          >
            <Play className="w-6 h-6 fill-white" />
            <span>PLAY AGAINST BOT</span>
          </button>

          {/* Play With Friend (1v1) */}
          <button
            onClick={() => {
              soundEngine.playUiClick();
              setShowMultiplayerModal(true);
            }}
            className="flex items-center justify-center gap-3 px-6 py-3.5 rounded-md bg-slate-900/90 hover:bg-slate-800 text-slate-200 font-heading text-xl tracking-wider border border-slate-700 active:scale-95 transition-all"
          >
            <Users className="w-5 h-5 text-amber-400" />
            <span>PLAY WITH FRIEND (1v1)</span>
          </button>

          {/* Settings & Controls */}
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onOpenSettings();
            }}
            className="flex items-center justify-center gap-3 px-6 py-2.5 rounded-md bg-slate-950/70 hover:bg-slate-900 text-slate-400 hover:text-white font-tactical text-xs tracking-wider border border-slate-800 active:scale-95 transition-all"
          >
            <Settings className="w-4 h-4" />
            <span>SETTINGS & CONTROLS</span>
          </button>

          {/* Android Mobile Install & Play Guide */}
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onOpenAndroidGuide();
            }}
            className="group relative flex items-center justify-center gap-3 px-6 py-3.5 rounded-md bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-500 text-white font-heading text-xl tracking-wider border border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.35)] active:scale-95 transition-all text-center cursor-pointer"
          >
            <Smartphone className="w-5 h-5 text-emerald-200 animate-pulse" />
            <span>📱 تشغيل وتثبيت اللعبة على هاتف الأندرويد</span>
          </button>

          {/* Download Full Source ZIP button */}
          <a
            href="/download/source.zip"
            download="ContainerClash_Source.zip"
            onClick={() => soundEngine.playUiClick()}
            className="flex items-center justify-center gap-2 px-6 py-2 rounded-md bg-slate-900/90 hover:bg-slate-800 text-emerald-300 font-tactical text-xs tracking-wider border border-emerald-700/60 active:scale-95 transition-all text-center"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>تحميل ملف المشروع الكامل (ZIP جاهز · 5.3 MB)</span>
          </a>
        </div>
      </div>

      {/* Bottom Info Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between text-slate-400 text-xs font-tactical gap-2">
        <div>1v1 TACTICAL SHOOTER · THREE.JS PBR ENGINE</div>
        <div>WASD MOVE · CLICK SHOOT · SPACE JUMP · TOUCH ENABLED</div>
      </div>

      {/* MULTIPLAYER LOBBY MODAL */}
      {showMultiplayerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#0d131f] border border-slate-700 rounded-lg p-6 shadow-2xl flex flex-col gap-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Wifi className="w-5 h-5 text-amber-400" />
                <h2 className="font-heading text-2xl text-white tracking-wide">1v1 LOCAL & HOTSPOT MULTIPLAYER</h2>
              </div>
              <button
                onClick={() => setShowMultiplayerModal(false)}
                className="text-slate-400 hover:text-white text-lg p-1"
              >
                ✕
              </button>
            </div>

            {networkError && (
              <div className="p-3 bg-red-950/60 border border-red-800 rounded text-red-200 text-xs font-tactical">
                {networkError}
              </div>
            )}

            {/* Host Game Section */}
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-md flex flex-col gap-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">1</span>
                <span className="font-heading text-lg text-white">PHONE A: HOST GAME</span>
              </div>
              <p className="text-xs text-slate-400">
                Turn on your Wi-Fi hotspot or connect to the same Wi-Fi network, then host a match room.
              </p>

              {networkRoomCode ? (
                <div className="p-3 bg-blue-950/60 border border-blue-800 rounded flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-blue-300 font-tactical">ROOM CODE:</span>
                    <span className="font-heading text-3xl text-cyan-400 font-bold tracking-widest">{networkRoomCode}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-400 truncate">
                      Share link with Phone B
                    </span>
                    <button
                      onClick={handleCopyLink}
                      className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 rounded text-xs text-white font-tactical flex items-center gap-1"
                    >
                      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copied ? 'COPIED' : 'COPY'}
                    </button>
                  </div>
                  <div className="text-xs text-amber-300 flex items-center gap-1.5 animate-pulse mt-1">
                    <div className="w-2 h-2 rounded-full bg-amber-400" />
                    Waiting for Phone B to join...
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => {
                    soundEngine.playUiClick();
                    onHostMultiplayer();
                  }}
                  disabled={isConnecting}
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 rounded text-white font-heading text-lg tracking-wider disabled:opacity-50 transition-colors"
                >
                  {isConnecting ? 'CREATING ROOM...' : 'HOST MATCH ROOM'}
                </button>
              )}
            </div>

            {/* Join Game Section */}
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-md flex flex-col gap-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center text-xs font-bold">2</span>
                <span className="font-heading text-lg text-white">PHONE B: JOIN GAME</span>
              </div>
              <p className="text-xs text-slate-400">
                Connect to Phone A's hotspot or Wi-Fi, then enter the 4-letter room code.
              </p>

              <div className="flex gap-2">
                <input
                  type="text"
                  maxLength={6}
                  placeholder="CODE (e.g. SYNC)"
                  value={joinCodeInput}
                  onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                  className="flex-1 bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white font-heading text-xl tracking-widest uppercase focus:outline-none focus:border-amber-400"
                />
                <button
                  onClick={() => {
                    soundEngine.playUiClick();
                    if (joinCodeInput.trim()) {
                      onJoinMultiplayer(joinCodeInput.trim());
                    }
                  }}
                  disabled={!joinCodeInput.trim() || isConnecting}
                  className="px-5 py-2 bg-red-600 hover:bg-red-500 rounded text-white font-heading text-lg tracking-wider disabled:opacity-50 transition-colors"
                >
                  {isConnecting ? 'JOINING...' : 'JOIN'}
                </button>
              </div>
            </div>

            <button
              onClick={() => setShowMultiplayerModal(false)}
              className="py-2 bg-slate-800 hover:bg-slate-700 rounded text-slate-300 font-tactical text-xs transition-colors"
            >
              CANCEL
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
