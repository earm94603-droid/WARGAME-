/**
 * CONTAINER CLASH - 3D FIRST-PERSON ARCADE SHOOTER
 * High-performance Three.js FPS engine with offline Bot AI,
 * 1v1 Hotspot / LAN multiplayer, procedural Web Audio, and mobile touch controls.
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

import {
  GameMode,
  Team,
  GameSettings,
  SurfaceType,
  Vector3D,
  NetworkPlayerState,
} from './game/types.ts';
import {
  MatchState,
  PlayerStats,
  createInitialMatchState,
  createInitialPlayerStats,
  calculateDamage,
  applyDamageToHealth,
  calculateReload,
  updateMatchScore,
  tickMatchTimer,
} from './game/rules.ts';
import { buildContainerYard, MapData } from './game/mapBuilder.ts';
import { FirstPersonWeaponRig } from './game/weapon.ts';
import { OperativeCharacter } from './game/character.ts';
import { ParticleSystem } from './game/particles.ts';
import { BotController } from './game/botAI.ts';
import { NetworkClient } from './game/network.ts';
import { soundEngine } from './game/audio.ts';

import { HUD } from './components/HUD.tsx';
import { TitleScreen } from './components/TitleScreen.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import { MatchEndModal } from './components/MatchEndModal.tsx';
import { AndroidInstallModal } from './components/AndroidInstallModal.tsx';

// Software WebGL detection guard
const isSoftwareGl = (() => {
  if (typeof document === 'undefined') return false;
  const gl = document.createElement('canvas').getContext('webgl2');
  if (!gl) return true;
  const ext = gl.getExtension('WEBGL_debug_renderer_info');
  const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
  const gpu = String(gl.getParameter(param));
  gl.getExtension('WEBGL_lose_context')?.loseContext();
  return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
})();

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);

  // UI States
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'paused' | 'game_over'>('menu');
  const [gameMode, setGameMode] = useState<GameMode>('bot');
  const [matchState, setMatchState] = useState<MatchState>(createInitialMatchState());
  const [playerStats, setPlayerStats] = useState<PlayerStats>(createInitialPlayerStats());
  const [isAiming, setIsAiming] = useState<boolean>(false);
  const [hitmarkerActive, setHitmarkerActive] = useState<boolean>(false);
  const [damageFlashActive, setDamageFlashActive] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showAndroidGuide, setShowAndroidGuide] = useState<boolean>(false);

  // Network state
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [networkRoomCode, setNetworkRoomCode] = useState<string | null>(null);
  const [networkError, setNetworkError] = useState<string | null>(null);

  // Player & Enemy 2D positions for Radar HUD
  const [radarPlayerPos, setRadarPlayerPos] = useState<{ x: number; z: number; yaw: number }>({
    x: -18,
    z: -18,
    yaw: 0,
  });
  const [radarEnemyPos, setRadarEnemyPos] = useState<{ x: number; z: number } | null>(null);

  // User Settings
  const [settings, setSettings] = useState<GameSettings>({
    mouseSensitivity: 1.0,
    touchSensitivity: 1.0,
    soundVolume: 0.8,
    graphicsQuality: 'high',
    invertY: false,
  });

  // Mutable Game Loop State stored in Ref (to prevent React re-render recreation)
  const gameRef = useRef<{
    renderer: THREE.WebGLRenderer | null;
    scene: THREE.Scene | null;
    camera: THREE.PerspectiveCamera | null;
    mapData: MapData | null;
    weaponRig: FirstPersonWeaponRig | null;
    particleSystem: ParticleSystem | null;
    opponentCharacter: OperativeCharacter | null;
    botController: BotController | null;
    networkClient: NetworkClient | null;

    // Local player kinematics
    playerPos: THREE.Vector3;
    playerVel: THREE.Vector3;
    playerYaw: number;
    playerPitch: number;
    targetYaw: number;
    targetPitch: number;
    isCrouching: boolean;
    isGrounded: boolean;
    myTeam: Team;

    // Inputs & Tactical State
    moveInput: { x: number; z: number };
    lookDelta: { dx: number; dy: number };
    isFiring: boolean;
    lastFireTime: number;
    peekState: 'left' | 'center' | 'right';
    currentLean: number;
    currentLeanRoll: number;

    // Interpolation for network opponent
    targetOpponentPos: THREE.Vector3;
    targetOpponentYaw: number;

    // Title screen camera orbit
    menuAngle: number;
    gameState: 'menu' | 'playing' | 'paused' | 'game_over';
    gameMode: GameMode;
  }>({
    renderer: null,
    scene: null,
    camera: null,
    mapData: null,
    weaponRig: null,
    particleSystem: null,
    opponentCharacter: null,
    botController: null,
    networkClient: null,

    playerPos: new THREE.Vector3(-18, 1.7, -18),
    playerVel: new THREE.Vector3(),
    playerYaw: -2.355,
    playerPitch: 0,
    targetYaw: -2.355,
    targetPitch: 0,
    isCrouching: false,
    isGrounded: true,
    myTeam: 'blue',

    moveInput: { x: 0, z: 0 },
    lookDelta: { dx: 0, dy: 0 },
    isFiring: false,
    lastFireTime: 0,
    peekState: 'center',
    currentLean: 0,
    currentLeanRoll: 0,

    targetOpponentPos: new THREE.Vector3(18, 0, 18),
    targetOpponentYaw: Math.PI,

    menuAngle: 0,
    gameState: 'menu',
    gameMode: 'bot',
  });

  const [peekState, setPeekState] = useState<'left' | 'center' | 'right'>('center');
  const handlePeekChange = useCallback((dir: 'left' | 'center' | 'right') => {
    gameRef.current.peekState = dir;
    setPeekState(dir);
  }, []);

  // Autostart & Install parameter support
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      startBotMatch();
    }
    if (params.get('install') === '1' || params.get('apk') === '1' || params.get('guide') === '1') {
      setShowAndroidGuide(true);
    }
  }, []);

  // Initialize Three.js scene once on mount
  useEffect(() => {
    if (!mountRef.current) return;

    const width = window.innerWidth;
    const height = window.innerHeight;

    // 1. Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    mountRef.current.appendChild(renderer.domElement);
    gameRef.current.renderer = renderer;

    // 2. Scene (Atmospheric dusk golden hour matching Image 2 reference)
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x3a4856); // Deep dusk overcast sky
    scene.fog = new THREE.FogExp2(0x3a4856, 0.016);
    gameRef.current.scene = scene;

    // Mandatory Procedural Studio Environment Reflection
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 3. Lighting Rig (Golden sunset sun + dramatic cool slate fill + edge rim)
    const sunLight = new THREE.DirectionalLight(0xffb366, 3.2); // Warm golden sun raking across top edges
    sunLight.position.set(32, 28, -26);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 100;
    const d = 35;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0005;
    scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0x5588bb, 1.4); // Cool blue rim light on opposite weapon side
    rimLight.position.set(-28, 20, 24);
    scene.add(rimLight);

    const hemiLight = new THREE.HemisphereLight(0x7090b0, 0x221a14, 1.2);
    scene.add(hemiLight);

    // 4. Camera
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 150);
    camera.position.set(-18, 1.7, -18);
    scene.add(camera);
    gameRef.current.camera = camera;

    // 5. Build Container Yard Map
    const mapData = buildContainerYard();
    scene.add(mapData.sceneGroup);
    gameRef.current.mapData = mapData;

    // 6. First-Person Weapon Rig (Attached to Camera)
    const weaponRig = new FirstPersonWeaponRig('blue');
    camera.add(weaponRig.group);
    gameRef.current.weaponRig = weaponRig;

    // 7. Particle System
    const particleSystem = new ParticleSystem(scene);
    gameRef.current.particleSystem = particleSystem;

    // 8. Opponent Character Model (Red Operative)
    const opponent = new OperativeCharacter('red');
    opponent.setPosition(18, 0, 18);
    scene.add(opponent.group);
    gameRef.current.opponentCharacter = opponent;

    // 9. Offline Bot Controller
    const botController = new BotController(
      opponent,
      mapData.waypoints,
      mapData.colliders,
      new THREE.Vector3(18, 0, 18)
    );
    gameRef.current.botController = botController;

    // 10. Window Resize Handler
    const handleResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // 11. Mouse Movement & Pointer Lock
    const handleMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === renderer.domElement) {
        const sens = 0.0022 * settings.mouseSensitivity;
        gameRef.current.lookDelta.dx += e.movementX * sens;
        gameRef.current.lookDelta.dy += e.movementY * sens * (settings.invertY ? -1 : 1);
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        // Left click fire
        gameRef.current.isFiring = true;
      } else if (e.button === 2) {
        // Right click ADS toggle
        setIsAiming((prev) => {
          const next = !prev;
          if (gameRef.current.weaponRig) gameRef.current.weaponRig.isAiming = next;
          return next;
        });
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        gameRef.current.isFiring = false;
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyW') gameRef.current.moveInput.z = 1;
      if (e.code === 'KeyS') gameRef.current.moveInput.z = -1;
      if (e.code === 'KeyA') gameRef.current.moveInput.x = -1;
      if (e.code === 'KeyD') gameRef.current.moveInput.x = 1;
      if (e.code === 'KeyQ') {
        gameRef.current.peekState = 'left';
        setPeekState('left');
      }
      if (e.code === 'KeyE') {
        gameRef.current.peekState = 'right';
        setPeekState('right');
      }
      if (e.code === 'Space' && gameRef.current.isGrounded) {
        gameRef.current.playerVel.y = 6.2;
        gameRef.current.isGrounded = false;
        soundEngine.playJump();
      }
      if (e.code === 'KeyC') {
        gameRef.current.isCrouching = !gameRef.current.isCrouching;
      }
      if (e.code === 'KeyR') {
        handleReload();
      }
      if (e.code === 'Escape') {
        setGameState((prev) => (prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev));
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'KeyW' && gameRef.current.moveInput.z === 1) gameRef.current.moveInput.z = 0;
      if (e.code === 'KeyS' && gameRef.current.moveInput.z === -1) gameRef.current.moveInput.z = 0;
      if (e.code === 'KeyA' && gameRef.current.moveInput.x === -1) gameRef.current.moveInput.x = 0;
      if (e.code === 'KeyD' && gameRef.current.moveInput.x === 1) gameRef.current.moveInput.x = 0;
      if (e.code === 'KeyQ' && gameRef.current.peekState === 'left') {
        gameRef.current.peekState = 'center';
        setPeekState('center');
      }
      if (e.code === 'KeyE' && gameRef.current.peekState === 'right') {
        gameRef.current.peekState = 'center';
        setPeekState('center');
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Disable context menu for right-click ADS
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    window.addEventListener('contextmenu', handleContextMenu);

    // 12. Main Game Loop with software WebGL pacing
    let lastTime = performance.now();
    let frameId = 0;
    let timerId: number | null = null;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          timerId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          timerId = window.setTimeout(cb, 80);
        }
      };
      timerId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      const now = performance.now();
      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      const dt = Math.min(rawDt, 0.05);

      updateSimulation(dt);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    frameId = requestAnimationFrame(tick);

    return () => {
      if (timerId !== null) clearTimeout(timerId);
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('contextmenu', handleContextMenu);
      renderer.dispose();
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Main simulation tick
  const updateSimulation = (dt: number) => {
    const g = gameRef.current;
    if (!g.camera || !g.weaponRig || !g.particleSystem) return;

    // 1. Title Screen Camera Orbit Mode
    if (g.gameState === 'menu') {
      g.menuAngle += dt * 0.15;
      const camRadius = 24.0;
      g.camera.position.set(
        Math.cos(g.menuAngle) * camRadius,
        9.0 + Math.sin(g.menuAngle * 0.8) * 2.0,
        Math.sin(g.menuAngle) * camRadius
      );
      g.camera.lookAt(0, 3.0, 0);
      g.weaponRig.group.visible = false;
      if (g.opponentCharacter) {
        g.opponentCharacter.update(dt, true, 2.0, false);
      }
      return;
    }

    g.weaponRig.group.visible = true;

    // 2. Match Timer
    if (g.gameState === 'playing') {
      setMatchState((prev) => {
        const next = tickMatchTimer(prev, dt);
        if (next.isGameOver) {
          g.gameState = 'game_over';
          setGameState('game_over');
          if (next.winner === g.myTeam) soundEngine.playVictory();
          else soundEngine.playDefeat();
        }
        return next;
      });
    }

    // 3. Camera Look (Yaw & Pitch with smooth exponential damping) & Tactical Peek Lean
    const targetLean = g.peekState === 'left' ? -1.0 : g.peekState === 'right' ? 1.0 : 0.0;
    g.currentLean = THREE.MathUtils.damp(g.currentLean, targetLean, 16.0, dt);

    g.targetYaw -= g.lookDelta.dx;
    g.targetPitch = Math.max(-1.45, Math.min(1.45, g.targetPitch - g.lookDelta.dy));

    const lookDamping = 32.0;
    g.playerYaw = THREE.MathUtils.damp(g.playerYaw, g.targetYaw, lookDamping, dt);
    g.playerPitch = THREE.MathUtils.damp(g.playerPitch, g.targetPitch, lookDamping, dt);

    const targetRoll = -g.currentLean * 0.14; // ~8 deg tactical lean roll
    g.currentLeanRoll = THREE.MathUtils.damp(g.currentLeanRoll, targetRoll, 16.0, dt);

    g.camera.rotation.order = 'YXZ';
    g.camera.rotation.y = g.playerYaw;
    g.camera.rotation.x = g.playerPitch;
    g.camera.rotation.z = g.currentLeanRoll;

    // Reset look delta
    const lookX = g.lookDelta.dx;
    const lookY = g.lookDelta.dy;
    g.lookDelta.dx = 0;
    g.lookDelta.dy = 0;

    // 4. Player Kinematics & Movement
    const speed = g.isCrouching ? 2.4 : isAiming ? 3.0 : 5.4;
    const isMoving = g.moveInput.x !== 0 || g.moveInput.z !== 0;

    const moveX = g.moveInput.x;
    const moveZ = g.moveInput.z;

    const forward = new THREE.Vector3(-Math.sin(g.playerYaw), 0, -Math.cos(g.playerYaw));
    const right = new THREE.Vector3(Math.cos(g.playerYaw), 0, -Math.sin(g.playerYaw));

    const moveDir = forward.multiplyScalar(moveZ).add(right.multiplyScalar(moveX));
    if (moveDir.lengthSq() > 0.001) moveDir.normalize();

    // Horizontal acceleration & friction
    const accel = 35.0;
    g.playerVel.x = THREE.MathUtils.lerp(g.playerVel.x, moveDir.x * speed, accel * dt);
    g.playerVel.z = THREE.MathUtils.lerp(g.playerVel.z, moveDir.z * speed, accel * dt);

    // Gravity
    g.playerVel.y -= 19.8 * dt;

    // Target eye height
    const targetEyeY = g.isCrouching ? 1.15 : 1.7;

    // Apply movement with AABB obstacle collision
    const nextX = g.playerPos.x + g.playerVel.x * dt;
    const nextZ = g.playerPos.z + g.playerVel.z * dt;
    const nextY = g.playerPos.y + g.playerVel.y * dt;

    // Check collisions
    const playerRadius = 0.45;
    let collidesX = false;
    let collidesZ = false;

    if (g.mapData) {
      for (const col of g.mapData.colliders) {
        if (
          nextX + playerRadius > col.minX &&
          nextX - playerRadius < col.maxX &&
          g.playerPos.z + playerRadius > col.minZ &&
          g.playerPos.z - playerRadius < col.maxZ &&
          col.maxY > 0.4
        ) {
          collidesX = true;
        }
        if (
          g.playerPos.x + playerRadius > col.minX &&
          g.playerPos.x - playerRadius < col.maxX &&
          nextZ + playerRadius > col.minZ &&
          nextZ - playerRadius < col.maxZ &&
          col.maxY > 0.4
        ) {
          collidesZ = true;
        }
      }
    }

    if (!collidesX) g.playerPos.x = nextX;
    else g.playerVel.x = 0;

    if (!collidesZ) g.playerPos.z = nextZ;
    else g.playerVel.z = 0;

    // Ground check (floor at y = 0, eye level at targetEyeY)
    if (nextY <= targetEyeY) {
      g.playerPos.y = targetEyeY;
      g.playerVel.y = 0;
      g.isGrounded = true;
    } else {
      g.playerPos.y = nextY;
      g.isGrounded = false;
    }

    // Apply lateral lean offset and natural eye drop
    const leanOffset = right.clone().multiplyScalar(g.currentLean * 0.38);
    const leanEyeDrop = Math.abs(g.currentLean) * 0.05;

    g.camera.position.copy(g.playerPos);
    g.camera.position.add(leanOffset);
    g.camera.position.y -= leanEyeDrop;

    // Footsteps
    if (isMoving && g.isGrounded) {
      soundEngine.playFootstep(!g.isCrouching);
    }

    // 5. Weapon Rig Update (Recoil, sway, ADS blend, running combat fire towards crosshair, and lean)
    g.weaponRig.update(dt, isMoving, !g.isCrouching, lookX, lookY, g.isFiring, g.currentLean);

    // Dynamic FOV zoom for ADS
    const targetFov = isAiming ? 48 : 75;
    g.camera.fov = THREE.MathUtils.lerp(g.camera.fov, targetFov, 14 * dt);
    g.camera.updateProjectionMatrix();

    // 6. Continuous Auto Fire
    if (g.isFiring && g.gameState === 'playing') {
      const now = performance.now();
      if (now - g.lastFireTime > 115) {
        // ~520 RPM
        g.lastFireTime = now;
        fireWeapon();
      }
    }

    // 7. Update Particles
    g.particleSystem.update(dt);

    // 8. Bot Update (if in bot mode)
    if (g.gameMode === 'bot' && g.botController) {
      const isPlayerMoving = g.moveInput.x !== 0 || g.moveInput.z !== 0 || g.playerVel.lengthSq() > 0.04;
      g.botController.update(dt, g.playerPos, isPlayerMoving, (botMuzzle, botAimDir) => {
        // Trigger realistic visual muzzle flare, dynamic point light, and gun recoil on enemy bot
        g.opponentCharacter?.triggerFireAnimation();
        const fireOrigin = g.opponentCharacter ? g.opponentCharacter.getMuzzleWorldPos() : botMuzzle;

        // Bot shot effect
        const hit = performRaycast(fireOrigin, botAimDir, true);
        const endPoint = hit ? hit.point : fireOrigin.clone().addScaledVector(botAimDir, 60);

        // Spawn red/orange tracer streak from bot rifle barrel
        g.particleSystem?.spawnTracer(fireOrigin, endPoint);

        if (hit) {
          if (hit.isPlayer) {
            // Player hit! Deals exactly 5% damage (5 HP) as requested!
            soundEngine.playPlayerHurt();
            setDamageFlashActive(true);
            setTimeout(() => setDamageFlashActive(false), 220);

            setPlayerStats((prev) => {
              const res = applyDamageToHealth(prev.health, 5); // 5% damage per hit!
              if (res.isDefeated) {
                // Player defeated
                handlePlayerDefeated();
              }
              return { ...prev, health: res.newHealth };
            });
          } else {
            // Near-miss impact on surface
            g.particleSystem?.spawnImpact(hit.point, hit.normal, hit.surface);
          }
        }
      });

      // Update radar enemy position
      setRadarEnemyPos({
        x: g.botController.position.x,
        z: g.botController.position.z,
      });
    }

    // 9. Update Radar Player Position
    setRadarPlayerPos({
      x: g.playerPos.x,
      z: g.playerPos.z,
      yaw: g.playerYaw,
    });
  };

  interface RaycastHitResult {
    point: THREE.Vector3;
    normal: THREE.Vector3;
    surface: SurfaceType;
    isHeadshot?: boolean;
    isOpponent?: boolean;
    isPlayer?: boolean;
  }

  // Perform Raycast for shooting hit detection
  const performRaycast = (
    origin: THREE.Vector3,
    direction: THREE.Vector3,
    isBotShooting: boolean = false
  ): RaycastHitResult | null => {
    const g = gameRef.current;
    if (!g.scene || !g.mapData) return null;

    const raycaster = new THREE.Raycaster(origin, direction, 0.1, 120);

    // 1. Check Opponent Character Hitboxes (if local player is shooting)
    if (!isBotShooting && g.opponentCharacter && !g.opponentCharacter.isDefeated) {
      const ray = raycaster.ray;

      // Check headshot first
      const headIntersection = ray.intersectBox(g.opponentCharacter.headCollider, new THREE.Vector3());
      if (headIntersection) {
        return {
          point: headIntersection,
          normal: new THREE.Vector3(0, 1, 0),
          surface: 'flesh' as SurfaceType,
          isHeadshot: true,
          isOpponent: true,
        };
      }

      // Check body shot
      const bodyIntersection = ray.intersectBox(g.opponentCharacter.bodyCollider, new THREE.Vector3());
      if (bodyIntersection) {
        return {
          point: bodyIntersection,
          normal: new THREE.Vector3(0, 0, 1),
          surface: 'flesh' as SurfaceType,
          isHeadshot: false,
          isOpponent: true,
        };
      }
    }

    // 2. Check Player Hitbox (if bot is shooting)
    if (isBotShooting) {
      const playerBox = new THREE.Box3(
        new THREE.Vector3(g.playerPos.x - 0.4, g.playerPos.y - 1.7, g.playerPos.z - 0.4),
        new THREE.Vector3(g.playerPos.x + 0.4, g.playerPos.y + 0.2, g.playerPos.z + 0.4)
      );
      const hit = raycaster.ray.intersectBox(playerBox, new THREE.Vector3());
      if (hit) {
        return {
          point: hit,
          normal: new THREE.Vector3(0, 1, 0),
          surface: 'flesh' as SurfaceType,
          isPlayer: true,
        };
      }
    }

    // 3. Check Map Colliders
    let closestDist = Infinity;
    let closestHit: RaycastHitResult | null = null;

    for (const col of g.mapData.colliders) {
      const box = new THREE.Box3(
        new THREE.Vector3(col.minX, col.minY, col.minZ),
        new THREE.Vector3(col.maxX, col.maxY, col.maxZ)
      );
      const hitPoint = raycaster.ray.intersectBox(box, new THREE.Vector3());
      if (hitPoint) {
        const d = origin.distanceTo(hitPoint);
        if (d < closestDist) {
          closestDist = d;
          closestHit = {
            point: hitPoint,
            normal: new THREE.Vector3(0, 1, 0),
            surface: col.surface,
          };
        }
      }
    }

    return closestHit;
  };

  // Weapon Fire
  const fireWeapon = () => {
    const g = gameRef.current;
    if (!g.camera || !g.weaponRig || !g.particleSystem) return;

    if (playerStats.ammo <= 0) {
      handleReload();
      return;
    }

    // Decrement ammo
    setPlayerStats((prev) => ({
      ...prev,
      ammo: prev.ammo - 1,
      shotsFired: prev.shotsFired + 1,
    }));

    // Trigger visual recoil & muzzle flash
    const camRecoil = g.weaponRig.triggerFireRecoil();
    g.targetPitch = Math.max(-1.45, Math.min(1.45, g.targetPitch + camRecoil * 0.35)); // smooth natural kick
    soundEngine.playGunshot(true);

    // Calculate bullet trajectory with spread
    const spread = isAiming ? 0.006 : 0.024;
    const aimDir = new THREE.Vector3(
      (Math.random() - 0.5) * spread,
      (Math.random() - 0.5) * spread,
      -1
    );
    aimDir.unproject(g.camera).sub(g.camera.position).normalize();

    // Raycast hit
    const hit = performRaycast(g.camera.position, aimDir, false);
    const endPoint = hit ? hit.point : g.camera.position.clone().addScaledVector(aimDir, 80);

    // Spawn tracer streak
    g.particleSystem.spawnTracer(g.weaponRig.muzzleWorldPos, endPoint);

    if (hit) {
      // Surface particles & sound
      g.particleSystem.spawnImpact(hit.point, hit.normal, hit.surface);
      soundEngine.playImpact(hit.surface);

      // Opponent Hit confirmation
      if (hit.isOpponent) {
        setHitmarkerActive(true);
        setTimeout(() => setHitmarkerActive(false), 140);
        soundEngine.playHitmarker(!!hit.isHeadshot);

        const damage = calculateDamage(!!hit.isHeadshot);

        setPlayerStats((prev) => ({
          ...prev,
          shotsHit: prev.shotsHit + 1,
          headshots: prev.headshots + (hit.isHeadshot ? 1 : 0),
        }));

        if (gameMode === 'bot' && g.botController) {
          const res = g.botController.takeDamage(damage);
          if (res.isDefeated) {
            handleOpponentDefeated();
          }
        } else if (g.networkClient && g.networkClient.isConnected) {
          g.networkClient.sendHit('opponent', damage, !!hit.isHeadshot);
        }
      }
    }
  };

  // Reload Weapon
  const handleReload = () => {
    const g = gameRef.current;
    if (!g.weaponRig || g.weaponRig.isReloading) return;
    if (playerStats.ammo >= playerStats.maxAmmo || playerStats.reserveAmmo <= 0) return;

    g.weaponRig.startReload();
    soundEngine.playReload();

    setTimeout(() => {
      setPlayerStats((prev) => {
        const res = calculateReload(prev.ammo, prev.reserveAmmo);
        return {
          ...prev,
          ammo: res.newAmmo,
          reserveAmmo: res.newReserveAmmo,
        };
      });
    }, 1200);
  };

  // Opponent defeated -> update score and trigger respawn
  const handleOpponentDefeated = () => {
    setPlayerStats((prev) => ({ ...prev, kills: prev.kills + 1 }));
    setMatchState((prev) => {
      const next = updateMatchScore(prev, 'blue');
      if (next.isGameOver) {
        setGameState('game_over');
        soundEngine.playVictory();
      }
      return next;
    });

    // Respawn bot after 3s
    setTimeout(() => {
      const g = gameRef.current;
      if (g.botController && g.mapData) {
        const spawns = g.mapData.spawnPoints.red;
        const randomSpawn = spawns[Math.floor(Math.random() * spawns.length)];
        g.botController.respawn(randomSpawn);
      }
    }, 3000);
  };

  // Player defeated -> update score and respawn
  const handlePlayerDefeated = () => {
    soundEngine.playPlayerHurt();
    setPlayerStats((prev) => ({ ...prev, deaths: prev.deaths + 1 }));
    setMatchState((prev) => {
      const next = updateMatchScore(prev, 'red');
      if (next.isGameOver) {
        setGameState('game_over');
        soundEngine.playDefeat();
      }
      return next;
    });

    // Respawn local player at blue spawn point
    setTimeout(() => {
      const g = gameRef.current;
      if (g.mapData) {
        const spawns = g.mapData.spawnPoints.blue;
        const randomSpawn = spawns[Math.floor(Math.random() * spawns.length)];
        g.playerPos.set(randomSpawn.x, 1.7, randomSpawn.z);
        setPlayerStats((prev) => ({
          ...prev,
          health: 100,
          ammo: 30,
        }));
      }
    }, 2500);
  };

  // Start Bot Match
  const startBotMatch = () => {
    const g = gameRef.current;
    g.gameState = 'playing';
    g.gameMode = 'bot';
    g.myTeam = 'blue';
    g.playerPos.set(-18, 1.7, -18);
    g.playerYaw = -2.355;
    g.targetYaw = -2.355;
    g.playerPitch = 0;
    g.targetPitch = 0;
    g.peekState = 'center';
    g.currentLean = 0;
    g.currentLeanRoll = 0;
    setPeekState('center');
    if (g.camera) {
      g.camera.rotation.order = 'YXZ';
      g.camera.rotation.set(0, g.playerYaw, 0);
    }

    setGameMode('bot');
    setMatchState(createInitialMatchState());
    setPlayerStats(createInitialPlayerStats());
    setGameState('playing');

    if (g.botController && g.mapData) {
      g.botController.respawn(new THREE.Vector3(18, 0, 18));
    }

    // Request pointer lock for desktop controls
    if (g.renderer) {
      g.renderer.domElement.requestPointerLock?.();
    }
  };

  // Host 1v1 Multiplayer Match
  const hostMultiplayerMatch = async () => {
    setIsConnecting(true);
    setNetworkError(null);

    const client = new NetworkClient({
      onRoomCreated: (roomCode) => {
        setNetworkRoomCode(roomCode);
        setIsConnecting(false);
      },
      onMatchStart: () => {
        const g = gameRef.current;
        g.gameState = 'playing';
        g.gameMode = 'multiplayer_host';
        g.myTeam = 'blue';

        setGameMode('multiplayer_host');
        setMatchState(createInitialMatchState());
        setPlayerStats(createInitialPlayerStats());
        setGameState('playing');
        if (g.renderer) {
          g.renderer.domElement.requestPointerLock?.();
        }
      },
      onDamageApplied: (dmg, newHealth) => {
        setPlayerStats((prev) => ({ ...prev, health: newHealth }));
        setDamageFlashActive(true);
        setTimeout(() => setDamageFlashActive(false), 220);
        soundEngine.playPlayerHurt();
      },
      onScoreUpdate: (blue, red, winner) => {
        setMatchState((prev) => ({
          ...prev,
          blueScore: blue,
          redScore: red,
          isGameOver: !!winner,
          winner,
        }));
        if (winner) {
          setGameState('game_over');
          if (winner === 'blue') soundEngine.playVictory();
          else soundEngine.playDefeat();
        }
      },
      onError: (err) => {
        setNetworkError(err);
        setIsConnecting(false);
      },
    });

    const ok = await client.connect();
    if (ok) {
      client.hostRoom();
      gameRef.current.networkClient = client;
    } else {
      setNetworkError('Could not connect to multiplayer server.');
      setIsConnecting(false);
    }
  };

  // Join 1v1 Multiplayer Match
  const joinMultiplayerMatch = async (code: string) => {
    setIsConnecting(true);
    setNetworkError(null);

    const client = new NetworkClient({
      onRoomJoined: () => {
        setIsConnecting(false);
      },
      onMatchStart: () => {
        const g = gameRef.current;
        g.gameState = 'playing';
        g.gameMode = 'multiplayer_client';
        g.myTeam = 'red';
        g.playerPos.set(18, 1.7, 18);
        g.playerYaw = Math.PI;

        setGameMode('multiplayer_client');
        setMatchState(createInitialMatchState());
        setPlayerStats(createInitialPlayerStats());
        setGameState('playing');
        if (g.renderer) {
          g.renderer.domElement.requestPointerLock?.();
        }
      },
      onError: (err) => {
        setNetworkError(err);
        setIsConnecting(false);
      },
    });

    const ok = await client.connect();
    if (ok) {
      client.joinRoom(code);
      gameRef.current.networkClient = client;
    } else {
      setNetworkError('Could not connect to multiplayer server.');
      setIsConnecting(false);
    }
  };

  // Rematch callback
  const handleRematch = () => {
    if (gameMode === 'bot') {
      startBotMatch();
    } else {
      setMatchState(createInitialMatchState());
      setPlayerStats(createInitialPlayerStats());
      setGameState('playing');
    }
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#0b0f19]">
      {/* Isolated Three.js WebGL Mount Canvas */}
      <div
        ref={mountRef}
        data-testid="webgl-canvas-container"
        className="absolute inset-0 cursor-crosshair z-0"
        onClick={() => {
          if (gameState === 'playing' && gameRef.current.renderer) {
            gameRef.current.renderer.domElement.requestPointerLock?.();
          }
        }}
      />

      {/* Title Screen Shell */}
      {gameState === 'menu' && (
        <TitleScreen
          onStartBotMatch={startBotMatch}
          onHostMultiplayer={hostMultiplayerMatch}
          onJoinMultiplayer={joinMultiplayerMatch}
          onOpenSettings={() => setShowSettings(true)}
          onOpenAndroidGuide={() => setShowAndroidGuide(true)}
          isConnecting={isConnecting}
          networkRoomCode={networkRoomCode}
          networkError={networkError}
        />
      )}

      {/* In-Game World-Matched HUD */}
      {gameState === 'playing' && (
        <HUD
          matchState={matchState}
          playerStats={playerStats}
          isAiming={isAiming}
          hitmarkerActive={hitmarkerActive}
          damageFlashActive={damageFlashActive}
          playerPos={radarPlayerPos}
          enemyPos={radarEnemyPos}
          peekState={peekState}
          onPeekChange={handlePeekChange}
          onFireDown={() => {
            gameRef.current.isFiring = true;
          }}
          onFireUp={() => {
            gameRef.current.isFiring = false;
          }}
          onAimToggle={() => {
            setIsAiming((prev) => {
              const next = !prev;
              if (gameRef.current.weaponRig) gameRef.current.weaponRig.isAiming = next;
              return next;
            });
          }}
          onJump={() => {
            if (gameRef.current.isGrounded) {
              gameRef.current.playerVel.y = 6.2;
              gameRef.current.isGrounded = false;
              soundEngine.playJump();
            }
          }}
          onCrouchToggle={() => {
            gameRef.current.isCrouching = !gameRef.current.isCrouching;
          }}
          onReload={handleReload}
          onPauseToggle={() => {
            gameRef.current.gameState = 'paused';
            setGameState('paused');
          }}
          onMoveChange={(x, z) => {
            gameRef.current.moveInput.x = x;
            gameRef.current.moveInput.z = z;
          }}
          onLookDelta={(dx, dy) => {
            const sens = 0.0045 * settings.touchSensitivity;
            gameRef.current.lookDelta.dx += dx * sens;
            gameRef.current.lookDelta.dy += dy * sens * (settings.invertY ? -1 : 1);
          }}
        />
      )}

      {/* Pause Modal */}
      {gameState === 'paused' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm pointer-events-auto select-none">
          <div className="w-full max-w-sm bg-[#0d131f] border border-slate-700 rounded-lg p-6 shadow-2xl flex flex-col gap-4 text-center">
            <h2 className="font-heading text-4xl text-white">MATCH PAUSED</h2>
            <div className="flex flex-col gap-2.5 mt-2">
              {/* Quick In-Match Aim Sensitivity Slider */}
              <div className="flex flex-col gap-1.5 p-3 bg-slate-900/90 rounded border border-slate-800 text-right" dir="rtl">
                <div className="flex items-center justify-between text-xs font-tactical text-slate-300">
                  <span className="font-semibold text-slate-200">حساسية توجيه السلاح (AIM SENSITIVITY):</span>
                  <span className="text-cyan-400 font-bold font-mono text-sm">{Math.round(settings.touchSensitivity * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="3.0"
                  step="0.1"
                  value={settings.touchSensitivity}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setSettings((prev) => ({
                      ...prev,
                      touchSensitivity: val,
                      mouseSensitivity: val,
                    }));
                  }}
                  className="w-full accent-cyan-400 bg-slate-950 rounded cursor-pointer h-2.5"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-tactical">
                  <span>بطيئة (20%)</span>
                  <span>افتراضية (100%)</span>
                  <span>سريعة جداً (300%)</span>
                </div>
              </div>

              <button
                onClick={() => {
                  soundEngine.playUiClick();
                  gameRef.current.gameState = 'playing';
                  setGameState('playing');
                  if (gameRef.current.renderer) {
                    gameRef.current.renderer.domElement.requestPointerLock?.();
                  }
                }}
                className="py-3 bg-blue-600 hover:bg-blue-500 rounded text-white font-heading text-xl tracking-wider transition-colors"
              >
                RESUME MATCH (متابعة اللعب)
              </button>
              <button
                onClick={() => {
                  soundEngine.playUiClick();
                  setShowSettings(true);
                }}
                className="py-2.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-300 font-tactical text-xs tracking-wider transition-colors"
              >
                SETTINGS (الإعدادات المتقدمة)
              </button>
              <button
                onClick={() => {
                  soundEngine.playUiClick();
                  gameRef.current.gameState = 'menu';
                  setGameState('menu');
                  if (document.exitPointerLock) document.exitPointerLock();
                }}
                className="py-2.5 bg-red-950/60 hover:bg-red-900/60 text-red-300 border border-red-800/80 rounded font-tactical text-xs tracking-wider transition-colors"
              >
                RETURN TO MENU
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Victory / Defeat Modal */}
      {gameState === 'game_over' && (
        <MatchEndModal
          isVictory={matchState.winner === gameRef.current.myTeam}
          blueScore={matchState.blueScore}
          redScore={matchState.redScore}
          playerStats={playerStats}
          onRematch={handleRematch}
          onReturnToMenu={() => {
            setGameState('menu');
            if (document.exitPointerLock) document.exitPointerLock();
          }}
        />
      )}

      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(s) => setSettings(s)}
          onClose={() => setShowSettings(false)}
          defaultTab="settings"
        />
      )}

      {/* Android Installation & Quick-Play Modal */}
      {showAndroidGuide && (
        <AndroidInstallModal
          onClose={() => setShowAndroidGuide(false)}
          onLaunchBotMatch={() => {
            setShowAndroidGuide(false);
            startBotMatch();
          }}
        />
      )}
    </main>
  );
}
