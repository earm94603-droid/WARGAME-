import * as THREE from 'three';
import { BoundingBox3D, SurfaceType, Waypoint } from './types.ts';

export interface MapData {
  sceneGroup: THREE.Group;
  colliders: BoundingBox3D[];
  waypoints: Waypoint[];
  spawnPoints: {
    blue: THREE.Vector3[];
    red: THREE.Vector3[];
  };
}

// Procedural texture generators to ensure zero external file / 404 dependencies
function createContainerTexture(colorHex: string, label: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Base background
  ctx.fillStyle = colorHex;
  ctx.fillRect(0, 0, 512, 256);

  // Vertical corrugation ribs
  const ribWidth = 16;
  for (let x = 0; x < 512; x += ribWidth) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.22)';
    ctx.fillRect(x, 0, ribWidth * 0.4, 256);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.fillRect(x + ribWidth * 0.4, 0, ribWidth * 0.3, 256);
  }

  // Border frame
  ctx.strokeStyle = 'rgba(0,0,0,0.5)';
  ctx.lineWidth = 10;
  ctx.strokeRect(5, 5, 502, 246);

  // Stencil markings
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 36px monospace';
  ctx.shadowColor = 'rgba(0,0,0,0.6)';
  ctx.shadowBlur = 4;
  ctx.fillText(label, 40, 110);

  ctx.font = 'bold 18px monospace';
  ctx.fillText('MAX GROSS: 30,480 KG', 40, 150);
  ctx.fillText('8 OPEN PRESSURE 6791', 40, 180);

  // Rust / grunge speckles
  for (let i = 0; i < 400; i++) {
    const rx = Math.random() * 512;
    const ry = Math.random() * 256;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(70, 30, 10, 0.25)' : 'rgba(0, 0, 0, 0.15)';
    ctx.fillRect(rx, ry, Math.random() * 4 + 1, Math.random() * 4 + 1);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

function createCrateTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Wood planks background
  ctx.fillStyle = '#9b7653';
  ctx.fillRect(0, 0, 256, 256);

  // Planks lines
  ctx.strokeStyle = '#5a3d28';
  ctx.lineWidth = 4;
  for (let y = 0; y <= 256; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(256, y);
    ctx.stroke();
  }

  // Diagonal cross bracing
  ctx.lineWidth = 20;
  ctx.strokeStyle = '#7c5737';
  ctx.beginPath();
  ctx.moveTo(10, 10);
  ctx.lineTo(246, 246);
  ctx.moveTo(246, 10);
  ctx.lineTo(10, 246);
  ctx.stroke();

  // Border frame
  ctx.lineWidth = 16;
  ctx.strokeStyle = '#644326';
  ctx.strokeRect(8, 8, 240, 240);

  // Metal corner brackets & rivets
  ctx.fillStyle = '#3a3a3a';
  ctx.fillRect(4, 4, 32, 32);
  ctx.fillRect(220, 4, 32, 32);
  ctx.fillRect(4, 220, 32, 32);
  ctx.fillRect(220, 220, 32, 32);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createGroundTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Dark industrial asphalt base with slate tone
  ctx.fillStyle = '#22252a';
  ctx.fillRect(0, 0, 512, 512);

  // Micro-aggregate grit texture
  for (let i = 0; i < 7000; i++) {
    const gx = Math.random() * 512;
    const gy = Math.random() * 512;
    const lum = Math.floor(Math.random() * 45 + 30);
    ctx.fillStyle = `rgb(${lum}, ${lum + 3}, ${lum + 6})`;
    ctx.fillRect(gx, gy, 2, 2);
  }

  // Asphalt expansion joint fissures
  ctx.strokeStyle = '#121417';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(80, 0);
  ctx.lineTo(160, 200);
  ctx.lineTo(290, 360);
  ctx.lineTo(460, 512);
  ctx.stroke();

  // Subtle wet tire track wear lanes
  ctx.fillStyle = 'rgba(15, 17, 21, 0.45)';
  ctx.fillRect(160, 0, 50, 512);
  ctx.fillRect(290, 0, 50, 512);

  // Vibrant yellow safety dividing lines (matching reference Image 2)
  ctx.fillStyle = '#eab308';
  ctx.fillRect(238, 0, 22, 512);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 12);
  return texture;
}

// Procedural roughness map for logical reflections (darker = glossy/reflective puddle, lighter = rough asphalt)
function createGroundRoughnessTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base asphalt roughness (~0.72)
  ctx.fillStyle = '#b8b8b8';
  ctx.fillRect(0, 0, 512, 512);

  // Smooth wet tire tracks & puddles (~0.25 - 0.35 roughness = high gloss reflections)
  ctx.fillStyle = '#444444';
  ctx.fillRect(160, 0, 50, 512);
  ctx.fillRect(290, 0, 50, 512);

  // Organic puddle spots reflecting sky and containers
  for (let i = 0; i < 4; i++) {
    const px = Math.random() * 400 + 50;
    const py = Math.random() * 400 + 50;
    const rad = Math.random() * 60 + 30;
    const grad = ctx.createRadialGradient(px, py, 5, px, py, rad);
    grad.addColorStop(0, '#282828'); // very glossy center
    grad.addColorStop(0.7, '#606060');
    grad.addColorStop(1, '#b8b8b8');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(px, py, rad, 0, Math.PI * 2);
    ctx.fill();
  }

  // Smooth yellow paint markings (glossy sheen)
  ctx.fillStyle = '#505050';
  ctx.fillRect(238, 0, 22, 512);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 12);
  return texture;
}

export function buildContainerYard(): MapData {
  const sceneGroup = new THREE.Group();
  sceneGroup.name = 'ContainerYardMap';

  const colliders: BoundingBox3D[] = [];

  // 1. Polished Textures & Highly Reflective Materials (Logical environmental reflections)
  const redMat = new THREE.MeshStandardMaterial({
    map: createContainerTexture('#992323', 'SYNCO 01'),
    roughness: 0.38,
    metalness: 0.58,
  });
  const blueMat = new THREE.MeshStandardMaterial({
    map: createContainerTexture('#1d4ed8', 'SYNCO LOGISTICS'),
    roughness: 0.38,
    metalness: 0.58,
  });
  const yellowMat = new THREE.MeshStandardMaterial({
    map: createContainerTexture('#d97706', 'SYNCO CARGO'),
    roughness: 0.38,
    metalness: 0.58,
  });
  const tealMat = new THREE.MeshStandardMaterial({
    map: createContainerTexture('#0f766e', 'EXPRESS FREIGHT'),
    roughness: 0.38,
    metalness: 0.58,
  });
  const crateMat = new THREE.MeshStandardMaterial({
    map: createCrateTexture(),
    roughness: 0.82,
    metalness: 0.12,
  });
  const barrelMat = new THREE.MeshStandardMaterial({
    color: 0x2563eb,
    roughness: 0.32,
    metalness: 0.75,
  });
  const groundMat = new THREE.MeshStandardMaterial({
    map: createGroundTexture(),
    roughnessMap: createGroundRoughnessTexture(),
    roughness: 0.65,
    metalness: 0.28,
  });
  const wallMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.65,
    metalness: 0.35,
  });
  const metalSteelMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.22,
    metalness: 0.90,
  });

  // 2. Ground Plane (64m x 64m)
  const groundGeo = new THREE.PlaneGeometry(64, 64);
  const groundMesh = new THREE.Mesh(groundGeo, groundMat);
  groundMesh.rotation.x = -Math.PI / 2;
  groundMesh.receiveShadow = true;
  sceneGroup.add(groundMesh);

  // 3. Perimeter Boundary Walls
  const wallHeight = 6;
  const wallThickness = 1.5;
  const perimeterConfigs = [
    { x: 0, z: -32, w: 64, d: wallThickness },
    { x: 0, z: 32, w: 64, d: wallThickness },
    { x: -32, z: 0, w: wallThickness, d: 64 },
    { x: 32, z: 0, w: wallThickness, d: 64 },
  ];

  perimeterConfigs.forEach((cfg) => {
    const geo = new THREE.BoxGeometry(cfg.w, wallHeight, cfg.d);
    const mesh = new THREE.Mesh(geo, wallMat);
    mesh.position.set(cfg.x, wallHeight / 2, cfg.z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    sceneGroup.add(mesh);

    colliders.push({
      minX: cfg.x - cfg.w / 2,
      maxX: cfg.x + cfg.w / 2,
      minY: 0,
      maxY: wallHeight,
      minZ: cfg.z - cfg.d / 2,
      maxZ: cfg.z + cfg.d / 2,
      surface: 'concrete',
      name: 'PerimeterWall',
    });
  });

  // Helper to add shipping containers
  // Standard container size: 6.0m length x 2.4m width x 2.6m height
  const containerGeo = new THREE.BoxGeometry(6.0, 2.6, 2.4);

  function addContainer(
    x: number,
    yBottom: number,
    z: number,
    rotY: number,
    mat: THREE.MeshStandardMaterial,
    name: string = 'Container'
  ) {
    const mesh = new THREE.Mesh(containerGeo, mat);
    mesh.position.set(x, yBottom + 1.3, z);
    mesh.rotation.y = rotY;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    sceneGroup.add(mesh);

    // Compute oriented bounding box approximation for AABB collision
    const isRotated = Math.abs(Math.sin(rotY)) > 0.5;
    const halfX = (isRotated ? 2.4 : 6.0) / 2;
    const halfZ = (isRotated ? 6.0 : 2.4) / 2;

    colliders.push({
      minX: x - halfX,
      maxX: x + halfX,
      minY: yBottom,
      maxY: yBottom + 2.6,
      minZ: z - halfZ,
      maxZ: z + halfZ,
      surface: 'metal',
      name,
    });
  }

  // 4. Strategic Container Layout (faithful to screenshots with narrow passages, open central zone, stacked blocks)
  // Left Zone Stacks (Blue side)
  addContainer(-14, 0, -10, 0, redMat, 'RedContainer');
  addContainer(-14, 2.6, -10, 0, yellowMat, 'YellowContainer');
  addContainer(-14, 0, -14, 0, blueMat, 'BlueContainer');

  addContainer(-8, 0, -18, Math.PI / 2, tealMat, 'TealContainer');
  addContainer(-8, 2.6, -18, Math.PI / 2, redMat, 'RedContainer');

  addContainer(-20, 0, -4, Math.PI / 2, blueMat, 'BlueContainer');
  addContainer(-20, 0, 4, Math.PI / 2, yellowMat, 'YellowContainer');

  // Center Flanking Containers
  addContainer(-6, 0, 0, 0, redMat, 'CenterLeftContainer');
  addContainer(6, 0, 0, 0, blueMat, 'CenterRightContainer');

  // Open Container Tunnel at Center-North (Walk-in feature from Screenshot 2!)
  // Built with side walls and roof so players can run through the interior
  const openContGroup = new THREE.Group();
  openContGroup.position.set(0, 0, -8);
  const sideWallGeo = new THREE.BoxGeometry(6.0, 2.6, 0.2);
  const roofGeo = new THREE.BoxGeometry(6.0, 0.2, 2.4);

  const leftWall = new THREE.Mesh(sideWallGeo, redMat);
  leftWall.position.set(0, 1.3, -1.1);
  leftWall.castShadow = true;
  leftWall.receiveShadow = true;
  openContGroup.add(leftWall);

  const rightWall = new THREE.Mesh(sideWallGeo, redMat);
  rightWall.position.set(0, 1.3, 1.1);
  rightWall.castShadow = true;
  rightWall.receiveShadow = true;
  openContGroup.add(rightWall);

  const roof = new THREE.Mesh(roofGeo, redMat);
  roof.position.set(0, 2.5, 0);
  roof.castShadow = true;
  roof.receiveShadow = true;
  openContGroup.add(roof);

  // Open Door Panel flapping outward (as seen in Screenshot 2!)
  const doorGeo = new THREE.BoxGeometry(0.1, 2.4, 1.1);
  const openDoor = new THREE.Mesh(doorGeo, redMat);
  openDoor.position.set(3.0, 1.2, 1.5);
  openDoor.rotation.y = -Math.PI / 3;
  openDoor.castShadow = true;
  openContGroup.add(openDoor);

  sceneGroup.add(openContGroup);

  colliders.push({
    minX: -3.0,
    maxX: 3.0,
    minY: 0,
    maxY: 2.6,
    minZ: -8 - 1.2,
    maxZ: -8 - 1.0,
    surface: 'metal',
    name: 'OpenContainerLeftWall',
  });
  colliders.push({
    minX: -3.0,
    maxX: 3.0,
    minY: 0,
    maxY: 2.6,
    minZ: -8 + 1.0,
    maxZ: -8 + 1.2,
    surface: 'metal',
    name: 'OpenContainerRightWall',
  });

  // Right Zone Stacks (Red side)
  addContainer(14, 0, 10, 0, blueMat, 'BlueContainer');
  addContainer(14, 2.6, 10, 0, redMat, 'RedContainer');
  addContainer(14, 0, 14, 0, tealMat, 'TealContainer');

  addContainer(8, 0, 18, Math.PI / 2, yellowMat, 'YellowContainer');
  addContainer(8, 2.6, 18, Math.PI / 2, blueMat, 'BlueContainer');

  addContainer(20, 0, 4, Math.PI / 2, redMat, 'RedContainer');
  addContainer(20, 0, -4, Math.PI / 2, tealMat, 'TealContainer');

  // Southern Corridors
  addContainer(-10, 0, 14, 0, yellowMat, 'YellowContainer');
  addContainer(-4, 0, 18, Math.PI / 2, blueMat, 'BlueContainer');

  // Northern Corridors
  addContainer(10, 0, -14, 0, redMat, 'RedContainer');
  addContainer(4, 0, -18, Math.PI / 2, yellowMat, 'YellowContainer');

  // 5. Central Watchtower (Screenshot 3 Reference)
  const towerGroup = new THREE.Group();
  towerGroup.position.set(0, 0, 8);

  const legGeo = new THREE.CylinderGeometry(0.12, 0.12, 6.5, 8);
  const legPositions = [
    [-1.6, -1.6],
    [1.6, -1.6],
    [-1.6, 1.6],
    [1.6, 1.6],
  ];

  legPositions.forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(legGeo, metalSteelMat);
    leg.position.set(lx, 3.25, lz);
    leg.castShadow = true;
    towerGroup.add(leg);
  });

  // Cross braces
  const braceGeo = new THREE.CylinderGeometry(0.06, 0.06, 4.5, 6);
  const brace1 = new THREE.Mesh(braceGeo, metalSteelMat);
  brace1.position.set(0, 3.25, -1.6);
  brace1.rotation.z = Math.PI / 4;
  towerGroup.add(brace1);

  // Platform at top
  const platformGeo = new THREE.BoxGeometry(4.0, 0.25, 4.0);
  const platform = new THREE.Mesh(platformGeo, metalSteelMat);
  platform.position.set(0, 6.5, 0);
  platform.castShadow = true;
  platform.receiveShadow = true;
  towerGroup.add(platform);

  // Platform Railing
  const railingGeo = new THREE.BoxGeometry(4.0, 0.9, 0.08);
  const railNorth = new THREE.Mesh(railingGeo, metalSteelMat);
  railNorth.position.set(0, 7.05, -2.0);
  towerGroup.add(railNorth);

  const railSouth = new THREE.Mesh(railingGeo, metalSteelMat);
  railSouth.position.set(0, 7.05, 2.0);
  towerGroup.add(railSouth);

  // Tower Roof Canopy
  const roofCanopyGeo = new THREE.ConeGeometry(2.8, 1.2, 4);
  const roofCanopy = new THREE.Mesh(roofCanopyGeo, redMat);
  roofCanopy.position.set(0, 8.8, 0);
  roofCanopy.rotation.y = Math.PI / 4;
  towerGroup.add(roofCanopy);

  // Red beacon light at tower apex
  const beaconGeo = new THREE.SphereGeometry(0.2, 8, 8);
  const beaconMat = new THREE.MeshBasicMaterial({ color: 0xff1100 });
  const beacon = new THREE.Mesh(beaconGeo, beaconMat);
  beacon.position.set(0, 9.6, 0);
  towerGroup.add(beacon);

  sceneGroup.add(towerGroup);

  // Tower base collider
  colliders.push({
    minX: -1.8,
    maxX: 1.8,
    minY: 0,
    maxY: 7.0,
    minZ: 8 - 1.8,
    maxZ: 8 + 1.8,
    surface: 'metal',
    name: 'CenterWatchtower',
  });

  // 6. Tactical Wooden Crates for Cover
  const crateConfigs = [
    { x: -3, z: -3, s: 1.2 },
    { x: -3, z: -1.8, s: 1.0 },
    { x: 3, z: 3, s: 1.2 },
    { x: 3, z: 1.8, s: 1.0 },
    { x: -11, z: 3, s: 1.4 },
    { x: -11, z: 4.4, s: 1.1 },
    { x: 11, z: -3, s: 1.4 },
    { x: 11, z: -4.4, s: 1.1 },
    { x: -16, z: -18, s: 1.2 },
    { x: 16, z: 18, s: 1.2 },
    { x: 0, z: 18, s: 1.5 },
    { x: 0, z: -18, s: 1.5 },
  ];

  crateConfigs.forEach((c, idx) => {
    const geo = new THREE.BoxGeometry(c.s, c.s, c.s);
    const mesh = new THREE.Mesh(geo, crateMat);
    mesh.position.set(c.x, c.s / 2, c.z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    sceneGroup.add(mesh);

    colliders.push({
      minX: c.x - c.s / 2,
      maxX: c.x + c.s / 2,
      minY: 0,
      maxY: c.s,
      minZ: c.z - c.s / 2,
      maxZ: c.z + c.s / 2,
      surface: 'wood',
      name: `Crate_${idx}`,
    });
  });

  // 7. Metal Oil Barrels
  const barrelGeo = new THREE.CylinderGeometry(0.42, 0.42, 1.1, 12);
  const barrelConfigs = [
    { x: -6, z: 6 },
    { x: -5.2, z: 6.2 },
    { x: 6, z: -6 },
    { x: 5.2, z: -6.2 },
    { x: -17, z: 12 },
    { x: 17, z: -12 },
  ];

  barrelConfigs.forEach((b, idx) => {
    const mesh = new THREE.Mesh(barrelGeo, barrelMat);
    mesh.position.set(b.x, 0.55, b.z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    sceneGroup.add(mesh);

    colliders.push({
      minX: b.x - 0.45,
      maxX: b.x + 0.45,
      minY: 0,
      maxY: 1.1,
      minZ: b.z - 0.45,
      maxZ: b.z + 0.45,
      surface: 'metal',
      name: `Barrel_${idx}`,
    });
  });

  // 8. Yard Light Poles (Industrial orange/warm spotlights)
  const poleGeo = new THREE.CylinderGeometry(0.1, 0.12, 6.0, 8);
  const polePositions = [
    [-18, -18],
    [18, 18],
    [-18, 18],
    [18, -18],
  ];

  polePositions.forEach(([px, pz]) => {
    const pole = new THREE.Mesh(poleGeo, metalSteelMat);
    pole.position.set(px, 3.0, pz);
    pole.castShadow = true;
    sceneGroup.add(pole);

    const headGeo = new THREE.BoxGeometry(0.6, 0.3, 0.4);
    const head = new THREE.Mesh(headGeo, wallMat);
    head.position.set(px, 6.0, pz);
    sceneGroup.add(head);
  });

  // 9. Waypoint Graph for Bot Navigation & Strategic Movement
  const waypoints: Waypoint[] = [
    { x: -18, z: -18 },
    { x: -14, z: -4 },
    { x: -14, z: 6 },
    { x: -6, z: -8, isCover: true },
    { x: 0, z: -8 }, // inside open container
    { x: 6, z: -8, isCover: true },
    { x: -3, z: 0 },
    { x: 3, z: 0 },
    { x: 0, z: 4, isCover: true },
    { x: 0, z: 14 },
    { x: 14, z: -6 },
    { x: 14, z: 6 },
    { x: 18, z: 18 },
    { x: 8, z: 14, isCover: true },
    { x: -8, z: 14, isCover: true },
    { x: -20, z: 10 },
    { x: 20, z: -10 },
  ];

  // 10. Team Spawn Points
  const spawnPoints = {
    blue: [
      new THREE.Vector3(-22, 0, -22),
      new THREE.Vector3(-22, 0, -14),
      new THREE.Vector3(-14, 0, -22),
    ],
    red: [
      new THREE.Vector3(22, 0, 22),
      new THREE.Vector3(22, 0, 14),
      new THREE.Vector3(14, 0, 22),
    ],
  };

  return {
    sceneGroup,
    colliders,
    waypoints,
    spawnPoints,
  };
}
