export type GameMode = 'bot' | 'multiplayer_host' | 'multiplayer_client';

export type Team = 'blue' | 'red';

export type SurfaceType = 'metal' | 'wood' | 'concrete' | 'flesh';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export type PeekDirection = 'left' | 'center' | 'right';

export interface PlayerInput {
  moveForward: number; // -1 to 1
  moveRight: number; // -1 to 1
  lookDeltaX: number;
  lookDeltaY: number;
  isFiring: boolean;
  isAiming: boolean;
  isJumping: boolean;
  isCrouching: boolean;
  isReloading: boolean;
  peek: PeekDirection;
}

export interface HitEvent {
  position: Vector3D;
  normal: Vector3D;
  surface: SurfaceType;
  isHeadshot?: boolean;
}

export interface NetworkPlayerState {
  id: string;
  team: Team;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  isAiming: boolean;
  isFiring: boolean;
  isCrouching: boolean;
  health: number;
  score: number;
  timestamp: number;
}

export interface NetworkMessage {
  type:
    | 'host_room'
    | 'room_created'
    | 'join_room'
    | 'room_joined'
    | 'player_joined'
    | 'player_left'
    | 'player_update'
    | 'shoot_event'
    | 'hit_event'
    | 'player_respawn'
    | 'match_end'
    | 'error';
  roomCode?: string;
  playerId?: string;
  playerState?: NetworkPlayerState;
  targetId?: string;
  damage?: number;
  hitPos?: Vector3D;
  hitNormal?: Vector3D;
  surface?: SurfaceType;
  message?: string;
  winner?: Team | 'draw';
}

export interface Waypoint {
  x: number;
  z: number;
  isCover?: boolean;
}

export interface BoundingBox3D {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
  surface: SurfaceType;
  name?: string;
}

export interface GameSettings {
  mouseSensitivity: number;
  touchSensitivity: number;
  soundVolume: number;
  graphicsQuality: 'high' | 'medium' | 'performance';
  invertY: boolean;
}
