export interface MatchState {
  blueScore: number;
  redScore: number;
  timeLeftSeconds: number;
  isGameOver: boolean;
  winner: 'blue' | 'red' | 'draw' | null;
  targetKills: number;
}

export interface PlayerStats {
  health: number;
  maxHealth: number;
  ammo: number;
  maxAmmo: number;
  reserveAmmo: number;
  kills: number;
  deaths: number;
  shotsFired: number;
  shotsHit: number;
  headshots: number;
}

export const MATCH_SETTINGS = {
  DEFAULT_MATCH_TIME_SECONDS: 180, // 3 minutes
  TARGET_KILLS_TO_WIN: 5,
  RESPAWN_DELAY_SECONDS: 3,
  BASE_DAMAGE_BODY: 28,
  BASE_DAMAGE_HEAD: 56,
  MAX_HEALTH: 100,
  MAGAZINE_SIZE: 30,
  MAX_RESERVE_AMMO: 90,
  FIRE_RATE_DELAY_MS: 110, // ~550 RPM arcade rifle
  RELOAD_TIME_MS: 1800,
};

export function createInitialMatchState(
  targetKills: number = MATCH_SETTINGS.TARGET_KILLS_TO_WIN,
  duration: number = MATCH_SETTINGS.DEFAULT_MATCH_TIME_SECONDS
): MatchState {
  return {
    blueScore: 0,
    redScore: 0,
    timeLeftSeconds: duration,
    isGameOver: false,
    winner: null,
    targetKills,
  };
}

export function createInitialPlayerStats(): PlayerStats {
  return {
    health: MATCH_SETTINGS.MAX_HEALTH,
    maxHealth: MATCH_SETTINGS.MAX_HEALTH,
    ammo: MATCH_SETTINGS.MAGAZINE_SIZE,
    maxAmmo: MATCH_SETTINGS.MAGAZINE_SIZE,
    reserveAmmo: MATCH_SETTINGS.MAX_RESERVE_AMMO,
    kills: 0,
    deaths: 0,
    shotsFired: 0,
    shotsHit: 0,
    headshots: 0,
  };
}

export function calculateDamage(isHeadshot: boolean): number {
  return isHeadshot ? MATCH_SETTINGS.BASE_DAMAGE_HEAD : MATCH_SETTINGS.BASE_DAMAGE_BODY;
}

export function applyDamageToHealth(currentHealth: number, damage: number): {
  newHealth: number;
  isDefeated: boolean;
} {
  const newHealth = Math.max(0, currentHealth - damage);
  return {
    newHealth,
    isDefeated: newHealth <= 0,
  };
}

export function calculateReload(currentAmmo: number, reserveAmmo: number): {
  newAmmo: number;
  newReserveAmmo: number;
  roundsLoaded: number;
} {
  const needed = MATCH_SETTINGS.MAGAZINE_SIZE - currentAmmo;
  if (needed <= 0 || reserveAmmo <= 0) {
    return { newAmmo: currentAmmo, newReserveAmmo: reserveAmmo, roundsLoaded: 0 };
  }
  const roundsToLoad = Math.min(needed, reserveAmmo);
  return {
    newAmmo: currentAmmo + roundsToLoad,
    newReserveAmmo: reserveAmmo - roundsToLoad,
    roundsLoaded: roundsToLoad,
  };
}

export function updateMatchScore(
  state: MatchState,
  scoringTeam: 'blue' | 'red'
): MatchState {
  if (state.isGameOver) return state;

  const nextBlue = scoringTeam === 'blue' ? state.blueScore + 1 : state.blueScore;
  const nextRed = scoringTeam === 'red' ? state.redScore + 1 : state.redScore;

  let isGameOver = false;
  let winner: 'blue' | 'red' | 'draw' | null = null;

  if (nextBlue >= state.targetKills) {
    isGameOver = true;
    winner = 'blue';
  } else if (nextRed >= state.targetKills) {
    isGameOver = true;
    winner = 'red';
  }

  return {
    ...state,
    blueScore: nextBlue,
    redScore: nextRed,
    isGameOver,
    winner,
  };
}

export function tickMatchTimer(state: MatchState, deltaSeconds: number): MatchState {
  if (state.isGameOver) return state;

  const nextTime = Math.max(0, state.timeLeftSeconds - deltaSeconds);
  if (nextTime <= 0) {
    let winner: 'blue' | 'red' | 'draw' = 'draw';
    if (state.blueScore > state.redScore) winner = 'blue';
    else if (state.redScore > state.blueScore) winner = 'red';

    return {
      ...state,
      timeLeftSeconds: 0,
      isGameOver: true,
      winner,
    };
  }

  return {
    ...state,
    timeLeftSeconds: nextTime,
  };
}

export function formatGameTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export function calculateAccuracy(shotsFired: number, shotsHit: number): number {
  if (shotsFired <= 0) return 0;
  return Math.min(100, Math.round((shotsHit / shotsFired) * 100));
}

export function calculatePeekOffset(
  peekDir: 'left' | 'center' | 'right',
  maxOffset: number = 0.38
): { lateralOffset: number; rollAngle: number } {
  if (peekDir === 'left') {
    return { lateralOffset: -maxOffset, rollAngle: 0.14 };
  }
  if (peekDir === 'right') {
    return { lateralOffset: maxOffset, rollAngle: -0.14 };
  }
  return { lateralOffset: 0, rollAngle: 0 };
}
