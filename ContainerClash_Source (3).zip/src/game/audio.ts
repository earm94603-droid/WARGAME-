/**
 * Procedural Web Audio synthesizer for Container Clash.
 * Generates all gunfire, bullet impacts, mechanical weapon sounds,
 * footsteps, and tactical cues on-the-fly with zero external dependencies.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private volume: number = 0.8;
  private isMuted: boolean = false;
  private lastFootstepTime: number = 0;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    this.setVolume(this.volume);
    return this.isMuted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Ultra-realistic tactical M4 assault rifle shot:
   * 1. Sub-bass kinetic body punch (190Hz -> 38Hz transient drop)
   * 2. Powder explosion noise blast with steep bandpass resonance
   * 3. Metallic bolt carrier group snap
   * 4. Industrial container yard slapback echo tail
   */
  public playGunshot(isLocal: boolean = true) {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const vol = isLocal ? 0.95 : 0.48;

    // 1. Sub-bass punch oscillator (visceral chest-thumping low end)
    const kickOsc = this.ctx.createOscillator();
    const kickGain = this.ctx.createGain();
    kickOsc.type = 'sine';
    kickOsc.frequency.setValueAtTime(190, t);
    kickOsc.frequency.exponentialRampToValueAtTime(38, t + 0.09);

    kickGain.gain.setValueAtTime(vol * 1.25, t);
    kickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.13);

    kickOsc.connect(kickGain);
    kickGain.connect(this.masterGain);
    kickOsc.start(t);
    kickOsc.stop(t + 0.14);

    // 2. High-speed powder explosion noise burst (super crisp attack)
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.22);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      // Exponential power curve for explosive initial attack
      const envelope = Math.exp(-i / (this.ctx.sampleRate * 0.028));
      data[i] = (Math.random() * 2 - 1) * envelope;
    }

    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = buffer;

    // Dual-stage filter for rifle body resonance
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(isLocal ? 1450 : 900, t);
    filter.Q.setValueAtTime(2.4, t);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(vol * 1.1, t);
    noiseGain.gain.exponentialRampToValueAtTime(0.005, t + 0.15);

    noiseSource.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.masterGain);
    noiseSource.start(t);

    // 3. Metallic bolt carrier snap (crisp mechanical assault rifle action)
    const boltOsc = this.ctx.createOscillator();
    const boltGain = this.ctx.createGain();
    boltOsc.type = 'triangle';
    boltOsc.frequency.setValueAtTime(2400, t + 0.005);
    boltOsc.frequency.exponentialRampToValueAtTime(750, t + 0.035);

    boltGain.gain.setValueAtTime(0, t);
    boltGain.gain.setValueAtTime(vol * 0.45, t + 0.005);
    boltGain.gain.exponentialRampToValueAtTime(0.001, t + 0.045);

    boltOsc.connect(boltGain);
    boltGain.connect(this.masterGain);
    boltOsc.start(t + 0.005);
    boltOsc.stop(t + 0.05);

    // 4. Industrial container yard slapback echo tail (reflections between metal containers)
    if (isLocal) {
      const echoDelays = [0.038, 0.076, 0.115];
      echoDelays.forEach((delayTime, idx) => {
        const echoGain = this.ctx!.createGain();
        const decay = 0.22 / (idx + 1);
        echoGain.gain.setValueAtTime(vol * decay, t + delayTime);
        echoGain.gain.exponentialRampToValueAtTime(0.001, t + delayTime + 0.12);

        const echoFilter = this.ctx!.createBiquadFilter();
        echoFilter.type = 'lowpass';
        echoFilter.frequency.setValueAtTime(850 - idx * 150, t + delayTime);

        const echoNoise = this.ctx!.createBufferSource();
        echoNoise.buffer = buffer;
        echoNoise.connect(echoFilter);
        echoFilter.connect(echoGain);
        echoGain.connect(this.masterGain!);
        echoNoise.start(t + delayTime);
      });

      // Brass casing bouncing on ground
      setTimeout(() => this.playShellCasing(), 110);
    }
  }

  /**
   * Shell casing bouncing on asphalt
   */
  public playShellCasing() {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    const baseFreq = 2800 + Math.random() * 600;
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.7, t + 0.05);

    gain.gain.setValueAtTime(0.08, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.06);
  }

  /**
   * Surface bullet impacts
   */
  public playImpact(surface: 'metal' | 'wood' | 'concrete' | 'flesh') {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;

    if (surface === 'metal') {
      // High pitch metallic ping
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1900 + Math.random() * 500, t);
      osc.frequency.exponentialRampToValueAtTime(600, t + 0.12);

      gain.gain.setValueAtTime(0.35, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.15);
    } else if (surface === 'wood') {
      // Hollow low thud
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(220, t);
      osc.frequency.exponentialRampToValueAtTime(70, t + 0.09);

      gain.gain.setValueAtTime(0.4, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.11);
    } else if (surface === 'concrete') {
      // Crunchy dust noise
      const bufferSize = this.ctx.sampleRate * 0.08;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.015));
      }
      const source = this.ctx.createBufferSource();
      source.buffer = buffer;
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.08);

      source.connect(gain);
      gain.connect(this.masterGain);
      source.start(t);
    } else {
      // Flesh / player hit impact
      this.playHitmarker(false);
    }
  }

  /**
   * Crisp tactical hit confirmation chime
   */
  public playHitmarker(isHeadshot: boolean = false) {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';

    const freq = isHeadshot ? 2400 : 1600;
    osc.frequency.setValueAtTime(freq, t);
    osc.frequency.setValueAtTime(freq * 1.25, t + 0.03);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.1);
  }

  /**
   * Player receives damage
   */
  public playPlayerHurt() {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(110, t);
    osc.frequency.exponentialRampToValueAtTime(45, t + 0.2);

    gain.gain.setValueAtTime(0.45, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.23);
  }

  /**
   * Reload sequence: click-clack mechanical sound
   */
  public playReload() {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;

    // Mag out click
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(450, t);
    osc1.frequency.exponentialRampToValueAtTime(120, t + 0.06);
    gain1.gain.setValueAtTime(0.25, t);
    gain1.gain.exponentialRampToValueAtTime(0.01, t + 0.07);
    osc1.connect(gain1);
    gain1.connect(this.masterGain);
    osc1.start(t);
    osc1.stop(t + 0.08);

    // Mag in click (at 0.7s)
    setTimeout(() => {
      if (!this.ctx || !this.masterGain || this.isMuted) return;
      const t2 = this.ctx.currentTime;
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(320, t2);
      osc2.frequency.exponentialRampToValueAtTime(600, t2 + 0.08);
      gain2.gain.setValueAtTime(0.3, t2);
      gain2.gain.exponentialRampToValueAtTime(0.01, t2 + 0.09);
      osc2.connect(gain2);
      gain2.connect(this.masterGain);
      osc2.start(t2);
      osc2.stop(t2 + 0.1);
    }, 700);

    // Bolt rack slide release (at 1.3s)
    setTimeout(() => {
      if (!this.ctx || !this.masterGain || this.isMuted) return;
      const t3 = this.ctx.currentTime;
      const osc3 = this.ctx.createOscillator();
      const gain3 = this.ctx.createGain();
      osc3.type = 'sawtooth';
      osc3.frequency.setValueAtTime(800, t3);
      osc3.frequency.exponentialRampToValueAtTime(250, t3 + 0.12);
      gain3.gain.setValueAtTime(0.25, t3);
      gain3.gain.exponentialRampToValueAtTime(0.01, t3 + 0.14);
      osc3.connect(gain3);
      gain3.connect(this.masterGain);
      osc3.start(t3);
      osc3.stop(t3 + 0.15);
    }, 1250);
  }

  /**
   * Footsteps
   */
  public playFootstep(isRunning: boolean = false) {
    const now = performance.now();
    const interval = isRunning ? 280 : 420;
    if (now - this.lastFootstepTime < interval) return;
    this.lastFootstepTime = now;

    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(85 + Math.random() * 25, t);
    osc.frequency.exponentialRampToValueAtTime(35, t + 0.06);

    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.08);
  }

  /**
   * Jump whoosh
   */
  public playJump() {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, t);
    osc.frequency.exponentialRampToValueAtTime(350, t + 0.1);
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.13);
  }

  /**
   * UI Click
   */
  public playUiClick() {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, t);
    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.05);
  }

  /**
   * Victory sound sting
   */
  public playVictory() {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((freq, idx) => {
      setTimeout(() => {
        if (!this.ctx || !this.masterGain || this.isMuted) return;
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(t);
        osc.stop(t + 0.45);
      }, idx * 110);
    });
  }

  /**
   * Defeat sound sting
   */
  public playDefeat() {
    this.initContext();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const notes = [440, 415.3, 370, 311.13];
    notes.forEach((freq, idx) => {
      setTimeout(() => {
        if (!this.ctx || !this.masterGain || this.isMuted) return;
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(0.25, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(t);
        osc.stop(t + 0.4);
      }, idx * 150);
    });
  }
}

export const soundEngine = new SoundEngine();
