import { NetworkPlayerState, Team, Vector3D } from './types.ts';

export interface NetworkCallbacks {
  onRoomCreated?: (roomCode: string, playerId: string) => void;
  onRoomJoined?: (roomCode: string, playerId: string, team: Team) => void;
  onMatchStart?: (players: { id: string; team: Team }[]) => void;
  onOpponentUpdate?: (state: NetworkPlayerState) => void;
  onOpponentShoot?: (origin: Vector3D, direction: Vector3D) => void;
  onDamageApplied?: (damage: number, newHealth: number, isHeadshot: boolean) => void;
  onScoreUpdate?: (blueScore: number, redScore: number, winner: Team | null) => void;
  onRespawn?: () => void;
  onPlayerDisconnected?: (message: string) => void;
  onError?: (error: string) => void;
}

export class NetworkClient {
  private ws: WebSocket | null = null;
  private callbacks: NetworkCallbacks;
  public isConnected: boolean = false;
  public roomCode: string | null = null;
  public playerId: string | null = null;
  public myTeam: Team = 'blue';

  constructor(callbacks: NetworkCallbacks) {
    this.callbacks = callbacks;
  }

  public connect(): Promise<boolean> {
    return new Promise((resolve) => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        resolve(true);
        return;
      }

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;

      try {
        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
          this.isConnected = true;
          resolve(true);
        };

        this.ws.onerror = () => {
          this.isConnected = false;
          resolve(false);
        };

        this.ws.onclose = () => {
          this.isConnected = false;
          if (this.callbacks.onPlayerDisconnected) {
            this.callbacks.onPlayerDisconnected('Connection closed.');
          }
        };

        this.ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            this.handleMessage(data);
          } catch {
            // ignore
          }
        };
      } catch {
        resolve(false);
      }
    });
  }

  private handleMessage(msg: {
    type: string;
    roomCode?: string;
    playerId?: string;
    team?: Team;
    players?: { id: string; team: Team }[];
    playerState?: NetworkPlayerState;
    origin?: Vector3D;
    direction?: Vector3D;
    damage?: number;
    newHealth?: number;
    isHeadshot?: boolean;
    blueScore?: number;
    redScore?: number;
    winner?: Team | null;
    message?: string;
  }) {
    switch (msg.type) {
      case 'room_created':
        this.roomCode = msg.roomCode || null;
        this.playerId = msg.playerId || null;
        this.myTeam = 'blue';
        this.callbacks.onRoomCreated?.(this.roomCode!, this.playerId!);
        break;
      case 'room_joined':
        this.roomCode = msg.roomCode || null;
        this.playerId = msg.playerId || null;
        this.myTeam = msg.team || 'red';
        this.callbacks.onRoomJoined?.(this.roomCode!, this.playerId!, this.myTeam);
        break;
      case 'match_start':
        this.callbacks.onMatchStart?.(msg.players || []);
        break;
      case 'opponent_update':
        if (msg.playerState) {
          this.callbacks.onOpponentUpdate?.(msg.playerState);
        }
        break;
      case 'opponent_shoot':
        if (msg.origin && msg.direction) {
          this.callbacks.onOpponentShoot?.(msg.origin, msg.direction);
        }
        break;
      case 'damage_applied':
        this.callbacks.onDamageApplied?.(
          msg.damage || 0,
          msg.newHealth || 0,
          !!msg.isHeadshot
        );
        break;
      case 'score_update':
        this.callbacks.onScoreUpdate?.(
          msg.blueScore || 0,
          msg.redScore || 0,
          msg.winner || null
        );
        break;
      case 'respawn_player':
        this.callbacks.onRespawn?.();
        break;
      case 'player_disconnected':
        this.callbacks.onPlayerDisconnected?.(msg.message || 'Opponent disconnected.');
        break;
      case 'error':
        this.callbacks.onError?.(msg.message || 'Unknown network error');
        break;
    }
  }

  public hostRoom() {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'create_room' }));
  }

  public joinRoom(roomCode: string) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'join_room', roomCode }));
  }

  public sendPlayerUpdate(state: NetworkPlayerState) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'player_update', playerState: state }));
  }

  public sendShoot(origin: Vector3D, direction: Vector3D) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'shoot_event', origin, direction }));
  }

  public sendHit(targetId: string, damage: number, isHeadshot: boolean) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ type: 'hit_damage', targetId, damage, isHeadshot }));
  }

  public disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
      this.isConnected = false;
    }
  }
}
