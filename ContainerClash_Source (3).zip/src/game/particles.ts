import * as THREE from 'three';
import { SurfaceType, Vector3D } from './types.ts';

interface Particle {
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  color: THREE.Color;
  size: number;
  life: number;
  maxLife: number;
  active: boolean;
}

interface BulletTracer {
  line: THREE.Line;
  material: THREE.LineBasicMaterial;
  life: number;
  maxLife: number;
  active: boolean;
}

interface DecalMark {
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
  active: boolean;
}

export class ParticleSystem {
  public scene: THREE.Scene;

  // Pre-allocated particle pool
  private maxParticles = 250;
  private particles: Particle[] = [];
  private particleGeometry: THREE.BufferGeometry;
  private particlePositions: Float32Array;
  private particleColors: Float32Array;
  private particleSizes: Float32Array;
  private pointsMesh: THREE.Points;

  // Bullet tracers pool
  private tracers: BulletTracer[] = [];
  private maxTracers = 16;

  // Decal marks pool
  private decals: DecalMark[] = [];
  private maxDecals = 30;

  constructor(scene: THREE.Scene) {
    this.scene = scene;

    // 1. Initialize Points for Particles
    this.particlePositions = new Float32Array(this.maxParticles * 3);
    this.particleColors = new Float32Array(this.maxParticles * 3);
    this.particleSizes = new Float32Array(this.maxParticles);

    this.particleGeometry = new THREE.BufferGeometry();
    this.particleGeometry.setAttribute(
      'position',
      new THREE.BufferAttribute(this.particlePositions, 3)
    );
    this.particleGeometry.setAttribute(
      'color',
      new THREE.BufferAttribute(this.particleColors, 3)
    );
    this.particleGeometry.setAttribute(
      'size',
      new THREE.BufferAttribute(this.particleSizes, 1)
    );

    // Canvas particle texture (soft circle)
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 32;
    pCanvas.height = 32;
    const pCtx = pCanvas.getContext('2d')!;
    const grad = pCtx.createRadialGradient(16, 16, 0, 16, 16, 16);
    grad.addColorStop(0, 'rgba(255,255,255,1)');
    grad.addColorStop(0.5, 'rgba(255,255,255,0.7)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    pCtx.fillStyle = grad;
    pCtx.fillRect(0, 0, 32, 32);

    const pTex = new THREE.CanvasTexture(pCanvas);

    const pointsMat = new THREE.PointsMaterial({
      size: 0.15,
      vertexColors: true,
      map: pTex,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    this.pointsMesh = new THREE.Points(this.particleGeometry, pointsMat);
    this.pointsMesh.frustumCulled = false;
    this.scene.add(this.pointsMesh);

    for (let i = 0; i < this.maxParticles; i++) {
      this.particles.push({
        position: new THREE.Vector3(0, -999, 0),
        velocity: new THREE.Vector3(),
        color: new THREE.Color(),
        size: 0.1,
        life: 0,
        maxLife: 1,
        active: false,
      });
    }

    // 2. Initialize Tracer lines pool
    for (let i = 0; i < this.maxTracers; i++) {
      const geo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, -999, 0),
        new THREE.Vector3(0, -999, 0),
      ]);
      const mat = new THREE.LineBasicMaterial({
        color: 0xffe680,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
      });
      const line = new THREE.Line(geo, mat);
      line.frustumCulled = false;
      this.scene.add(line);
      this.tracers.push({
        line,
        material: mat,
        life: 0,
        maxLife: 0.08,
        active: false,
      });
    }

    // 3. Initialize Decals pool
    const decalGeo = new THREE.PlaneGeometry(0.18, 0.18);
    const decalMat = new THREE.MeshBasicMaterial({
      color: 0x111111,
      transparent: true,
      opacity: 0.8,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });

    for (let i = 0; i < this.maxDecals; i++) {
      const mesh = new THREE.Mesh(decalGeo, decalMat.clone());
      mesh.position.set(0, -999, 0);
      mesh.visible = false;
      this.scene.add(mesh);
      this.decals.push({
        mesh,
        life: 0,
        maxLife: 12.0, // fades after 12 seconds
        active: false,
      });
    }
  }

  /**
   * Spawns bullet tracer streak
   */
  public spawnTracer(from: THREE.Vector3, to: THREE.Vector3) {
    const tracer = this.tracers.find((t) => !t.active) || this.tracers[0];
    tracer.active = true;
    tracer.life = 0;
    tracer.material.opacity = 0.9;

    const posAttr = tracer.line.geometry.attributes.position as THREE.BufferAttribute;
    posAttr.setXYZ(0, from.x, from.y, from.z);
    posAttr.setXYZ(1, to.x, to.y, to.z);
    posAttr.needsUpdate = true;
  }

  /**
   * Spawns surface impact particle burst
   */
  public spawnImpact(
    position: Vector3D,
    normal: Vector3D,
    surface: SurfaceType
  ) {
    const pos = new THREE.Vector3(position.x, position.y, position.z);
    const norm = new THREE.Vector3(normal.x, normal.y, normal.z).normalize();

    // Determine particle count & colors by surface
    let count = 12;
    let baseColor = new THREE.Color(0xff9922);
    let speed = 4.5;
    let maxLife = 0.35;

    if (surface === 'metal') {
      // Sparks
      count = 16;
      baseColor = new THREE.Color(0xffdd44);
      speed = 6.0;
      maxLife = 0.45;
    } else if (surface === 'wood') {
      // Wooden splinters
      count = 10;
      baseColor = new THREE.Color(0x9b7653);
      speed = 3.5;
      maxLife = 0.5;
    } else if (surface === 'concrete') {
      // Concrete dust
      count = 12;
      baseColor = new THREE.Color(0xcccccc);
      speed = 2.8;
      maxLife = 0.4;
    } else if (surface === 'flesh') {
      // Energy hit confirmation
      count = 18;
      baseColor = new THREE.Color(0xef4444);
      speed = 4.0;
      maxLife = 0.3;
    }

    // Spawn particles
    for (let i = 0; i < count; i++) {
      const p = this.particles.find((item) => !item.active);
      if (!p) break;

      p.active = true;
      p.life = 0;
      p.maxLife = maxLife * (0.7 + Math.random() * 0.6);
      p.position.copy(pos).addScaledVector(norm, 0.04);

      // Cone velocity around normal
      const spread = 0.65;
      p.velocity.set(
        norm.x + (Math.random() - 0.5) * spread * 2,
        norm.y + (Math.random() - 0.5) * spread * 2,
        norm.z + (Math.random() - 0.5) * spread * 2
      ).normalize().multiplyScalar(speed * (0.6 + Math.random() * 0.8));

      p.color.copy(baseColor);
      p.size = 0.12 + Math.random() * 0.08;
    }

    // Place decal on non-flesh surfaces
    if (surface !== 'flesh') {
      const decal = this.decals.find((d) => !d.active) || this.decals[0];
      decal.active = true;
      decal.life = 0;
      decal.mesh.visible = true;
      (decal.mesh.material as THREE.MeshBasicMaterial).opacity = 0.8;

      decal.mesh.position.copy(pos).addScaledVector(norm, 0.02);
      decal.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), norm);
    }
  }

  public update(delta: number) {
    // 1. Update Particles
    for (let i = 0; i < this.maxParticles; i++) {
      const p = this.particles[i];
      if (!p.active) {
        this.particleSizes[i] = 0;
        continue;
      }

      p.life += delta;
      if (p.life >= p.maxLife) {
        p.active = false;
        p.position.set(0, -999, 0);
        this.particleSizes[i] = 0;
        continue;
      }

      // Physics: velocity + gravity
      p.velocity.y -= 9.8 * delta * 0.6;
      p.position.addScaledVector(p.velocity, delta);

      const lifeRatio = 1 - p.life / p.maxLife;

      this.particlePositions[i * 3] = p.position.x;
      this.particlePositions[i * 3 + 1] = p.position.y;
      this.particlePositions[i * 3 + 2] = p.position.z;

      this.particleColors[i * 3] = p.color.r * lifeRatio;
      this.particleColors[i * 3 + 1] = p.color.g * lifeRatio;
      this.particleColors[i * 3 + 2] = p.color.b * lifeRatio;

      this.particleSizes[i] = p.size * lifeRatio;
    }

    (this.particleGeometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.particleGeometry.attributes.color as THREE.BufferAttribute).needsUpdate = true;
    (this.particleGeometry.attributes.size as THREE.BufferAttribute).needsUpdate = true;

    // 2. Update Tracers
    this.tracers.forEach((t) => {
      if (!t.active) return;
      t.life += delta;
      if (t.life >= t.maxLife) {
        t.active = false;
        t.material.opacity = 0;
      } else {
        t.material.opacity = (1 - t.life / t.maxLife) * 0.9;
      }
    });

    // 3. Update Decals
    this.decals.forEach((d) => {
      if (!d.active) return;
      d.life += delta;
      if (d.life >= d.maxLife) {
        d.active = false;
        d.mesh.visible = false;
      } else if (d.life > d.maxLife - 2.0) {
        // Fade out during last 2 seconds
        const fade = (d.maxLife - d.life) / 2.0;
        (d.mesh.material as THREE.MeshBasicMaterial).opacity = fade * 0.8;
      }
    });
  }
}
