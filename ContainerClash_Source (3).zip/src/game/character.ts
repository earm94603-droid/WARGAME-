import * as THREE from 'three';
import { Team } from './types.ts';

/**
 * CONTAINER CLASH - Tactical Operative Character Model
 * Faithful recreation of the reference operative (CRTE tactical uniform,
 * helmet, headset, balaclava, knee pads, plate carrier, and 3D M4 rifle with muzzle flash).
 */
export class OperativeCharacter {
  public group: THREE.Group;
  public team: Team;
  public isDefeated: boolean = false;

  private headGroup: THREE.Group;
  private torsoGroup: THREE.Group;
  private leftArmGroup: THREE.Group;
  private rightArmGroup: THREE.Group;
  private leftLegGroup: THREE.Group;
  private rightLegGroup: THREE.Group;

  // Detailed 3D M4 Rifle & Firing Effects
  private weaponMesh: THREE.Group;
  private botMuzzleFlash: THREE.Mesh;
  private botMuzzleLight: THREE.PointLight;
  private gunRecoilZ: number = 0;
  private muzzleWorldPos: THREE.Vector3 = new THREE.Vector3();

  // Hitboxes for headshot vs body shot
  public headCollider: THREE.Box3 = new THREE.Box3();
  public bodyCollider: THREE.Box3 = new THREE.Box3();

  // Animation state
  private animTime: number = 0;
  private isCrouching: boolean = false;
  private hitFlinchTime: number = 0;
  private deathProgress: number = 0;

  constructor(team: Team = 'red') {
    this.team = team;
    this.group = new THREE.Group();
    this.group.name = `Operative_${team}`;

    // Base tactical materials matching Screenshot 1
    const squadColor = team === 'blue' ? 0x2563eb : 0xdc2626;
    const vestColor = team === 'blue' ? 0x1d4ed8 : 0x991b1b;
    const darkArmor = 0x1e232a;
    const camoPattern = 0x373c44;
    const gloveColor = 0x181a1f;

    const uniformMat = new THREE.MeshStandardMaterial({
      color: squadColor,
      roughness: 0.7,
      metalness: 0.15,
    });
    const vestMat = new THREE.MeshStandardMaterial({
      color: vestColor,
      roughness: 0.5,
      metalness: 0.35,
    });
    const armorMat = new THREE.MeshStandardMaterial({
      color: darkArmor,
      roughness: 0.45,
      metalness: 0.65,
    });
    const camoMat = new THREE.MeshStandardMaterial({
      color: camoPattern,
      roughness: 0.8,
      metalness: 0.1,
    });
    const gloveMat = new THREE.MeshStandardMaterial({
      color: gloveColor,
      roughness: 0.6,
      metalness: 0.2,
    });
    const visorMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.15,
      metalness: 0.9,
    });
    const badgeMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.3,
      metalness: 0.8,
    });
    const gunMetal = new THREE.MeshStandardMaterial({
      color: 0x15181d,
      roughness: 0.35,
      metalness: 0.85,
    });

    // 1. Torso & Tactical Plate Carrier
    this.torsoGroup = new THREE.Group();
    this.torsoGroup.position.set(0, 1.0, 0);

    const chestGeo = new THREE.BoxGeometry(0.38, 0.44, 0.24);
    const chest = new THREE.Mesh(chestGeo, uniformMat);
    chest.castShadow = true;
    this.torsoGroup.add(chest);

    // Plate carrier vest (layered over chest)
    const vestGeo = new THREE.BoxGeometry(0.40, 0.38, 0.28);
    const vest = new THREE.Mesh(vestGeo, vestMat);
    vest.position.set(0, 0.02, 0);
    vest.castShadow = true;
    this.torsoGroup.add(vest);

    // CRTE Chest Badge Plate (Reference Screenshot 1)
    const badgeGeo = new THREE.BoxGeometry(0.14, 0.05, 0.01);
    const badge = new THREE.Mesh(badgeGeo, badgeMat);
    badge.position.set(0, 0.12, 0.145);
    this.torsoGroup.add(badge);

    // Front ammo pouches (3 tactical mag pouches)
    const pouchGeo = new THREE.BoxGeometry(0.08, 0.12, 0.06);
    for (let i = -1; i <= 1; i++) {
      const pouch = new THREE.Mesh(pouchGeo, armorMat);
      pouch.position.set(i * 0.1, -0.06, 0.16);
      pouch.castShadow = true;
      this.torsoGroup.add(pouch);
    }

    // Chest radio with antenna
    const radioGeo = new THREE.BoxGeometry(0.06, 0.10, 0.05);
    const radio = new THREE.Mesh(radioGeo, armorMat);
    radio.position.set(0.14, 0.08, 0.15);
    this.torsoGroup.add(radio);

    const antennaGeo = new THREE.CylinderGeometry(0.005, 0.005, 0.28, 6);
    const antenna = new THREE.Mesh(antennaGeo, armorMat);
    antenna.position.set(0.15, 0.24, 0.14);
    this.torsoGroup.add(antenna);

    // Tactical duty belt & holster
    const beltGeo = new THREE.BoxGeometry(0.40, 0.06, 0.26);
    const belt = new THREE.Mesh(beltGeo, armorMat);
    belt.position.set(0, -0.22, 0);
    this.torsoGroup.add(belt);

    const holsterGeo = new THREE.BoxGeometry(0.08, 0.14, 0.06);
    const holster = new THREE.Mesh(holsterGeo, armorMat);
    holster.position.set(0.21, -0.26, 0.02);
    this.torsoGroup.add(holster);

    this.group.add(this.torsoGroup);

    // 2. Head with Tactical Helmet, Balaclava & Headset (Screenshot 1)
    this.headGroup = new THREE.Group();
    this.headGroup.position.set(0, 0.35, 0);

    // Balaclava head covering
    const headGeo = new THREE.BoxGeometry(0.22, 0.24, 0.22);
    const head = new THREE.Mesh(headGeo, armorMat);
    head.castShadow = true;
    this.headGroup.add(head);

    // Tactical Goggles / Visor
    const visorGeo = new THREE.BoxGeometry(0.2, 0.06, 0.08);
    const visor = new THREE.Mesh(visorGeo, visorMat);
    visor.position.set(0, 0.02, 0.11);
    this.headGroup.add(visor);

    // Tactical Combat Helmet with squad trim
    const helmetGeo = new THREE.SphereGeometry(0.15, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.6);
    const helmet = new THREE.Mesh(helmetGeo, vestMat);
    helmet.position.set(0, 0.07, 0);
    helmet.castShadow = true;
    this.headGroup.add(helmet);

    // Comms Headset with Earcups and Overhead Band
    const cupGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.04, 10);
    const leftCup = new THREE.Mesh(cupGeo, armorMat);
    leftCup.rotation.z = Math.PI / 2;
    leftCup.position.set(-0.13, 0.02, 0);
    this.headGroup.add(leftCup);

    const rightCup = new THREE.Mesh(cupGeo, armorMat);
    rightCup.rotation.z = Math.PI / 2;
    rightCup.position.set(0.13, 0.02, 0);
    this.headGroup.add(rightCup);

    const headbandGeo = new THREE.TorusGeometry(0.14, 0.012, 8, 20, Math.PI);
    const headband = new THREE.Mesh(headbandGeo, armorMat);
    headband.rotation.y = Math.PI / 2;
    headband.position.set(0, 0.12, 0);
    this.headGroup.add(headband);

    this.torsoGroup.add(this.headGroup);

    // 3. Arms & Hands holding the M4 Rifle
    // Shoulders / Pauldrons with team color
    const pauldronGeo = new THREE.BoxGeometry(0.12, 0.08, 0.12);
    const leftPauldron = new THREE.Mesh(pauldronGeo, vestMat);
    leftPauldron.position.set(-0.24, 0.20, 0);
    this.torsoGroup.add(leftPauldron);

    const rightPauldron = new THREE.Mesh(pauldronGeo, vestMat);
    rightPauldron.position.set(0.24, 0.20, 0);
    this.torsoGroup.add(rightPauldron);

    const armGeo = new THREE.BoxGeometry(0.09, 0.32, 0.09);

    // Left Arm (Reaching forward to support M4 handguard)
    this.leftArmGroup = new THREE.Group();
    this.leftArmGroup.position.set(-0.24, 0.16, 0);
    const leftArmMesh = new THREE.Mesh(armGeo, camoMat);
    leftArmMesh.position.set(0.08, -0.12, 0.18);
    leftArmMesh.rotation.set(-0.75, -0.3, -0.4);
    leftArmMesh.castShadow = true;
    this.leftArmGroup.add(leftArmMesh);

    const leftHandMesh = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.07, 0.07), gloveMat);
    leftHandMesh.position.set(0.15, -0.24, 0.32);
    this.leftArmGroup.add(leftHandMesh);
    this.torsoGroup.add(this.leftArmGroup);

    // Right Arm (Gripping pistol grip and trigger)
    this.rightArmGroup = new THREE.Group();
    this.rightArmGroup.position.set(0.24, 0.16, 0);
    const rightArmMesh = new THREE.Mesh(armGeo, camoMat);
    rightArmMesh.position.set(-0.06, -0.12, 0.14);
    rightArmMesh.rotation.set(-0.85, 0.2, 0.3);
    rightArmMesh.castShadow = true;
    this.rightArmGroup.add(rightArmMesh);

    const rightHandMesh = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.07, 0.07), gloveMat);
    rightHandMesh.position.set(-0.12, -0.24, 0.26);
    this.rightArmGroup.add(rightHandMesh);
    this.torsoGroup.add(this.rightArmGroup);

    // 4. DETAILED 3D M4 RIFLE IN ENEMY HANDS
    this.weaponMesh = new THREE.Group();
    this.weaponMesh.name = 'EnemyM4';
    this.weaponMesh.position.set(0.06, -0.10, 0.24);
    this.weaponMesh.rotation.set(0.05, -0.05, 0);

    // Receiver
    const receiverGeo = new THREE.BoxGeometry(0.05, 0.08, 0.28);
    const receiver = new THREE.Mesh(receiverGeo, gunMetal);
    receiver.castShadow = true;
    this.weaponMesh.add(receiver);

    // Telescoping Buttstock
    const stockGeo = new THREE.BoxGeometry(0.04, 0.10, 0.16);
    const stock = new THREE.Mesh(stockGeo, gunMetal);
    stock.position.set(0, 0, -0.20);
    this.weaponMesh.add(stock);

    // Curved PMAG Magazine
    const magGeo = new THREE.BoxGeometry(0.038, 0.15, 0.08);
    const mag = new THREE.Mesh(magGeo, gunMetal);
    mag.position.set(0, -0.10, 0.02);
    mag.rotation.x = 0.25;
    this.weaponMesh.add(mag);

    // Handguard & Picatinny Rail
    const handguardGeo = new THREE.BoxGeometry(0.046, 0.06, 0.22);
    const handguard = new THREE.Mesh(handguardGeo, gunMetal);
    handguard.position.set(0, 0.01, 0.22);
    this.weaponMesh.add(handguard);

    // Barrel & Birdcage Flash Hider
    const barrelGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.25, 10);
    const barrel = new THREE.Mesh(barrelGeo, gunMetal);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.01, 0.44);
    this.weaponMesh.add(barrel);

    // Red Dot Sight Optic on Bot Weapon
    const opticGeo = new THREE.BoxGeometry(0.035, 0.045, 0.06);
    const optic = new THREE.Mesh(opticGeo, gunMetal);
    optic.position.set(0, 0.065, 0.02);
    this.weaponMesh.add(optic);

    // 5. Bot Muzzle Flash Flame & Dynamic Light
    const flashGeo = new THREE.ConeGeometry(0.08, 0.28, 4);
    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xffaa22,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      toneMapped: false,
    });
    this.botMuzzleFlash = new THREE.Mesh(flashGeo, flashMat);
    this.botMuzzleFlash.rotation.x = -Math.PI / 2;
    this.botMuzzleFlash.position.set(0, 0.01, 0.60);
    this.weaponMesh.add(this.botMuzzleFlash);

    this.botMuzzleLight = new THREE.PointLight(0xff9922, 0, 8);
    this.botMuzzleLight.position.set(0, 0.01, 0.62);
    this.weaponMesh.add(this.botMuzzleLight);

    this.torsoGroup.add(this.weaponMesh);

    // 6. Legs, Knee Pads & Combat Boots
    const legGeo = new THREE.BoxGeometry(0.13, 0.5, 0.13);
    const kneePadGeo = new THREE.BoxGeometry(0.14, 0.12, 0.05);
    const bootGeo = new THREE.BoxGeometry(0.14, 0.14, 0.22);

    // Left Leg
    this.leftLegGroup = new THREE.Group();
    this.leftLegGroup.position.set(-0.11, 0.55, 0);
    const leftLegMesh = new THREE.Mesh(legGeo, camoMat);
    leftLegMesh.position.set(0, -0.25, 0);
    leftLegMesh.castShadow = true;
    this.leftLegGroup.add(leftLegMesh);

    const leftKneePad = new THREE.Mesh(kneePadGeo, armorMat);
    leftKneePad.position.set(0, -0.22, 0.075);
    this.leftLegGroup.add(leftKneePad);

    const leftBoot = new THREE.Mesh(bootGeo, armorMat);
    leftBoot.position.set(0, -0.5, 0.04);
    leftBoot.castShadow = true;
    this.leftLegGroup.add(leftBoot);
    this.group.add(this.leftLegGroup);

    // Right Leg
    this.rightLegGroup = new THREE.Group();
    this.rightLegGroup.position.set(0.11, 0.55, 0);
    const rightLegMesh = new THREE.Mesh(legGeo, camoMat);
    rightLegMesh.position.set(0, -0.25, 0);
    rightLegMesh.castShadow = true;
    this.rightLegGroup.add(rightLegMesh);

    const rightKneePad = new THREE.Mesh(kneePadGeo, armorMat);
    rightKneePad.position.set(0, -0.22, 0.075);
    this.rightLegGroup.add(rightKneePad);

    const rightBoot = new THREE.Mesh(bootGeo, armorMat);
    rightBoot.position.set(0, -0.5, 0.04);
    rightBoot.castShadow = true;
    this.rightLegGroup.add(rightBoot);
    this.group.add(this.rightLegGroup);
  }

  public setPosition(x: number, y: number, z: number) {
    this.group.position.set(x, y, z);
    this.updateHitboxes();
  }

  public setRotation(yaw: number) {
    this.group.rotation.y = yaw;
  }

  public triggerHitFlinch() {
    this.hitFlinchTime = 0.18;
  }

  /**
   * Visible firing animation on the bot:
   * Flares the muzzle flash, turns on point light, and kicks the weapon back!
   */
  public triggerFireAnimation() {
    const flashMat = this.botMuzzleFlash.material as THREE.MeshBasicMaterial;
    flashMat.opacity = 1.0;
    this.botMuzzleFlash.rotation.z = Math.random() * Math.PI * 2;
    this.botMuzzleLight.intensity = 4.0;
    this.gunRecoilZ = 0.05;
  }

  public getMuzzleWorldPos(): THREE.Vector3 {
    this.botMuzzleFlash.getWorldPosition(this.muzzleWorldPos);
    return this.muzzleWorldPos;
  }

  public setDefeated(isDefeated: boolean) {
    this.isDefeated = isDefeated;
    if (!isDefeated) {
      this.deathProgress = 0;
      this.group.rotation.x = 0;
      this.group.position.y = 0;
    }
  }

  public update(delta: number, isMoving: boolean, speed: number, isCrouching: boolean) {
    this.isCrouching = isCrouching;

    // 1. Decay muzzle flash and recoil
    const flashMat = this.botMuzzleFlash.material as THREE.MeshBasicMaterial;
    if (flashMat.opacity > 0) {
      flashMat.opacity = Math.max(0, flashMat.opacity - delta * 20);
    }
    if (this.botMuzzleLight.intensity > 0) {
      this.botMuzzleLight.intensity = Math.max(0, this.botMuzzleLight.intensity - delta * 25);
    }
    this.gunRecoilZ = THREE.MathUtils.lerp(this.gunRecoilZ, 0, 16 * delta);
    this.weaponMesh.position.z = 0.24 - this.gunRecoilZ;

    if (this.isDefeated) {
      // Smooth defeat collapse
      if (this.deathProgress < 1.0) {
        this.deathProgress = Math.min(1.0, this.deathProgress + delta * 3.5);
        this.group.rotation.x = -Math.PI / 2 * this.deathProgress;
        this.group.position.y = -0.4 * this.deathProgress;
      }
      return;
    }

    // 2. Crouch posture
    const targetTorsoY = isCrouching ? 0.72 : 1.0;
    this.torsoGroup.position.y = THREE.MathUtils.lerp(this.torsoGroup.position.y, targetTorsoY, 12 * delta);

    // 3. Walk cycle
    if (isMoving) {
      this.animTime += delta * speed * 4.0;
      const legAngle = Math.sin(this.animTime) * 0.45;
      this.leftLegGroup.rotation.x = legAngle;
      this.rightLegGroup.rotation.x = -legAngle;

      this.leftArmGroup.rotation.x = -legAngle * 0.25;
      this.rightArmGroup.rotation.x = legAngle * 0.25;
    } else {
      // Idle reset
      this.leftLegGroup.rotation.x = THREE.MathUtils.lerp(this.leftLegGroup.rotation.x, 0, 10 * delta);
      this.rightLegGroup.rotation.x = THREE.MathUtils.lerp(this.rightLegGroup.rotation.x, 0, 10 * delta);
      this.leftArmGroup.rotation.x = THREE.MathUtils.lerp(this.leftArmGroup.rotation.x, 0, 10 * delta);
      this.rightArmGroup.rotation.x = THREE.MathUtils.lerp(this.rightArmGroup.rotation.x, 0, 10 * delta);
    }

    // 4. Hit flinch decay
    if (this.hitFlinchTime > 0) {
      this.hitFlinchTime -= delta;
      this.torsoGroup.rotation.x = -0.25;
    } else {
      this.torsoGroup.rotation.x = THREE.MathUtils.lerp(this.torsoGroup.rotation.x, 0, 10 * delta);
    }

    this.updateHitboxes();
  }

  public updateHitboxes() {
    const pos = this.group.position;
    // Head hitbox: radius 0.2m centered around y: 1.55 (or 1.25 if crouching)
    const headY = this.isCrouching ? pos.y + 1.25 : pos.y + 1.55;
    this.headCollider.min.set(pos.x - 0.22, headY - 0.2, pos.z - 0.22);
    this.headCollider.max.set(pos.x + 0.22, headY + 0.2, pos.z + 0.22);

    // Body hitbox: from y: 0 to y: 1.35
    const bodyHeight = this.isCrouching ? 1.05 : 1.35;
    this.bodyCollider.min.set(pos.x - 0.35, pos.y, pos.z - 0.35);
    this.bodyCollider.max.set(pos.x + 0.35, pos.y + bodyHeight, pos.z + 0.35);
  }
}
