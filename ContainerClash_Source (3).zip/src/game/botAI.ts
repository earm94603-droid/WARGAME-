import * as THREE from 'three';
import { BoundingBox3D, Waypoint } from './types.ts';
import { OperativeCharacter } from './character.ts';
import { soundEngine } from './audio.ts';

export type BotState = 'patrol' | 'chase' | 'attack' | 'take_cover';

export class BotController {
  public character: OperativeCharacter;
  public health: number = 100;
  public isDefeated: boolean = false;
  public currentWaypointIndex: number = 0;
  public state: BotState = 'patrol';

  private waypoints: Waypoint[];
  private colliders: BoundingBox3D[];
  private respawnTimer: number = 0;
  private burstCounter: number = 0;
  private burstCooldown: number = 0;
  private lastFireTime: number = 0;
  private totalShotsFired: number = 0;

  // Navigation & kinematics
  public position: THREE.Vector3 = new THREE.Vector3();
  public velocity: THREE.Vector3 = new THREE.Vector3();
  public yaw: number = 0;
  public moveSpeed: number = 3.6;

  constructor(
    character: OperativeCharacter,
    waypoints: Waypoint[],
    colliders: BoundingBox3D[],
    initialPos: THREE.Vector3
  ) {
    this.character = character;
    this.waypoints = waypoints;
    this.colliders = colliders;
    this.position.copy(initialPos);
    this.character.setPosition(this.position.x, this.position.y, this.position.z);
  }

  public takeDamage(damage: number): { isDefeated: boolean } {
    if (this.isDefeated) return { isDefeated: true };

    this.health = Math.max(0, this.health - damage);
    this.character.triggerHitFlinch();

    if (this.health <= 0) {
      this.isDefeated = true;
      this.character.setDefeated(true);
      this.respawnTimer = 3.0; // 3 seconds respawn
      return { isDefeated: true };
    }

    if (this.health < 40 && this.state !== 'take_cover') {
      this.state = 'take_cover';
    }

    return { isDefeated: false };
  }

  public respawn(spawnPos: THREE.Vector3) {
    this.health = 100;
    this.isDefeated = false;
    this.character.setDefeated(false);
    this.position.copy(spawnPos);
    this.character.setPosition(this.position.x, this.position.y, this.position.z);
    this.state = 'patrol';
    this.currentWaypointIndex = Math.floor(Math.random() * this.waypoints.length);
  }

  /**
   * Fast raycast against AABB colliders to verify line-of-sight
   */
  public hasLineOfSight(playerPos: THREE.Vector3): boolean {
    const startX = this.position.x;
    const startZ = this.position.z;
    const dirX = playerPos.x - startX;
    const dirZ = playerPos.z - startZ;
    const dist = Math.hypot(dirX, dirZ);

    if (dist < 0.1 || dist > 32.0) return false;

    const normX = dirX / dist;
    const normZ = dirZ / dist;

    // Check steps along 2D ray
    const stepSize = 1.0;
    const steps = Math.floor(dist / stepSize);

    for (let i = 1; i < steps; i++) {
      const checkX = startX + normX * i * stepSize;
      const checkZ = startZ + normZ * i * stepSize;

      for (const col of this.colliders) {
        if (
          checkX >= col.minX &&
          checkX <= col.maxX &&
          checkZ >= col.minZ &&
          checkZ <= col.maxZ &&
          col.maxY > 1.2
        ) {
          return false; // Intersecting container or wall blocks line-of-sight
        }
      }
    }

    return true;
  }

  public update(
    delta: number,
    playerPos: THREE.Vector3,
    isPlayerMoving: boolean = false,
    onBotFire?: (origin: THREE.Vector3, dir: THREE.Vector3) => void
  ) {
    if (this.isDefeated) {
      this.character.update(delta, false, 0, false);
      if (this.respawnTimer > 0) {
        this.respawnTimer -= delta;
      }
      return;
    }

    const distToPlayer = this.position.distanceTo(playerPos);
    const canSeePlayer = this.hasLineOfSight(playerPos);

    // 1. State Transitions
    if (this.state === 'take_cover') {
      // Find nearest cover waypoint
      const coverWaypoint = this.waypoints.find((w) => w.isCover);
      if (coverWaypoint) {
        const d = Math.hypot(this.position.x - coverWaypoint.x, this.position.z - coverWaypoint.z);
        if (d < 1.5) {
          this.state = 'attack';
        }
      }
    } else if (canSeePlayer && distToPlayer < 24.0) {
      this.state = 'attack';
    } else if (canSeePlayer && distToPlayer >= 24.0) {
      this.state = 'chase';
    } else {
      this.state = 'patrol';
    }

    // 2. State Actions
    let targetX = 0;
    let targetZ = 0;
    let isMoving = false;
    let speed = this.moveSpeed;

    if (this.state === 'attack') {
      // Face player directly
      const toPlayer = new THREE.Vector3().subVectors(playerPos, this.position);
      this.yaw = Math.atan2(toPlayer.x, toPlayer.z);

      // Controlled strafe
      if (distToPlayer > 12.0) {
        targetX = playerPos.x;
        targetZ = playerPos.z;
        isMoving = true;
      } else {
        isMoving = false;
      }

      // 3-round burst firing logic
      const now = performance.now();
      if (now - this.lastFireTime > 140 && this.burstCooldown <= 0) {
        this.lastFireTime = now;
        this.burstCounter++;
        this.totalShotsFired++;

        // User requirement: 1 hit out of 6 when stationary, 1 hit out of 10 when player is moving!
        const hitModulus = isPlayerMoving ? 10 : 6;
        const shouldHit = this.totalShotsFired % hitModulus === 1;

        let aimDir: THREE.Vector3;
        if (shouldHit) {
          // Direct hit shot towards chest/head
          aimDir = new THREE.Vector3().subVectors(playerPos, this.position).normalize();
          aimDir.x += (Math.random() - 0.5) * 0.015;
          aimDir.y += 0.04 + (Math.random() - 0.5) * 0.02;
          aimDir.z += (Math.random() - 0.5) * 0.015;
          aimDir.normalize();
        } else {
          // Intentional near-miss whizzing past player with sparks and tracers
          const dirToPlayer = new THREE.Vector3().subVectors(playerPos, this.position).normalize();
          const sideVector = new THREE.Vector3(-dirToPlayer.z, 0, dirToPlayer.x).normalize();
          const offsetAngle = (Math.random() > 0.5 ? 1 : -1) * (0.18 + Math.random() * 0.12);
          aimDir = dirToPlayer.clone().addScaledVector(sideVector, offsetAngle).normalize();
          aimDir.y += (Math.random() - 0.5) * 0.08;
          aimDir.normalize();
        }

        const muzzlePos = this.position.clone().add(new THREE.Vector3(0, 1.2, 0));
        this.character.triggerFireAnimation();
        soundEngine.playGunshot(false);

        if (onBotFire) {
          onBotFire(muzzlePos, aimDir);
        }

        if (this.burstCounter >= 3) {
          this.burstCounter = 0;
          this.burstCooldown = 1.0 + Math.random() * 0.6; // cooldown before next burst
        }
      }

      if (this.burstCooldown > 0) {
        this.burstCooldown -= delta;
      }
    } else if (this.state === 'chase') {
      targetX = playerPos.x;
      targetZ = playerPos.z;
      isMoving = true;
      speed = this.moveSpeed * 1.25; // sprint
    } else {
      // Patrol waypoint navigation
      const wp = this.waypoints[this.currentWaypointIndex];
      targetX = wp.x;
      targetZ = wp.z;
      const d = Math.hypot(this.position.x - targetX, this.position.z - targetZ);

      if (d < 1.8) {
        // Next waypoint
        this.currentWaypointIndex = (this.currentWaypointIndex + 1) % this.waypoints.length;
      }
      isMoving = true;
    }

    // 3. Move towards target with obstacle avoidance
    if (isMoving) {
      const dx = targetX - this.position.x;
      const dz = targetZ - this.position.z;
      const dist = Math.hypot(dx, dz);

      if (dist > 0.2) {
        const moveDirX = dx / dist;
        const moveDirZ = dz / dist;

        if (this.state !== 'attack') {
          this.yaw = Math.atan2(moveDirX, moveDirZ);
        }

        const nextX = this.position.x + moveDirX * speed * delta;
        const nextZ = this.position.z + moveDirZ * speed * delta;

        // Collision check
        let collidesX = false;
        let collidesZ = false;
        const r = 0.4;

        for (const col of this.colliders) {
          if (
            nextX + r > col.minX &&
            nextX - r < col.maxX &&
            this.position.z + r > col.minZ &&
            this.position.z - r < col.maxZ &&
            col.maxY > 0.5
          ) {
            collidesX = true;
          }
          if (
            this.position.x + r > col.minX &&
            this.position.x - r < col.maxX &&
            nextZ + r > col.minZ &&
            nextZ - r < col.maxZ &&
            col.maxY > 0.5
          ) {
            collidesZ = true;
          }
        }

        if (!collidesX) this.position.x = nextX;
        if (!collidesZ) this.position.z = nextZ;
      }
    }

    // Update 3D model
    this.character.setPosition(this.position.x, this.position.y, this.position.z);
    this.character.setRotation(this.yaw);
    this.character.update(delta, isMoving, speed, false);
  }
}
