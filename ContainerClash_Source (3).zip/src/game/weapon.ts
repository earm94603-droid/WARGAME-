/**
 * CONTAINER CLASH - First-Person Tactical Weapon Rig
 * Faithful recreation of the tactical M4 Carbine with circular reflex red-dot optic,
 * serrated Picatinny rail spine, QD suppressor, angled foregrip, and responsive recoil.
 */

import * as THREE from 'three';
import { Team } from './types.ts';

export class FirstPersonWeaponRig {
  public group: THREE.Group;
  public isAiming: boolean = false;
  public isReloading: boolean = false;
  public muzzleWorldPos: THREE.Vector3 = new THREE.Vector3();

  private team: Team;
  private weaponMesh: THREE.Group;
  private muzzleFlashGroup: THREE.Group;
  private muzzleLight: THREE.PointLight;

  // Hip, ADS, and Sprint tactical carry transforms
  private hipPos = new THREE.Vector3(0.20, -0.19, -0.42);
  private adsPos = new THREE.Vector3(0.0, -0.130, -0.27); // Reticle centered at exact viewport center
  private sprintPos = new THREE.Vector3(0.14, -0.27, -0.36); // Tactical low-ready sprint carry stance

  // Recoil spring state
  private recoilZ: number = 0;
  private recoilPitch: number = 0;
  private recoilRoll: number = 0;

  // Sway & bobbing
  private bobTime: number = 0;
  private reloadTime: number = 0;
  private fireRecoveryTimer: number = 0; // Ensures weapon stays raised towards crosshair when firing while sprinting

  constructor(team: Team = 'blue') {
    this.team = team;
    this.group = new THREE.Group();
    this.group.name = 'FirstPersonRig';

    this.weaponMesh = this.buildWeaponMesh();
    this.group.add(this.weaponMesh);

    // Muzzle flash fiery flare and dynamic light
    this.muzzleFlashGroup = this.buildMuzzleFlash();
    this.weaponMesh.add(this.muzzleFlashGroup);

    this.muzzleLight = new THREE.PointLight(0xff9922, 0, 10);
    this.muzzleLight.position.set(0, 0.02, -1.08);
    this.weaponMesh.add(this.muzzleLight);

    // Initial position
    this.weaponMesh.position.copy(this.hipPos);
  }

  private buildWeaponMesh(): THREE.Group {
    const gun = new THREE.Group();
    gun.name = 'M4Rifle';

    // Mil-spec matte black & dark gunmetal materials
    const blackMetal = new THREE.MeshStandardMaterial({
      color: 0x181a1e,
      roughness: 0.35,
      metalness: 0.85,
    });
    const darkGunMetal = new THREE.MeshStandardMaterial({
      color: 0x252830,
      roughness: 0.45,
      metalness: 0.75,
    });
    const railMat = new THREE.MeshStandardMaterial({
      color: 0x101215,
      roughness: 0.5,
      metalness: 0.85,
    });
    const bevelMat = new THREE.MeshStandardMaterial({
      color: 0x2e333d,
      roughness: 0.3,
      metalness: 0.9,
    });

    // 1. Lower & Upper Receiver (Sleek, low-profile and tapered)
    const lowerReceiverGeo = new THREE.BoxGeometry(0.052, 0.065, 0.30);
    const lowerReceiver = new THREE.Mesh(lowerReceiverGeo, blackMetal);
    lowerReceiver.position.set(0, -0.015, 0.02);
    gun.add(lowerReceiver);

    const upperReceiverGeo = new THREE.BoxGeometry(0.048, 0.05, 0.28);
    const upperReceiver = new THREE.Mesh(upperReceiverGeo, darkGunMetal);
    upperReceiver.position.set(0, 0.025, 0.01);
    gun.add(upperReceiver);

    // Ejection Port & Dust Cover (Right side)
    const ejectionPortGeo = new THREE.BoxGeometry(0.008, 0.026, 0.08);
    const ejectionPortMat = new THREE.MeshStandardMaterial({ color: 0x0a0c0e, roughness: 0.2, metalness: 0.95 });
    const ejectionPort = new THREE.Mesh(ejectionPortGeo, ejectionPortMat);
    ejectionPort.position.set(0.026, 0.025, 0.02);
    gun.add(ejectionPort);

    const brassDeflectorGeo = new THREE.BoxGeometry(0.014, 0.018, 0.026);
    const brassDeflector = new THREE.Mesh(brassDeflectorGeo, darkGunMetal);
    brassDeflector.position.set(0.029, 0.028, 0.065);
    gun.add(brassDeflector);

    // 2. Picatinny Top Rail with Individual Serrated Teeth (The iconic ribbed spine in Image 2!)
    const railBaseGeo = new THREE.BoxGeometry(0.042, 0.012, 0.58);
    const railBase = new THREE.Mesh(railBaseGeo, railMat);
    railBase.position.set(0, 0.053, -0.12);
    gun.add(railBase);

    // Individual Picatinny cross-slots / ribs along the top spine
    const ribGeo = new THREE.BoxGeometry(0.044, 0.007, 0.012);
    for (let z = 0.14; z >= -0.40; z -= 0.024) {
      const rib = new THREE.Mesh(ribGeo, bevelMat);
      rib.position.set(0, 0.060, z);
      gun.add(rib);
    }

    // Charging Handle at rear of receiver
    const chargingHandleGeo = new THREE.BoxGeometry(0.055, 0.016, 0.04);
    const chargingHandle = new THREE.Mesh(chargingHandleGeo, railMat);
    chargingHandle.position.set(0, 0.048, 0.16);
    gun.add(chargingHandle);

    // 3. Handguard Shroud & Barrel
    const handguardGeo = new THREE.BoxGeometry(0.050, 0.062, 0.34);
    const handguard = new THREE.Mesh(handguardGeo, railMat);
    handguard.position.set(0, 0.015, -0.28);
    gun.add(handguard);

    // Angled Foregrip (AFG)
    const afgGeo = new THREE.BoxGeometry(0.034, 0.06, 0.13);
    const afgMat = new THREE.MeshStandardMaterial({ color: 0x16181c, roughness: 0.65, metalness: 0.3 });
    const afg = new THREE.Mesh(afgGeo, afgMat);
    afg.position.set(0, -0.035, -0.27);
    afg.rotation.x = -0.38;
    gun.add(afg);

    // AN/PEQ-15 Laser Box (Right Rail)
    const peqGeo = new THREE.BoxGeometry(0.028, 0.024, 0.09);
    const peqMat = new THREE.MeshStandardMaterial({ color: 0x22262e, roughness: 0.6, metalness: 0.5 });
    const peq = new THREE.Mesh(peqGeo, peqMat);
    peq.position.set(0.032, 0.032, -0.29);
    gun.add(peq);

    // 4. Barrel & QD Tactical Suppressor (Silencer)
    const barrelGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.32, 12);
    const barrel = new THREE.Mesh(barrelGeo, darkGunMetal);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.02, -0.58);
    gun.add(barrel);

    const suppressorMat = new THREE.MeshStandardMaterial({
      color: 0x141619,
      roughness: 0.35,
      metalness: 0.88,
    });
    const suppressorGeo = new THREE.CylinderGeometry(0.022, 0.022, 0.32, 16);
    const suppressor = new THREE.Mesh(suppressorGeo, suppressorMat);
    suppressor.rotation.x = Math.PI / 2;
    suppressor.position.set(0, 0.02, -0.88);
    gun.add(suppressor);

    // 5. CIRCULAR REFLEX RED DOT OPTIC (100% Transparent, Faithful to Reference Images!)
    // Optic Riser Mount attached to the Picatinny rail
    const opticMountGeo = new THREE.BoxGeometry(0.038, 0.032, 0.08);
    const opticMount = new THREE.Mesh(opticMountGeo, blackMetal);
    opticMount.position.set(0, 0.076, -0.04);
    gun.add(opticMount);

    // Mount clamp screws on side
    const screwGeo = new THREE.CylinderGeometry(0.007, 0.007, 0.012, 8);
    const screw = new THREE.Mesh(screwGeo, darkGunMetal);
    screw.rotation.z = Math.PI / 2;
    screw.position.set(0.024, 0.076, -0.04);
    gun.add(screw);

    // Circular Outer Housing Ring (Thin anodized matte metal ring - open center!)
    const opticRingMat = new THREE.MeshStandardMaterial({
      color: 0x1a1c20,
      roughness: 0.35,
      metalness: 0.85,
    });
    // Outer torus ring creates the circular optic frame you can look straight through!
    const opticOuterRingGeo = new THREE.TorusGeometry(0.046, 0.0055, 16, 48);
    const opticOuterRing = new THREE.Mesh(opticOuterRingGeo, opticRingMat);
    opticOuterRing.position.set(0, 0.130, -0.04);
    gun.add(opticOuterRing);

    // Side hood protective brackets connecting ring to mount
    const bracketGeo = new THREE.BoxGeometry(0.008, 0.042, 0.032);
    const leftBracket = new THREE.Mesh(bracketGeo, opticRingMat);
    leftBracket.position.set(-0.045, 0.108, -0.04);
    gun.add(leftBracket);

    const rightBracket = new THREE.Mesh(bracketGeo, opticRingMat);
    rightBracket.position.set(0.045, 0.108, -0.04);
    gun.add(rightBracket);

    // Front sunshade lip
    const sunshadeGeo = new THREE.TorusGeometry(0.047, 0.0035, 8, 36);
    const sunshade = new THREE.Mesh(sunshadeGeo, opticRingMat);
    sunshade.position.set(0, 0.130, -0.065);
    gun.add(sunshade);

    // Optical Glass Lens: 100% CLEAR with zero occlusion (depthWrite: false is critical!)
    // Uses MeshBasicMaterial with subtle cyan anti-reflective reflection so it NEVER turns black!
    const glassLensGeo = new THREE.CircleGeometry(0.044, 32);
    const glassLensMat = new THREE.MeshBasicMaterial({
      color: 0x60d5ff,
      transparent: true,
      opacity: 0.08,
      depthWrite: false, // Guarantees all containers, sky, and enemies render through it!
      side: THREE.DoubleSide,
    });
    const glassLens = new THREE.Mesh(glassLensGeo, glassLensMat);
    glassLens.position.set(0, 0.130, -0.042);
    gun.add(glassLens);

    // Reticle Group (Centered perfectly at y: 0.130)
    const reticleGroup = new THREE.Group();
    reticleGroup.position.set(0, 0.130, -0.048);

    // 1. Center Glowing Red-Dot Reticle (Vibrant neon red dot, toneMapped: false)
    const dotGeo = new THREE.SphereGeometry(0.0028, 12, 12);
    const dotMat = new THREE.MeshBasicMaterial({
      color: 0xff0022,
      toneMapped: false,
      depthWrite: false,
    });
    const reticleDot = new THREE.Mesh(dotGeo, dotMat);
    reticleGroup.add(reticleDot);

    // 2. Holographic Outer Reticle Ring (Matching tactical EOTech / Aimpoint reflex sights)
    const reticleRingGeo = new THREE.RingGeometry(0.016, 0.0185, 36);
    const reticleRingMat = new THREE.MeshBasicMaterial({
      color: 0xff2200,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.82,
      blending: THREE.AdditiveBlending,
      toneMapped: false,
      depthWrite: false,
    });
    const reticleRing = new THREE.Mesh(reticleRingGeo, reticleRingMat);
    reticleGroup.add(reticleRing);

    // 3. Four tactical crosshair tick marks (Top, Bottom, Left, Right)
    const tickMat = new THREE.MeshBasicMaterial({
      color: 0xff3300,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      toneMapped: false,
      depthWrite: false,
    });

    // Top tick
    const vertTickGeo = new THREE.BoxGeometry(0.0012, 0.0055, 0.001);
    const topTick = new THREE.Mesh(vertTickGeo, tickMat);
    topTick.position.set(0, 0.0215, 0);
    reticleGroup.add(topTick);

    // Bottom tick
    const bottomTick = new THREE.Mesh(vertTickGeo, tickMat);
    bottomTick.position.set(0, -0.0215, 0);
    reticleGroup.add(bottomTick);

    // Left tick
    const horizTickGeo = new THREE.BoxGeometry(0.0055, 0.0012, 0.001);
    const leftTick = new THREE.Mesh(horizTickGeo, tickMat);
    leftTick.position.set(-0.0215, 0, 0);
    reticleGroup.add(leftTick);

    // Right tick
    const rightTick = new THREE.Mesh(horizTickGeo, tickMat);
    rightTick.position.set(0.0215, 0, 0);
    reticleGroup.add(rightTick);

    gun.add(reticleGroup);

    // 6. Textured P-MAG Magazine
    const magGeo = new THREE.BoxGeometry(0.042, 0.20, 0.09);
    const mag = new THREE.Mesh(magGeo, blackMetal);
    mag.position.set(0, -0.10, -0.04);
    mag.rotation.x = 0.22;
    gun.add(mag);

    // Magazine baseplate bumper
    const magPlateGeo = new THREE.BoxGeometry(0.046, 0.02, 0.095);
    const magPlate = new THREE.Mesh(magPlateGeo, railMat);
    magPlate.position.set(0, -0.19, -0.02);
    magPlate.rotation.x = 0.22;
    gun.add(magPlate);

    // 7. Tactical Pistol Grip
    const gripGeo = new THREE.BoxGeometry(0.044, 0.14, 0.06);
    const grip = new THREE.Mesh(gripGeo, darkGunMetal);
    grip.position.set(0, -0.08, 0.12);
    grip.rotation.x = -0.35;
    gun.add(grip);

    // 8. Crane Stock
    const stockTubeGeo = new THREE.CylinderGeometry(0.016, 0.016, 0.20, 10);
    const stockTube = new THREE.Mesh(stockTubeGeo, blackMetal);
    stockTube.rotation.x = Math.PI / 2;
    stockTube.position.set(0, 0.015, 0.23);
    gun.add(stockTube);

    const stockButtGeo = new THREE.BoxGeometry(0.046, 0.13, 0.11);
    const stockButt = new THREE.Mesh(stockButtGeo, darkGunMetal);
    stockButt.position.set(0, -0.01, 0.31);
    gun.add(stockButt);

    // 9. Operative Arms & Tactical Gloves
    const sleeveColor = this.team === 'blue' ? 0x2563eb : 0xdc2626;
    const sleeveMat = new THREE.MeshStandardMaterial({
      color: sleeveColor,
      roughness: 0.8,
      metalness: 0.1,
    });
    const gloveMat = new THREE.MeshStandardMaterial({
      color: 0x1a1e26,
      roughness: 0.55,
      metalness: 0.25,
    });

    // Right Arm (Pistol grip hand)
    const rightForearmGeo = new THREE.CylinderGeometry(0.042, 0.048, 0.30, 10);
    const rightForearm = new THREE.Mesh(rightForearmGeo, sleeveMat);
    rightForearm.position.set(0.11, -0.15, 0.25);
    rightForearm.rotation.set(-0.4, -0.2, -0.3);
    gun.add(rightForearm);

    const rightHandGeo = new THREE.BoxGeometry(0.055, 0.065, 0.085);
    const rightHand = new THREE.Mesh(rightHandGeo, gloveMat);
    rightHand.position.set(0.025, -0.075, 0.12);
    rightHand.rotation.set(-0.35, 0, 0);
    gun.add(rightHand);

    // Left Arm (Handguard support hand on Angled Foregrip)
    const leftForearmGeo = new THREE.CylinderGeometry(0.042, 0.048, 0.36, 10);
    const leftForearm = new THREE.Mesh(leftForearmGeo, sleeveMat);
    leftForearm.position.set(-0.15, -0.20, -0.06);
    leftForearm.rotation.set(0.6, 0.4, 0.8);
    gun.add(leftForearm);

    const leftHandGeo = new THREE.BoxGeometry(0.055, 0.065, 0.085);
    const leftHand = new THREE.Mesh(leftHandGeo, gloveMat);
    leftHand.position.set(-0.02, -0.035, -0.27);
    leftHand.rotation.set(0.25, 0.2, -0.2);
    gun.add(leftHand);

    return gun;
  }

  private buildMuzzleFlash(): THREE.Group {
    const flashGroup = new THREE.Group();
    flashGroup.position.set(0, 0.02, -1.06);
    flashGroup.name = 'MuzzleFlash';

    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xffaa22,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      toneMapped: false,
    });

    // 4-pointed star fiery flash
    const starGeo = new THREE.ConeGeometry(0.09, 0.26, 4);
    const star1 = new THREE.Mesh(starGeo, flashMat);
    star1.rotation.x = -Math.PI / 2;
    flashGroup.add(star1);

    const star2 = new THREE.Mesh(starGeo, flashMat);
    star2.rotation.x = -Math.PI / 2;
    star2.rotation.z = Math.PI / 4;
    flashGroup.add(star2);

    return flashGroup;
  }

  public triggerFireRecoil(): number {
    this.recoilZ = Math.min(this.recoilZ + 0.045, 0.10);
    this.recoilPitch = Math.min(this.recoilPitch + 0.06, 0.14);
    this.recoilRoll = (Math.random() - 0.5) * 0.02;

    // Set combat firing timer so weapon immediately raises towards crosshair when firing
    this.fireRecoveryTimer = 0.38;

    // Show fiery muzzle flash and point light
    this.muzzleFlashGroup.children.forEach((child) => {
      const mesh = child as THREE.Mesh;
      const mat = mesh.material as THREE.MeshBasicMaterial;
      mat.opacity = 0.95;
    });
    this.muzzleFlashGroup.rotation.z = Math.random() * Math.PI * 2;
    this.muzzleLight.intensity = 5.0;

    // Return smooth camera pitch recoil amount for camera kick
    return this.isAiming ? 0.010 : 0.022;
  }

  public startReload() {
    if (this.isReloading) return;
    this.isReloading = true;
    this.reloadTime = 0;
  }

  /**
   * Updates weapon sway, recoil decay, bobbing, ADS blending, running & shooting alignment, and peek lean
   */
  public update(
    delta: number,
    isMoving: boolean,
    isRunning: boolean,
    mouseDeltaX: number,
    mouseDeltaY: number,
    isFiring: boolean = false,
    lean: number = 0
  ) {
    // 1. Decay muzzle flash
    this.muzzleFlashGroup.children.forEach((child) => {
      const mesh = child as THREE.Mesh;
      const mat = mesh.material as THREE.MeshBasicMaterial;
      if (mat.opacity > 0) {
        mat.opacity = Math.max(0, mat.opacity - delta * 18);
      }
    });
    if (this.muzzleLight.intensity > 0) {
      this.muzzleLight.intensity = Math.max(0, this.muzzleLight.intensity - delta * 25);
    }

    // 2. Fire Recovery Timer Decay (keeps weapon raised towards crosshair when shooting)
    if (this.fireRecoveryTimer > 0) {
      this.fireRecoveryTimer = Math.max(0, this.fireRecoveryTimer - delta);
    }

    // 3. Recoil Recovery Spring
    const recoverySpeed = 16.0;
    this.recoilZ = THREE.MathUtils.lerp(this.recoilZ, 0, recoverySpeed * delta);
    this.recoilPitch = THREE.MathUtils.lerp(this.recoilPitch, 0, recoverySpeed * delta);
    this.recoilRoll = THREE.MathUtils.lerp(this.recoilRoll, 0, recoverySpeed * delta);

    // 4. Stance & Target Selection
    // User requirement: When running AND firing, immediately cancel low-ready carry and point towards crosshair!
    const isCombatFiring = isFiring || (this.fireRecoveryTimer > 0);
    const isSprinting = isRunning && isMoving && !this.isAiming && !isCombatFiring;

    const targetPos = this.isAiming ? this.adsPos : isSprinting ? this.sprintPos : this.hipPos;

    let targetRotX = isSprinting ? -0.32 : 0;
    let targetRotY = isSprinting ? 0.22 : 0;
    let targetRotZ = (isSprinting ? -0.24 : 0) - lean * 0.12;

    let bobX = 0;
    let bobY = 0;

    if (isMoving) {
      const speed = isRunning ? 13.0 : 8.0;
      this.bobTime += delta * speed;
      // When shooting while moving, reduce bob so player can aim accurately at crosshair
      const amp = this.isAiming ? 0.0012 : isCombatFiring ? 0.0035 : isSprinting ? 0.016 : 0.007;
      bobX = Math.cos(this.bobTime * 0.5) * amp;
      bobY = Math.sin(this.bobTime) * (amp * 1.3);
    } else {
      // Gentle breathing idle
      this.bobTime += delta * 1.8;
      bobX = Math.cos(this.bobTime) * 0.001;
      bobY = Math.sin(this.bobTime * 2) * 0.001;
    }

    // 5. Subtle Lag Sway
    const swayX = -mouseDeltaX * (this.isAiming ? 0.0002 : 0.0007);
    const swayY = -mouseDeltaY * (this.isAiming ? 0.0002 : 0.0007);

    // 6. Reload Animation Arc
    let reloadOffsetY = 0;
    let reloadOffsetRoll = 0;
    if (this.isReloading) {
      this.reloadTime += delta;
      if (this.reloadTime < 0.6) {
        const progress = this.reloadTime / 0.6;
        reloadOffsetY = -Math.sin(progress * Math.PI) * 0.10;
        reloadOffsetRoll = Math.sin(progress * Math.PI) * 0.25;
      } else if (this.reloadTime >= 1.6) {
        this.isReloading = false;
        this.reloadTime = 0;
      }
    }

    // 7. Tactical Lean Lateral Shift
    const leanOffsetX = lean * 0.035;

    // 8. Responsive Stance Blending (Super snappy transition into fire stance from sprint)
    const blendSpeed = isCombatFiring ? 28.0 : this.isAiming ? 20.0 : isSprinting ? 12.0 : 16.0;
    this.weaponMesh.position.x = THREE.MathUtils.lerp(
      this.weaponMesh.position.x,
      targetPos.x + bobX + swayX + leanOffsetX,
      blendSpeed * delta
    );
    this.weaponMesh.position.y = THREE.MathUtils.lerp(
      this.weaponMesh.position.y,
      targetPos.y + bobY + swayY + reloadOffsetY,
      blendSpeed * delta
    );
    this.weaponMesh.position.z = THREE.MathUtils.lerp(
      this.weaponMesh.position.z,
      targetPos.z + this.recoilZ,
      blendSpeed * delta
    );

    this.weaponMesh.rotation.x = THREE.MathUtils.lerp(
      this.weaponMesh.rotation.x,
      targetRotX + this.recoilPitch + swayY * 0.4,
      blendSpeed * delta
    );
    this.weaponMesh.rotation.y = THREE.MathUtils.lerp(
      this.weaponMesh.rotation.y,
      targetRotY + swayX * 0.4,
      blendSpeed * delta
    );
    this.weaponMesh.rotation.z = THREE.MathUtils.lerp(
      this.weaponMesh.rotation.z,
      targetRotZ + this.recoilRoll + reloadOffsetRoll,
      blendSpeed * delta
    );

    // Cache muzzle world position for particle effects
    this.muzzleFlashGroup.getWorldPosition(this.muzzleWorldPos);
  }
}
