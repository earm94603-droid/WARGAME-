import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDamage,
  applyDamageToHealth,
  calculateReload,
  updateMatchScore,
  tickMatchTimer,
  formatGameTime,
  calculateAccuracy,
  calculatePeekOffset,
  createInitialMatchState,
  MATCH_SETTINGS,
} from './rules.ts';

test('calculateDamage returns headshot and body damage correctly', () => {
  assert.equal(calculateDamage(false), MATCH_SETTINGS.BASE_DAMAGE_BODY);
  assert.equal(calculateDamage(true), MATCH_SETTINGS.BASE_DAMAGE_HEAD);
  assert.ok(calculateDamage(true) > calculateDamage(false));
});

test('applyDamageToHealth clamps health to 0 and detects defeat', () => {
  const result1 = applyDamageToHealth(100, 28);
  assert.equal(result1.newHealth, 72);
  assert.equal(result1.isDefeated, false);

  const result2 = applyDamageToHealth(20, 28);
  assert.equal(result2.newHealth, 0);
  assert.equal(result2.isDefeated, true);
});

test('calculateReload correctly transfers ammo from reserve', () => {
  const fullReload = calculateReload(10, 90);
  assert.equal(fullReload.newAmmo, 30);
  assert.equal(fullReload.newReserveAmmo, 70);
  assert.equal(fullReload.roundsLoaded, 20);

  const partialReload = calculateReload(25, 3);
  assert.equal(partialReload.newAmmo, 28);
  assert.equal(partialReload.newReserveAmmo, 0);
  assert.equal(partialReload.roundsLoaded, 3);

  const emptyReserve = calculateReload(15, 0);
  assert.equal(emptyReserve.newAmmo, 15);
  assert.equal(emptyReserve.newReserveAmmo, 0);
  assert.equal(emptyReloadLoaded(emptyReserve), 0);
});

function emptyReloadLoaded(res: { roundsLoaded: number }) {
  return res.roundsLoaded;
}

test('updateMatchScore updates scores and ends match at target score', () => {
  let state = createInitialMatchState(5, 180);
  assert.equal(state.blueScore, 0);
  assert.equal(state.redScore, 0);
  assert.equal(state.isGameOver, false);

  state = updateMatchScore(state, 'blue');
  assert.equal(state.blueScore, 1);
  assert.equal(state.isGameOver, false);

  for (let i = 0; i < 4; i++) {
    state = updateMatchScore(state, 'blue');
  }
  assert.equal(state.blueScore, 5);
  assert.equal(state.isGameOver, true);
  assert.equal(state.winner, 'blue');
});

test('tickMatchTimer decrements time and declares winner on timeout', () => {
  let state = createInitialMatchState(5, 10);
  state.blueScore = 3;
  state.redScore = 2;

  state = tickMatchTimer(state, 4);
  assert.equal(state.timeLeftSeconds, 6);
  assert.equal(state.isGameOver, false);

  state = tickMatchTimer(state, 10);
  assert.equal(state.timeLeftSeconds, 0);
  assert.equal(state.isGameOver, true);
  assert.equal(state.winner, 'blue');
});

test('formatGameTime formats mm:ss accurately', () => {
  assert.equal(formatGameTime(180), '03:00');
  assert.equal(formatGameTime(65), '01:05');
  assert.equal(formatGameTime(9), '00:09');
});

test('calculateAccuracy calculates percentage correctly', () => {
  assert.equal(calculateAccuracy(0, 0), 0);
  assert.equal(calculateAccuracy(10, 5), 50);
  assert.equal(calculateAccuracy(30, 24), 80);
});

test('calculatePeekOffset returns correct lateral and roll offsets for lean states', () => {
  const left = calculatePeekOffset('left', 0.4);
  assert.equal(left.lateralOffset, -0.4);
  assert.equal(left.rollAngle, 0.14);

  const right = calculatePeekOffset('right', 0.4);
  assert.equal(right.lateralOffset, 0.4);
  assert.equal(right.rollAngle, -0.14);

  const center = calculatePeekOffset('center', 0.4);
  assert.equal(center.lateralOffset, 0);
  assert.equal(center.rollAngle, 0);
});
