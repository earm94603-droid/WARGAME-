import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.containerclash.fps',
  appName: 'Container Clash',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true, // Enables local LAN/Wi-Fi hotspot communication without SSL restrictions
  },
  android: {
    backgroundColor: '#0f172a',
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
};

export default config;
