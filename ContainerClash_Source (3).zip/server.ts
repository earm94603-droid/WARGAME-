import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const port = 3000;

app.use(express.json());

// Match Rooms storage: roomCode -> Room
interface RoomPlayer {
  ws: WebSocket;
  id: string;
  team: 'blue' | 'red';
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  health: number;
  score: number;
}

interface Room {
  code: string;
  hostId: string;
  players: Map<string, RoomPlayer>;
  state: {
    blueScore: number;
    redScore: number;
    timeLeft: number;
    targetKills: number;
  };
}

const rooms = new Map<string, Room>();

// WebSocket Server
const wss = new WebSocketServer({ server });

wss.on('connection', (ws: WebSocket) => {
  let currentRoomCode: string | null = null;
  let playerId: string | null = null;

  ws.on('message', (data: string) => {
    try {
      const msg = JSON.parse(data.toString());

      if (msg.type === 'create_room') {
        const code = Math.random().toString(36).substring(2, 6).toUpperCase();
        playerId = 'host_' + Math.random().toString(36).substring(2, 7);
        currentRoomCode = code;

        const room: Room = {
          code,
          hostId: playerId,
          players: new Map(),
          state: {
            blueScore: 0,
            redScore: 0,
            timeLeft: 180,
            targetKills: 5,
          },
        };

        room.players.set(playerId, {
          ws,
          id: playerId,
          team: 'blue',
          x: -18,
          y: 0,
          z: -18,
          yaw: 0,
          pitch: 0,
          health: 100,
          score: 0,
        });

        rooms.set(code, room);

        ws.send(
          JSON.stringify({
            type: 'room_created',
            roomCode: code,
            playerId,
            team: 'blue',
          })
        );
      } else if (msg.type === 'join_room') {
        const code = (msg.roomCode || '').toUpperCase().trim();
        const room = rooms.get(code);

        if (!room) {
          ws.send(JSON.stringify({ type: 'error', message: 'Room not found. Check the room code.' }));
          return;
        }

        if (room.players.size >= 2) {
          ws.send(JSON.stringify({ type: 'error', message: 'Room is already full (1v1 match).' }));
          return;
        }

        playerId = 'client_' + Math.random().toString(36).substring(2, 7);
        currentRoomCode = code;

        room.players.set(playerId, {
          ws,
          id: playerId,
          team: 'red',
          x: 18,
          y: 0,
          z: 18,
          yaw: Math.PI,
          pitch: 0,
          health: 100,
          score: 0,
        });

        ws.send(
          JSON.stringify({
            type: 'room_joined',
            roomCode: code,
            playerId,
            team: 'red',
          })
        );

        // Notify both players that match is ready
        room.players.forEach((p) => {
          p.ws.send(
            JSON.stringify({
              type: 'match_start',
              roomCode: code,
              players: Array.from(room.players.values()).map((pl) => ({
                id: pl.id,
                team: pl.team,
                health: pl.health,
              })),
            })
          );
        });
      } else if (msg.type === 'player_update') {
        if (!currentRoomCode) return;
        const room = rooms.get(currentRoomCode);
        if (!room) return;

        // Relay movement snapshot to opponent
        room.players.forEach((p, pId) => {
          if (pId !== playerId && p.ws.readyState === WebSocket.OPEN) {
            p.ws.send(
              JSON.stringify({
                type: 'opponent_update',
                playerState: msg.playerState,
              })
            );
          }
        });
      } else if (msg.type === 'shoot_event') {
        if (!currentRoomCode) return;
        const room = rooms.get(currentRoomCode);
        if (!room) return;

        // Broadcast gunshot effect to opponent
        room.players.forEach((p, pId) => {
          if (pId !== playerId && p.ws.readyState === WebSocket.OPEN) {
            p.ws.send(
              JSON.stringify({
                type: 'opponent_shoot',
                origin: msg.origin,
                direction: msg.direction,
              })
            );
          }
        });
      } else if (msg.type === 'hit_damage') {
        if (!currentRoomCode) return;
        const room = rooms.get(currentRoomCode);
        if (!room) return;

        const targetId = msg.targetId;
        const target = room.players.get(targetId);
        if (target) {
          target.health = Math.max(0, target.health - (msg.damage || 28));

          // Broadcast hit event and updated health
          room.players.forEach((p) => {
            if (p.ws.readyState === WebSocket.OPEN) {
              p.ws.send(
                JSON.stringify({
                  type: 'damage_applied',
                  targetId,
                  damage: msg.damage,
                  newHealth: target.health,
                  isHeadshot: msg.isHeadshot,
                  attackerId: playerId,
                })
              );
            }
          });

          // If target defeated, award point
          if (target.health <= 0) {
            const attacker = room.players.get(playerId!);
            if (attacker) {
              if (attacker.team === 'blue') room.state.blueScore++;
              else room.state.redScore++;

              room.players.forEach((p) => {
                if (p.ws.readyState === WebSocket.OPEN) {
                  p.ws.send(
                    JSON.stringify({
                      type: 'score_update',
                      blueScore: room.state.blueScore,
                      redScore: room.state.redScore,
                      defeatedId: targetId,
                      winner:
                        room.state.blueScore >= room.state.targetKills
                          ? 'blue'
                          : room.state.redScore >= room.state.targetKills
                          ? 'red'
                          : null,
                    })
                  );
                }
              });

              // Respawn target health after 3s
              setTimeout(() => {
                target.health = 100;
                target.ws.send(JSON.stringify({ type: 'respawn_player' }));
              }, 3000);
            }
          }
        }
      }
    } catch {
      // ignore malformed messages
    }
  });

  ws.on('close', () => {
    if (currentRoomCode) {
      const room = rooms.get(currentRoomCode);
      if (room && playerId) {
        room.players.delete(playerId);
        room.players.forEach((p) => {
          if (p.ws.readyState === WebSocket.OPEN) {
            p.ws.send(
              JSON.stringify({
                type: 'player_disconnected',
                message: 'Opponent disconnected from match.',
              })
            );
          }
        });
        if (room.players.size === 0) {
          rooms.delete(currentRoomCode);
        }
      }
    }
  });
});

// Source project ZIP download
app.get('/download/source.zip', (_req, res) => {
  res.download(path.join(__dirname, 'public', 'downloads', 'ContainerClash_Source.zip'));
});

// APK / WebAPK redirect
app.get('/download/ContainerClash.apk', (_req, res) => {
  res.redirect('/?install=1');
});

// Dev vs Production Vite integration
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`Container Clash game server running on port ${port}`);
  });
}

startServer();
