# CONTAINER CLASH – Android 3D FPS Game

**Container Clash** is a complete, lightweight 3D first-person arcade shooter built with Three.js and packaged as a native standalone Android application using **Capacitor**.

---

## 📱 Features

- **1v1 Local Multiplayer**: Real two-phone Wi-Fi Hotspot LAN combat with host IP detection.
- **Offline Single-Player Bot**: High-performance tactical AI with real-time waypoint navigation and cover shooting.
- **Tactical First-Person Mechanics**:
  - Holographic Red Dot Sight (100% transparent aperture with luminous reticle).
  - Tactical Sprint: Low-ready carry pose that smoothly snaps to center crosshair when firing.
  - Tactical Peek: Lean Left (Q / بيك يسار) and Lean Right (E / بيك يمين) around container cover.
  - Procedural Web Audio: Sub-bass assault rifle punch, mechanical bolt snap, container yard slapback echo.
  - Polished Environmental Visuals: Wet asphalt sheen, corrugation reflections, and dynamic lighting.

---

## 🚀 How to Build APK Directly from Your Android Phone (No Laptop Required!)

Because Android APKs require a Java/Android SDK build toolchain (Gradle), you can easily generate your installable `.apk` file using **GitHub's free Cloud Build (GitHub Actions)** directly from your smartphone browser:

### Method 1: Automated Free Cloud Build via GitHub Actions (Recommended)

1. **Download the Project ZIP**:
   - Download `ContainerClash_Source.zip` from the app.
   - Extract it on your phone using **ZArchiver** or your Files app.
2. **Open GitHub on Your Phone**:
   - Open Chrome on your phone and go to [github.com](https://github.com).
   - Log in or create a free account.
3. **Create a New Repository**:
   - Click **+ (New Repository)** -> Name it `ContainerClash` -> Select **Public** or **Private** -> Click **Create repository**.
4. **Upload Files**:
   - Tap **Add file** -> **Upload files**.
   - Drag/select the extracted project files (including the `.github` folder) and tap **Commit changes**.
5. **Download Your APK**:
   - Go to the **Actions** tab on your GitHub repository.
   - You will see the workflow **"Build Android APK"** running automatically!
   - Wait ~2 to 3 minutes until a green checkmark appears.
   - Tap the completed workflow run, scroll down to **Artifacts**, and tap **`ContainerClash-Android-Debug-APK`**.
   - Your phone will download the ZIP containing `app-debug.apk`. Open and tap **Install**!

---

### Method 2: Building with Android Studio on PC/Mac

If you have access to a computer:
```bash
# 1. Install dependencies
npm install

# 2. Build web bundle
npm run build

# 3. Sync to Android project
npx cap sync android

# 4. Open in Android Studio
npx cap open android
# Or build APK directly via command line:
cd android
./gradlew assembleDebug
```
The output APK will be at:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## 🛠 Project Structure

- `src/` — Complete TypeScript & Three.js 3D game engine (physics, AI bot, weapons, audio, HUD).
- `dist/` — Compiled production web application.
- `android/` — Native Android project (Gradle, AndroidManifest, Capacitor bridge).
- `capacitor.config.ts` — Capacitor Android native bridge configuration.
- `.github/workflows/build-android.yml` — Cloud build pipeline for GitHub Actions.
- `public/` — Assets, textures, audio, and offline manifest.

---

## 📜 Dependencies
- `@capacitor/core`: ^8.6.0
- `@capacitor/android`: ^8.6.0
- `@capacitor/cli`: ^8.6.0
- `three`: ^0.187.0
- `react`: ^19.0.1
- `lucide-react`: ^0.546.0
- `tailwindcss`: ^4.3.3
